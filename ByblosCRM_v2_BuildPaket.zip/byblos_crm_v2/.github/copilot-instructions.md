# Copilot Instructions for Byblos CRM

## Product context
Byblos CRM is an operational CRM for security service, cleaning, janitorial service, moving and clearing services. It supports B2B and B2C workflows, invoices, time tracking, field operations, contracts, compliance and imports.

## Coding rules
- Preserve existing Streamlit navigation and extension modules.
- Keep database/data changes backward compatible.
- Do not remove existing import paths without adding a fallback.
- Use clear German labels in the UI.
- Prefer CSV/JSON exports for operational data.
- Keep legal modules as templates only unless an external legal review is explicitly provided.
- Treat XRechnung/XML output as technical draft unless validated by a certified validator.
- Never add real customer data, employee data or credentials to sample files.

## Test rules
Before submitting changes, run:

```bash
python tests/test_imports.py
python -m py_compile byblos_crm_app/app.py
```

## AI safety rules inside the app
- AI suggestions must be marked as suggestions.
- Low confidence imports must go to review/quarantine.
- Automated financial or legal decisions require human confirmation.
