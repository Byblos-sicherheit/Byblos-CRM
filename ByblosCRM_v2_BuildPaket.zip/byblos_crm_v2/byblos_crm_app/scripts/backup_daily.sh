#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/run_daily_automation.py
if command -v rclone >/dev/null 2>&1 && [ -n "${RCLONE_REMOTE:-}" ]; then
  latest=$(ls -t backups/byblos_crm_backup_*.zip | head -n 1)
  rclone copy "$latest" "$RCLONE_REMOTE"
fi
