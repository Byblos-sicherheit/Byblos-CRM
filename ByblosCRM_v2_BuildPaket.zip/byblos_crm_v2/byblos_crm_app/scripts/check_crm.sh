#!/usr/bin/env bash
set -euo pipefail
URL="${CRM_URL:-https://crm.byblos-sicherheit.de}"
MAIL_TO="${ALERT_EMAIL:-info@byblos-sicherheit.de}"
STATUS=$(curl -L -s -o /dev/null -w "%{http_code}" "$URL" || echo "000")
if [ "$STATUS" != "200" ]; then
  echo "CRM Healthcheck Fehler: $URL liefert HTTP $STATUS" | mail -s "ALARM: Byblos CRM nicht erreichbar" "$MAIL_TO" || true
  exit 1
fi
echo "OK: $URL liefert HTTP 200"
