import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import init_db, run_daily_automation

if __name__ == '__main__':
    init_db()
    for line in run_daily_automation(send_reminders=False, create_backup=True):
        print(line)
