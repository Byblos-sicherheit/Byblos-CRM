#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
latest=$(ls -t backups/byblos_crm_backup_*.zip | head -n 1)
mkdir -p /tmp/byblos_crm_restore_test
rm -rf /tmp/byblos_crm_restore_test/*
unzip -t "$latest"
unzip -q "$latest" -d /tmp/byblos_crm_restore_test
echo "Restore-Test OK: $latest"
