"""
Byblos CRM - Windows Launcher
Startet den eingebetteten Streamlit-Server und oeffnet den Browser.
Wird von PyInstaller als Entry-Point genutzt.
"""
import os
import sys
import threading
import time
import webbrowser
import subprocess
from pathlib import Path


def get_base_dir():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def open_browser(port, delay=3.0):
    time.sleep(delay)
    webbrowser.open(f"http://localhost:{port}")


def main():
    base = get_base_dir()
    app_dir = base / "byblos_crm_app"
    app_py = app_dir / "app.py"

    # Streamlit-Konfiguration
    config_dir = app_dir / ".streamlit"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "config.toml"
    if not config_file.exists():
        config_file.write_text(
            "[server]\nheadless = true\nport = 8501\nenableCORS = false\n\n"
            "[theme]\nprimaryColor = '#c0392b'\nbackgroundColor = '#0e1117'\n"
            "secondaryBackgroundColor = '#1a1f2e'\ntextColor = '#ffffff'\n"
        )

    port = 8501
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    env = os.environ.copy()
    env["PYTHONPATH"] = str(app_dir)

    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(app_py),
        "--server.port", str(port),
        "--server.headless", "true",
        "--server.enableCORS", "false",
        "--browser.gatherUsageStats", "false",
    ]

    proc = subprocess.run(cmd, env=env, cwd=str(app_dir))
    sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
