"""
extensions_v2_xtra.py – Zusätzliche Features für Byblos CRM v2
================================================================
1. Mehrsprachigkeit i18n (DE/EN/TR/AR)
2. OCR mit Tesseract
3. Online-Zahlungs-Links (Stripe/PayPal)
4. MS Teams / Slack / Discord Webhooks
5. Mobile-Optimierung
6. FastAPI REST-Server-Vorbereitung
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, Optional, Tuple
import json

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# DB-Registrierung
# ─────────────────────────────────────────────────────────────

def register_xtra(run_fn, df_fn) -> None:
    run_fn("""CREATE TABLE IF NOT EXISTS payment_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER,
        provider TEXT NOT NULL,
        link_url TEXT NOT NULL,
        amount REAL,
        currency TEXT DEFAULT 'EUR',
        status TEXT DEFAULT 'aktiv',
        clicked_count INTEGER DEFAULT 0,
        last_clicked TEXT,
        expires_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    )""")


# ─────────────────────────────────────────────────────────────
# 1. Mehrsprachigkeit
# ─────────────────────────────────────────────────────────────

TRANSLATIONS = {
    "de": {"dashboard":"Dashboard","customers":"Kunden","invoices":"Rechnungen",
           "expenses":"Ausgaben","employees":"Mitarbeiter","shifts":"Dienstplan",
           "settings":"Einstellungen","save":"Speichern","cancel":"Abbrechen",
           "delete":"Löschen","create":"Anlegen","edit":"Bearbeiten",
           "search":"Suchen","total":"Gesamt","open":"Offen","paid":"Bezahlt",
           "overdue":"Überfällig","today":"Heute","yesterday":"Gestern",
           "this_month":"Dieser Monat","this_year":"Dieses Jahr"},
    "en": {"dashboard":"Dashboard","customers":"Customers","invoices":"Invoices",
           "expenses":"Expenses","employees":"Employees","shifts":"Schedule",
           "settings":"Settings","save":"Save","cancel":"Cancel","delete":"Delete",
           "create":"Create","edit":"Edit","search":"Search","total":"Total",
           "open":"Open","paid":"Paid","overdue":"Overdue","today":"Today",
           "yesterday":"Yesterday","this_month":"This Month","this_year":"This Year"},
    "tr": {"dashboard":"Gösterge","customers":"Müşteriler","invoices":"Faturalar",
           "expenses":"Giderler","employees":"Personel","shifts":"Vardiya",
           "settings":"Ayarlar","save":"Kaydet","cancel":"İptal","delete":"Sil",
           "create":"Oluştur","edit":"Düzenle","search":"Ara","total":"Toplam",
           "open":"Açık","paid":"Ödenmiş","overdue":"Vadesi Geçmiş","today":"Bugün",
           "yesterday":"Dün","this_month":"Bu Ay","this_year":"Bu Yıl"},
    "ar": {"dashboard":"لوحة","customers":"العملاء","invoices":"الفواتير",
           "expenses":"المصاريف","employees":"الموظفون","shifts":"المناوبات",
           "settings":"الإعدادات","save":"حفظ","cancel":"إلغاء","delete":"حذف",
           "create":"إنشاء","edit":"تعديل","search":"بحث","total":"الإجمالي",
           "open":"مفتوح","paid":"مدفوع","overdue":"متأخر","today":"اليوم",
           "yesterday":"أمس","this_month":"هذا الشهر","this_year":"هذا العام"},
}


def t(key: str, lang: str = None) -> str:
    if lang is None:
        lang = st.session_state.get("lang", "de")
    return TRANSLATIONS.get(lang, TRANSLATIONS["de"]).get(key, key)


def page_language_settings(get_setting_fn, set_setting_fn) -> None:
    st.title("🌐 Sprache / Language / Dil / اللغة")

    LANGS = {"de":"🇩🇪 Deutsch", "en":"🇬🇧 English",
             "tr":"🇹🇷 Türkçe", "ar":"🇸🇦 العربية"}

    current = st.session_state.get("lang", get_setting_fn("ui_language", "de"))
    new_label = st.selectbox("Sprache wählen", list(LANGS.values()),
                              index=list(LANGS.keys()).index(current) if current in LANGS else 0)
    new_lang = [k for k,v in LANGS.items() if v == new_label][0]

    if st.button("💾 Speichern", type="primary"):
        st.session_state["lang"] = new_lang
        set_setting_fn("ui_language", new_lang)
        st.success(f"✅ {LANGS[new_lang]}")
        st.rerun()

    st.divider()
    st.subheader("Übersetzungs-Vorschau")
    test_keys = ["dashboard","customers","invoices","save","delete","total","open","paid","overdue"]
    rows = [{"Schlüssel": k, **{LANGS[lang]: TRANSLATIONS[lang].get(k, k) for lang in LANGS}}
            for k in test_keys]
    st.dataframe(pd.DataFrame(rows), use_container_width=True)
    st.info("Mehrsprachigkeit wird schrittweise auf alle Module ausgerollt. "
            "Aktuell: Sidebar-Hauptbegriffe, Buttons.")


# ─────────────────────────────────────────────────────────────
# 2. OCR mit Tesseract
# ─────────────────────────────────────────────────────────────

def extract_text_ocr(file_path: str) -> Tuple[str, str]:
    """Extrahiert Text aus Bild oder gescanntem PDF mit Tesseract OCR."""
    try:
        import subprocess
        result = subprocess.run(["tesseract","--version"],
                                capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return "", "Tesseract nicht installiert"
    except Exception:
        return "", "Tesseract nicht verfügbar – bitte installieren"

    try:
        path = Path(file_path)
        if path.suffix.lower() in [".jpg",".jpeg",".png",".tiff",".bmp"]:
            output_base = path.with_suffix("")
            result = subprocess.run(
                ["tesseract", str(path), str(output_base), "-l", "deu+eng"],
                capture_output=True, text=True, timeout=60
            )
            txt_file = Path(str(output_base) + ".txt")
            if txt_file.exists():
                text = txt_file.read_text(encoding="utf-8")
                txt_file.unlink()
                return text, "OK"
            return "", f"Tesseract: {result.stderr[:100]}"

        elif path.suffix.lower() == ".pdf":
            try:
                from pdf2image import convert_from_path
                images = convert_from_path(str(path), dpi=200)
                full_text = ""
                for i, img in enumerate(images):
                    img_path = path.parent / f"_temp_page_{i}.png"
                    img.save(str(img_path))
                    text, _ = extract_text_ocr(str(img_path))
                    full_text += text + "\n"
                    img_path.unlink()
                return full_text, "OK"
            except ImportError:
                return "", "pdf2image nicht installiert (pip install pdf2image)"
        return "", "Dateityp nicht unterstützt"
    except Exception as e:
        return "", f"Fehler: {e}"


def page_ocr_import(run_fn, df_fn, base_dir: Path) -> None:
    st.title("👁️ OCR Belegerfassung")
    st.caption("Texterkennung aus gescannten Dokumenten und Fotos.")

    tabs = st.tabs(["📄 OCR durchführen", "ℹ️ Installation"])

    with tabs[0]:
        uploaded = st.file_uploader("Beleg hochladen",
            type=["pdf","jpg","jpeg","png","tiff","bmp"])

        if uploaded:
            ocr_dir = base_dir / "imports" / "ocr"
            ocr_dir.mkdir(parents=True, exist_ok=True)
            target = ocr_dir / uploaded.name
            target.write_bytes(uploaded.read())

            with st.spinner("OCR läuft..."):
                text, status = extract_text_ocr(str(target))

            if status == "OK" and text:
                st.success(f"✅ {len(text)} Zeichen extrahiert")
                st.text_area("Erkannter Text", text, height=300)

                try:
                    from extensions_v2_prod1 import extract_invoice_data_from_text
                    extracted = extract_invoice_data_from_text(text)
                    if extracted:
                        st.subheader("🤖 Erkannte Felder:")
                        st.json(extracted)
                except Exception:
                    pass

                st.download_button("📥 Text als TXT", text.encode("utf-8"),
                                   f"ocr_{uploaded.name}.txt", "text/plain")
            else:
                st.error(f"❌ {status}")

    with tabs[1]:
        st.markdown("""
**Tesseract OCR Installation:**

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install tesseract-ocr tesseract-ocr-deu poppler-utils
pip install pdf2image
```

**macOS:**
```bash
brew install tesseract tesseract-lang poppler
pip install pdf2image
```

**Windows:**
1. Tesseract: https://github.com/UB-Mannheim/tesseract/wiki
2. Sprachpaket "deu" auswählen
3. Tesseract zu PATH hinzufügen
4. Poppler: https://github.com/oschwartz10612/poppler-windows/releases

**Docker (im Image bereits konfiguriert via Dockerfile).**
        """)


# ─────────────────────────────────────────────────────────────
# 3. Online-Zahlungslinks
# ─────────────────────────────────────────────────────────────

def page_payment_links(run_fn, df_fn, get_setting_fn, set_setting_fn) -> None:
    st.title("💳 Online-Zahlungslinks")
    st.caption("PayPal-/Stripe-Links zu Rechnungen für schnellere Zahlung.")

    tabs = st.tabs(["⚙️ Anbieter konfigurieren", "🔗 Link erstellen", "📋 Aktive Links"])

    with tabs[0]:
        with st.form("pay_setup"):
            st.subheader("PayPal")
            paypal_email = st.text_input("PayPal Business E-Mail",
                                          get_setting_fn("paypal_email",""))
            st.caption("PayPal.me wird automatisch generiert: paypal.me/[username]/[Betrag]EUR")

            st.subheader("Stripe (manuelle Links)")
            st.caption("Stripe Payment Links erstellst du im Stripe Dashboard und fügst sie hier ein.")

            st.subheader("Allgemein")
            base_url = st.text_input("CRM Basis-URL",
                                      get_setting_fn("payment_base_url","http://localhost:8501"))

            if st.form_submit_button("💾 Speichern", type="primary"):
                set_setting_fn("paypal_email", paypal_email)
                set_setting_fn("payment_base_url", base_url)
                st.success("✅ Gespeichert.")

    with tabs[1]:
        invoices = df_fn("""
            SELECT i.id, i.invoice_no || ' – ' || c.company AS label,
                   ROUND(i.gross_total - i.paid_amount, 2) AS offen
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            WHERE i.status IN ('offen','ueberfaellig')
              AND ROUND(i.gross_total - i.paid_amount, 2) > 0
            ORDER BY i.invoice_date DESC LIMIT 50
        """)
        if invoices.empty:
            st.info("Keine offenen Rechnungen.")
            return

        sel = st.selectbox("Rechnung", invoices["label"].tolist())
        iid = int(invoices[invoices["label"] == sel].iloc[0]["id"])
        amount = float(invoices[invoices["label"] == sel].iloc[0]["offen"])

        col1, col2 = st.columns(2)
        provider = col1.selectbox("Anbieter", ["PayPal.me", "Stripe Payment Link", "Manuelle URL"])
        custom_amount = col2.number_input("Betrag (€)", min_value=0.01, value=amount, step=10.0)

        if st.button("🔗 Zahlungslink erstellen", type="primary"):
            paypal_email = get_setting_fn("paypal_email","")
            link = ""

            if provider == "PayPal.me" and paypal_email:
                username = paypal_email.split("@")[0]
                link = f"https://paypal.me/{username}/{custom_amount:.2f}EUR"
            elif provider == "Stripe Payment Link":
                link = st.text_input("Stripe Payment Link", "https://buy.stripe.com/...")
            else:
                link = st.text_input("URL eingeben")

            if link:
                run_fn("""INSERT INTO payment_links(invoice_id,provider,link_url,amount,status)
                          VALUES(?,?,?,?,?)""",
                       (iid, provider, link, custom_amount, "aktiv"))
                st.success("✅ Zahlungslink erstellt!")
                st.code(link, language="text")

    with tabs[2]:
        links = df_fn("""
            SELECT pl.id, i.invoice_no AS Rechnung, pl.provider AS Anbieter,
                   pl.link_url AS URL, pl.amount AS Betrag,
                   pl.clicked_count AS Klicks, pl.status AS Status
            FROM payment_links pl LEFT JOIN invoices i ON i.id=pl.invoice_id
            ORDER BY pl.created_at DESC
        """)
        if not links.empty:
            st.dataframe(links.drop(columns=["id"]), use_container_width=True)
        else:
            st.info("Noch keine Links erstellt.")


# ─────────────────────────────────────────────────────────────
# 4. Webhook-Integrationen (Teams/Slack/Discord)
# ─────────────────────────────────────────────────────────────

def send_webhook(url: str, payload: dict, provider: str = "generic") -> Tuple[bool, str]:
    try:
        import urllib.request
        import json as json_lib

        if provider == "teams":
            data = {
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "summary": payload.get("title", "Byblos CRM"),
                "themeColor": "C0392B",
                "sections": [{
                    "activityTitle": payload.get("title", ""),
                    "text": payload.get("text", ""),
                    "facts": [{"name": k, "value": str(v)}
                               for k, v in payload.get("facts", {}).items()],
                }]
            }
        elif provider == "slack":
            data = {
                "text": payload.get("title", ""),
                "attachments": [{
                    "color": "#C0392B",
                    "text": payload.get("text", ""),
                    "fields": [{"title": k, "value": str(v), "short": True}
                               for k, v in payload.get("facts", {}).items()],
                }]
            }
        elif provider == "discord":
            facts_text = "\n".join([f"**{k}:** {v}" for k, v in payload.get("facts", {}).items()])
            data = {
                "embeds": [{
                    "title": payload.get("title", "Byblos CRM"),
                    "description": payload.get("text", "") + "\n\n" + facts_text,
                    "color": 12604987,
                }]
            }
        else:
            data = payload

        body = json_lib.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body,
                                      headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status in (200, 201, 202, 204), f"HTTP {resp.status}"
    except Exception as e:
        return False, str(e)


def page_webhook_management(run_fn, df_fn, log_fn) -> None:
    st.title("🔔 Webhook-Integrationen")
    st.caption("MS Teams · Slack · Discord · Eigene Endpunkte.")

    # DB-Tabelle sicherstellen
    run_fn("""CREATE TABLE IF NOT EXISTS webhook_subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        webhook_url TEXT NOT NULL,
        provider TEXT DEFAULT 'generic',
        events TEXT DEFAULT '[]',
        active INTEGER DEFAULT 1,
        last_called TEXT,
        last_status TEXT,
        secret TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    tabs = st.tabs(["➕ Neuer Webhook", "📋 Alle Webhooks", "🧪 Test", "📖 Anleitung"])

    with tabs[0]:
        with st.form("hook_form", clear_on_submit=True):
            name = st.text_input("Name *", "Teams Buchhaltung")
            provider = st.selectbox("Anbieter", ["teams","slack","discord","generic"],
                format_func=lambda p: {"teams":"MS Teams","slack":"Slack",
                                        "discord":"Discord","generic":"Generisch"}[p])
            url = st.text_input("Webhook-URL *",
                placeholder="https://outlook.office.com/webhook/...")
            events = st.multiselect("Trigger-Events",
                ["new_invoice","payment_received","invoice_overdue",
                 "shift_unassigned","backup_completed","contract_expiring",
                 "daily_summary"],
                default=["payment_received","invoice_overdue"])
            if st.form_submit_button("💾 Speichern", type="primary") and name and url:
                run_fn("""INSERT INTO webhook_subscriptions(name,webhook_url,provider,events)
                          VALUES(?,?,?,?)""", (name, url, provider, json.dumps(events)))
                log_fn("webhook_added", name)
                st.success(f"✅ '{name}' angelegt!"); st.rerun()

    with tabs[1]:
        hooks = df_fn("SELECT id, name AS Name, provider AS Anbieter, active AS Aktiv, last_called AS Zuletzt FROM webhook_subscriptions ORDER BY created_at DESC")
        if not hooks.empty:
            st.dataframe(hooks.drop(columns=["id"]), use_container_width=True)
            sel = st.selectbox("Verwalten", hooks["Name"].tolist())
            wid = int(hooks[hooks["Name"] == sel].iloc[0]["id"])
            cur_active = bool(hooks[hooks["Name"] == sel].iloc[0]["Aktiv"])
            col1, col2 = st.columns(2)
            if col1.button("⛔ Deaktivieren" if cur_active else "✅ Aktivieren"):
                run_fn("UPDATE webhook_subscriptions SET active=? WHERE id=?",
                       (0 if cur_active else 1, wid))
                st.rerun()
            if col2.button("🗑️ Löschen"):
                run_fn("DELETE FROM webhook_subscriptions WHERE id=?", (wid,))
                st.rerun()
        else:
            st.info("Noch keine Webhooks.")

    with tabs[2]:
        active_hooks = df_fn("SELECT id, name FROM webhook_subscriptions WHERE active=1")
        if active_hooks.empty:
            st.info("Keine aktiven Webhooks.")
            return
        sel_h = st.selectbox("Webhook", active_hooks["name"].tolist())
        wid = int(active_hooks[active_hooks["name"] == sel_h].iloc[0]["id"])
        title = st.text_input("Titel", "🛡️ Test von Byblos CRM")
        text  = st.text_area("Nachricht", "Diese Test-Nachricht wurde aus Byblos CRM gesendet.")
        if st.button("🚀 Test senden", type="primary"):
            hook = df_fn("SELECT webhook_url, provider FROM webhook_subscriptions WHERE id=?", (wid,)).iloc[0]
            ok, status = send_webhook(
                str(hook["webhook_url"]),
                {"title": title, "text": text,
                 "facts": {"Zeit": datetime.now().isoformat()[:16],
                            "Quelle": "Byblos CRM v2"}},
                str(hook["provider"])
            )
            run_fn("UPDATE webhook_subscriptions SET last_called=?, last_status=? WHERE id=?",
                   (datetime.now().isoformat()[:19], status, wid))
            if ok: st.success(f"✅ {status}")
            else: st.error(f"❌ {status}")

    with tabs[3]:
        st.markdown("""
### MS Teams Webhook erstellen
1. Channel öffnen → **⋯ → Connectors**
2. **"Incoming Webhook"** suchen → Hinzufügen
3. Name "ByblosCRM" eingeben → **Erstellen**
4. URL kopieren

### Slack Webhook
1. https://api.slack.com/messaging/webhooks
2. "Create New App" → "From scratch"
3. **Incoming Webhooks** aktivieren
4. "Add New Webhook to Workspace" → Channel wählen
5. URL kopieren

### Discord Webhook
1. Server-Einstellungen → **Integrationen**
2. **"Webhook erstellen"**
3. Name eingeben → URL kopieren
        """)


# ─────────────────────────────────────────────────────────────
# 5. Mobile-Optimierung
# ─────────────────────────────────────────────────────────────

def page_mobile_mode(get_setting_fn, set_setting_fn) -> None:
    st.title("📱 Mobile-Optimierung")
    st.caption("Kompakt-Ansicht und Touch-Optimierung für Smartphones / Tablets.")

    tabs = st.tabs(["⚙️ Einstellungen", "📲 PWA-Installation", "🎨 Custom CSS"])

    with tabs[0]:
        compact = st.checkbox("Kompakt-Modus aktiv",
                              value=get_setting_fn("compact_mode","0") == "1")
        big_buttons = st.checkbox("Touch-friendly Buttons (44px+)",
                                  value=get_setting_fn("touch_buttons","1") == "1")
        auto_hide = st.checkbox("Sidebar auf Mobil ausblenden",
                                value=get_setting_fn("auto_hide_sidebar","1") == "1")
        large_text = st.checkbox("Größere Schrift",
                                  value=get_setting_fn("large_text","0") == "1")

        if st.button("💾 Speichern", type="primary"):
            for k, v in [
                ("compact_mode", "1" if compact else "0"),
                ("touch_buttons", "1" if big_buttons else "0"),
                ("auto_hide_sidebar", "1" if auto_hide else "0"),
                ("large_text", "1" if large_text else "0"),
            ]:
                set_setting_fn(k, v)
            st.success("✅ Mobile-Einstellungen gespeichert. Browser neu laden für volle Wirkung.")

        # Live-Vorschau CSS
        if compact or big_buttons or large_text:
            css = "<style>"
            if compact:
                css += """
                @media (max-width: 768px) {
                    .block-container {padding: 0.5rem !important;}
                    .stMetric {padding: 0.3rem !important;}
                    h1 {font-size: 1.4rem !important;}
                    h2 {font-size: 1.2rem !important;}
                }
                """
            if big_buttons:
                css += ".stButton button {min-height: 44px; font-size: 16px;}\n"
            if large_text:
                css += "body, .stMarkdown {font-size: 18px !important;}\n"
            css += "</style>"
            st.markdown(css, unsafe_allow_html=True)
            st.info("✅ Vorschau aktiv für diese Sitzung.")

    with tabs[1]:
        st.markdown("""
### Als App auf Smartphone installieren

**iPhone / iPad (Safari):**
1. CRM in Safari öffnen
2. **Teilen-Symbol** unten in der Mitte
3. **"Zum Home-Bildschirm"**
4. Name bestätigen → fertig!

**Android (Chrome):**
1. CRM in Chrome öffnen
2. Menü ⋮ oben rechts
3. **"App installieren"** oder **"Zum Startbildschirm"**

**Vorteile:**
- ✅ App-Icon auf Startbildschirm
- ✅ Vollbildmodus (keine Browserleiste)
- ✅ Schneller Zugriff
- ✅ Funktioniert auch offline für gecachte Seiten
        """)

    with tabs[2]:
        st.markdown("**Eigenes Theme über Streamlit-Config:**")
        st.code("""# .streamlit/config.toml

[theme]
primaryColor = "#c0392b"
backgroundColor = "#0e1117"
secondaryBackgroundColor = "#1a1f2e"
textColor = "#e8eaf0"
font = "sans serif"

[server]
headless = true
maxUploadSize = 200
""", language="toml")


# ─────────────────────────────────────────────────────────────
# 6. FastAPI-Server-Vorbereitung
# ─────────────────────────────────────────────────────────────

def page_api_server_info(run_fn, df_fn, get_setting_fn) -> None:
    st.title("🚀 FastAPI REST-Server")
    st.caption("Vollwertige REST-API für Drittsystem-Integration.")

    tabs = st.tabs(["📖 Endpunkte", "💻 Server-Code", "🔑 API-Keys"])

    with tabs[0]:
        endpoints = [
            ("GET",  "/api/v1/health", "Status-Check (kein Key nötig)"),
            ("GET",  "/api/v1/customers", "Alle Kunden"),
            ("GET",  "/api/v1/customers/{id}", "Einzelner Kunde"),
            ("POST", "/api/v1/customers", "Neuen Kunden anlegen"),
            ("GET",  "/api/v1/invoices", "Rechnungen (?status=open)"),
            ("GET",  "/api/v1/invoices/{id}", "Rechnung mit Positionen"),
            ("GET",  "/api/v1/invoices/{id}/pdf", "Rechnungs-PDF"),
            ("GET",  "/api/v1/employees", "Mitarbeiter"),
            ("GET",  "/api/v1/shifts", "Schichten (?date=YYYY-MM-DD)"),
            ("POST", "/api/v1/checkin", "GPS-Eincheck"),
            ("GET",  "/api/v1/kpis", "Tägliche KPIs"),
            ("POST", "/api/v1/webhook", "Externe Events empfangen"),
        ]
        df_e = pd.DataFrame(endpoints, columns=["Methode","Endpoint","Beschreibung"])
        st.dataframe(df_e, use_container_width=True, height=400)

    with tabs[1]:
        st.subheader("api_server.py")
        st.code('''"""FastAPI REST-Server für Byblos CRM"""
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import FileResponse
import sqlite3
from pathlib import Path
from datetime import datetime

app = FastAPI(title="Byblos CRM API", version="2.0",
              description="REST-API für Byblos Sicherheitsdienst")
DB_PATH = Path(__file__).parent / "byblos_crm.db"


def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    try: yield conn
    finally: conn.close()


def verify_api_key(x_api_key: str = Header(None), conn=Depends(get_db)):
    if not x_api_key:
        raise HTTPException(401, "X-API-Key Header required")
    cur = conn.execute("SELECT * FROM api_keys WHERE api_key=? AND active=1",
                        (x_api_key,))
    if not cur.fetchone():
        raise HTTPException(403, "Invalid API-Key")
    conn.execute("UPDATE api_keys SET last_used=? WHERE api_key=?",
                  (datetime.now().isoformat(), x_api_key))
    conn.commit()


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": "Byblos CRM v2", "time": datetime.now().isoformat()}


@app.get("/api/v1/customers", dependencies=[Depends(verify_api_key)])
def list_customers(conn=Depends(get_db)):
    cur = conn.execute("SELECT * FROM customers ORDER BY company")
    return [dict(row) for row in cur.fetchall()]


@app.get("/api/v1/customers/{cid}", dependencies=[Depends(verify_api_key)])
def get_customer(cid: int, conn=Depends(get_db)):
    cur = conn.execute("SELECT * FROM customers WHERE id=?", (cid,))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "Customer not found")
    return dict(row)


@app.get("/api/v1/invoices", dependencies=[Depends(verify_api_key)])
def list_invoices(status: str = None, conn=Depends(get_db)):
    if status:
        cur = conn.execute("SELECT * FROM invoices WHERE status=? ORDER BY invoice_date DESC", (status,))
    else:
        cur = conn.execute("SELECT * FROM invoices ORDER BY invoice_date DESC LIMIT 100")
    return [dict(row) for row in cur.fetchall()]


@app.get("/api/v1/invoices/{iid}", dependencies=[Depends(verify_api_key)])
def get_invoice(iid: int, conn=Depends(get_db)):
    cur = conn.execute("SELECT * FROM invoices WHERE id=?", (iid,))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404)
    inv = dict(row)
    items = conn.execute("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY position", (iid,))
    inv["items"] = [dict(i) for i in items.fetchall()]
    return inv


@app.get("/api/v1/invoices/{iid}/pdf", dependencies=[Depends(verify_api_key)])
def get_invoice_pdf(iid: int, conn=Depends(get_db)):
    cur = conn.execute("SELECT pdf_path, invoice_no FROM invoices WHERE id=?", (iid,))
    row = cur.fetchone()
    if not row or not row["pdf_path"]:
        raise HTTPException(404, "PDF not generated yet")
    pdf_path = Path(row["pdf_path"])
    if not pdf_path.exists():
        raise HTTPException(404)
    return FileResponse(str(pdf_path), media_type="application/pdf",
                         filename=f"{row[\'invoice_no\']}.pdf")


@app.get("/api/v1/employees", dependencies=[Depends(verify_api_key)])
def list_employees(conn=Depends(get_db)):
    cur = conn.execute("SELECT id, employee_no, name, email, phone FROM employees WHERE active=1")
    return [dict(row) for row in cur.fetchall()]


@app.get("/api/v1/kpis", dependencies=[Depends(verify_api_key)])
def get_kpis(conn=Depends(get_db)):
    cur = conn.execute("SELECT * FROM daily_kpis ORDER BY kpi_date DESC LIMIT 30")
    return [dict(row) for row in cur.fetchall()]
''', language="python")

        st.subheader("Server starten")
        st.code("""# Installation
pip install fastapi uvicorn

# Server starten (separates Terminal)
cd byblos_crm_app
uvicorn api_server:app --host 0.0.0.0 --port 8000 --reload

# Dokumentation:
# http://localhost:8000/docs (Swagger UI)
# http://localhost:8000/redoc (ReDoc)
""", language="bash")

    with tabs[2]:
        keys = df_fn("SELECT id, key_name AS Name, LEFT(api_key,12)||'...' AS Vorschau, permissions AS Berechtigungen, active AS Aktiv, last_used AS Letzte_Nutzung FROM api_keys ORDER BY created_at DESC")
        if not keys.empty:
            st.dataframe(keys.drop(columns=["id"]), use_container_width=True)
        else:
            st.info("Keine API-Keys. Bitte unter 🔌 JSON-API erstellen.")

        st.subheader("Beispiel-Aufruf")
        st.code('''curl -X GET "http://localhost:8000/api/v1/customers" \\
     -H "X-API-Key: byb_dein_api_key_hier"

# Python-Beispiel:
import requests
r = requests.get("http://localhost:8000/api/v1/invoices?status=open",
                  headers={"X-API-Key": "byb_xxx..."})
print(r.json())
''', language="bash")
