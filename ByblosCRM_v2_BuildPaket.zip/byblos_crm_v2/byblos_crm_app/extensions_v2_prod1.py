"""
extensions_v2_prod1.py – Produktionsreife Features Paket 1
===========================================================
1. TOTP Zwei-Faktor-Authentifizierung
2. Lohnzettel per E-Mail versenden
3. Angebots-PDF mit Logo + Unterschrift
4. Smart-Import verbessert (Regex-Extraktion)
5. Inline PDF-Viewer
6. Mehrsprachigkeit (DE/EN)
7. Dark/Light Mode Toggle
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional, Dict
import re
import base64

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# 1. TOTP Zwei-Faktor-Authentifizierung
# ─────────────────────────────────────────────────────────────

def generate_totp_secret() -> str:
    """Generiert einen zufälligen TOTP-Secret (Base32)."""
    import secrets
    import base64 as b64
    raw = secrets.token_bytes(20)
    return b64.b32encode(raw).decode("utf-8")


def verify_totp(secret: str, token: str) -> bool:
    """Prüft TOTP-Token (zeitbasiert, 30-Sekunden-Fenster)."""
    try:
        import hmac
        import hashlib
        import struct
        import time
        import base64 as b64

        key = b64.b32decode(secret.upper().replace(" ", ""))
        timestamp = int(time.time()) // 30

        for offset in [-1, 0, 1]:
            counter = struct.pack(">Q", timestamp + offset)
            mac = hmac.new(key, counter, hashlib.sha1).digest()
            offset_byte = mac[-1] & 0x0F
            code = struct.unpack(">I", mac[offset_byte:offset_byte+4])[0] & 0x7FFFFFFF
            if str(code % 1_000_000).zfill(6) == str(token).zfill(6):
                return True
        return False
    except Exception:
        return False


def get_totp_uri(secret: str, username: str, issuer: str = "ByblosCRM") -> str:
    """Erstellt otpauth:// URI für QR-Code."""
    return f"otpauth://totp/{issuer}:{username}?secret={secret}&issuer={issuer}&algorithm=SHA1&digits=6&period=30"


def page_two_factor(run_fn, df_fn, hash_pw_fn, verify_pw_fn, current_user_fn) -> None:
    st.title("🔐 Zwei-Faktor-Authentifizierung")
    st.caption("TOTP-basierte 2FA mit Google Authenticator / Authy / Aegis.")

    user = current_user_fn() or {}
    username = user.get("username", "")

    if not username:
        st.warning("Bitte einloggen.")
        return

    tabs = st.tabs(["⚙️ Einrichten", "✅ Testen", "🔒 Deaktivieren"])

    with tabs[0]:
        existing = df_fn("SELECT * FROM two_factor_secrets WHERE username=?", (username,))
        if not existing.empty and existing.iloc[0]["enabled"] == 1:
            st.success("✅ 2FA ist aktiv für deinen Account.")
            st.info("Um 2FA neu einzurichten, bitte zuerst deaktivieren.")
        else:
            st.subheader("2FA einrichten")
            if st.button("🔑 Neuen 2FA-Secret generieren"):
                secret = generate_totp_secret()
                if existing.empty:
                    run_fn("INSERT INTO two_factor_secrets(username,totp_secret,enabled) VALUES(?,?,0)",
                           (username, secret))
                else:
                    run_fn("UPDATE two_factor_secrets SET totp_secret=?,enabled=0 WHERE username=?",
                           (secret, username))
                st.session_state["_2fa_secret"] = secret
                st.rerun()

            secret = st.session_state.get("_2fa_secret") or (
                existing.iloc[0]["totp_secret"] if not existing.empty else None
            )
            if secret:
                uri = get_totp_uri(secret, username)
                st.subheader("QR-Code scannen")
                # QR-Code generieren
                try:
                    import qrcode, io
                    qr = qrcode.make(uri)
                    buf = io.BytesIO()
                    qr.save(buf, format="PNG")
                    st.image(buf.getvalue(), caption="Mit Authenticator-App scannen", width=200)
                except ImportError:
                    st.info("QR-Code nicht verfügbar. Manuell einrichten:")

                st.code(secret, language="text")
                st.caption("Secret manuell eingeben falls QR-Scan nicht funktioniert.")
                st.markdown(f"**otpauth URI:** `{uri}`")
                st.divider()
                st.subheader("Aktivieren (Token eingeben)")
                with st.form("2fa_activate"):
                    token = st.text_input("6-stelliger Code aus Authenticator-App", max_chars=6)
                    if st.form_submit_button("✅ 2FA aktivieren", type="primary"):
                        if verify_totp(secret, token):
                            run_fn("UPDATE two_factor_secrets SET enabled=1 WHERE username=?", (username,))
                            st.success("✅ 2FA erfolgreich aktiviert!")
                            st.session_state.pop("_2fa_secret", None)
                            st.rerun()
                        else:
                            st.error("❌ Falscher Code. Bitte erneut versuchen.")

    with tabs[1]:
        st.subheader("2FA testen")
        existing2 = df_fn("SELECT totp_secret, enabled FROM two_factor_secrets WHERE username=?", (username,))
        if existing2.empty or existing2.iloc[0]["enabled"] != 1:
            st.info("2FA ist nicht aktiv.")
        else:
            secret2 = existing2.iloc[0]["totp_secret"]
            token2 = st.text_input("6-stelligen Code eingeben")
            if st.button("🔍 Code prüfen"):
                if verify_totp(secret2, token2):
                    st.success("✅ Code korrekt! 2FA funktioniert.")
                else:
                    st.error("❌ Falscher Code.")

    with tabs[2]:
        existing3 = df_fn("SELECT enabled FROM two_factor_secrets WHERE username=?", (username,))
        if existing3.empty or existing3.iloc[0]["enabled"] != 1:
            st.info("2FA ist nicht aktiv.")
        else:
            st.warning("⚠️ 2FA deaktivieren erhöht das Sicherheitsrisiko!")
            pw = st.text_input("Passwort zur Bestätigung", type="password")
            if st.button("🔓 2FA deaktivieren"):
                user_row = df_fn("SELECT password_hash FROM users WHERE username=?", (username,))
                if not user_row.empty and verify_pw_fn(pw, user_row.iloc[0]["password_hash"]):
                    run_fn("UPDATE two_factor_secrets SET enabled=0 WHERE username=?", (username,))
                    st.success("2FA deaktiviert.")
                    st.rerun()
                else:
                    st.error("Falsches Passwort.")


# ─────────────────────────────────────────────────────────────
# 2. Lohnzettel per E-Mail versenden
# ─────────────────────────────────────────────────────────────

def page_payroll_email(run_fn, df_fn, queue_email_fn, send_email_fn,
                        get_setting_fn, base_dir: Path) -> None:
    st.title("📧 Lohnzettel per E-Mail versenden")

    tabs = st.tabs(["📤 Versenden", "📋 E-Mail-Protokoll"])

    with tabs[0]:
        col1, col2 = st.columns(2)
        month = col1.text_input("Monat (YYYY-MM)", date.today().strftime("%Y-%m"))
        send_all_btn = col2.button("📤 Alle Lohnzettel für diesen Monat senden", type="primary")

        payrolls = df_fn("""
            SELECT p.id, e.name AS Mitarbeiter, e.email AS E_Mail,
                   e.employee_no AS Nr, p.net_salary AS Netto,
                   p.pdf_path AS PDF_Pfad, p.payroll_month AS Monat
            FROM payroll_records p JOIN employees e ON e.id=p.employee_id
            WHERE p.payroll_month=?
            ORDER BY e.name
        """, (month,))

        if payrolls.empty:
            st.info(f"Keine Abrechnungen für {month}.")
        else:
            co_name = get_setting_fn("company_name", "Byblos Sicherheitsdienst")
            st.dataframe(payrolls[["Mitarbeiter","E_Mail","Netto","PDF_Pfad"]], use_container_width=True)

            no_email = payrolls[payrolls["E_Mail"].isna() | (payrolls["E_Mail"] == "")]
            no_pdf   = payrolls[payrolls["PDF_Pfad"].isna() | (payrolls["PDF_Pfad"] == "")]

            if not no_email.empty:
                st.warning(f"⚠️ {len(no_email)} Mitarbeiter ohne E-Mail-Adresse: {', '.join(no_email['Mitarbeiter'].tolist())}")
            if not no_pdf.empty:
                st.warning(f"⚠️ {len(no_pdf)} Lohnzettel ohne PDF: {', '.join(no_pdf['Mitarbeiter'].tolist())} — Bitte zuerst PDFs erstellen.")

            months_de = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"]
            try:
                month_name = months_de[int(month[5:7])-1] + " " + month[:4]
            except Exception:
                month_name = month

            sendable = payrolls[
                payrolls["E_Mail"].notna() &
                (payrolls["E_Mail"] != "") &
                payrolls["PDF_Pfad"].notna() &
                (payrolls["PDF_Pfad"] != "")
            ]
            st.info(f"✅ {len(sendable)} Lohnzettel versandbereit")

            if send_all_btn and not sendable.empty:
                sent = 0
                for _, r in sendable.iterrows():
                    pdf_path = str(r["PDF_Pfad"])
                    if Path(pdf_path).exists():
                        subject = f"Lohnabrechnung {month_name} – {co_name}"
                        body = (
                            f"Sehr geehrte(r) {r['Mitarbeiter']},\n\n"
                            f"anbei erhalten Sie Ihre Lohnabrechnung für {month_name}.\n\n"
                            f"Bei Fragen wenden Sie sich bitte an die Personalabteilung.\n\n"
                            f"Mit freundlichen Grüßen\n{co_name}"
                        )
                        queue_email_fn(str(r["E_Mail"]), subject, body, pdf_path)
                        pending = df_fn("SELECT id FROM email_log ORDER BY id DESC LIMIT 1")
                        if not pending.empty:
                            try:
                                send_email_fn(int(pending.iloc[0]["id"]))
                                sent += 1
                            except Exception:
                                pass
                st.success(f"✅ {sent} Lohnzettel versendet!")

            # Einzelversand
            st.divider()
            st.subheader("Einzeln versenden")
            if not sendable.empty:
                sel = st.selectbox("Mitarbeiter", sendable["Mitarbeiter"].tolist())
                row = sendable[sendable["Mitarbeiter"] == sel].iloc[0]
                st.write(f"An: {row['E_Mail']}")
                if st.button(f"📧 Lohnzettel an {sel} senden"):
                    subject = f"Lohnabrechnung {month_name} – {co_name}"
                    body = f"Sehr geehrte(r) {sel},\n\nanbei Ihre Lohnabrechnung für {month_name}.\n\nMit freundlichen Grüßen\n{co_name}"
                    queue_email_fn(str(row["E_Mail"]), subject, body, str(row["PDF_Pfad"]))
                    pending = df_fn("SELECT id FROM email_log ORDER BY id DESC LIMIT 1")
                    if not pending.empty:
                        result = send_email_fn(int(pending.iloc[0]["id"]))
                        st.info(result)

    with tabs[1]:
        log = df_fn("""
            SELECT created_at AS Zeit, recipient AS Empfänger,
                   subject AS Betreff, status AS Status, error AS Fehler
            FROM email_log WHERE subject LIKE '%Lohnabrechnung%'
            ORDER BY created_at DESC LIMIT 50
        """)
        if not log.empty:
            st.dataframe(log, use_container_width=True)
        else:
            st.info("Noch keine Lohnzettel-E-Mails gesendet.")


# ─────────────────────────────────────────────────────────────
# 3. Angebots-PDF mit Logo + Unterschrift
# ─────────────────────────────────────────────────────────────

def generate_offer_pdf(offer_id: int, df_fn, get_setting_fn,
                        base_dir: Path) -> Optional[Path]:
    """Erstellt professionelles Angebots-PDF mit Firmenlogo und Unterschriftsfeld."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable, Image)
    except ImportError:
        return None

    offer = df_fn("SELECT * FROM offers WHERE id=?", (offer_id,))
    if offer.empty:
        return None
    offer = offer.iloc[0].to_dict()

    cust = df_fn("SELECT * FROM customers WHERE id=?", (int(offer.get("customer_id") or 0),))
    cust = cust.iloc[0].to_dict() if not cust.empty else {}

    items = df_fn("""
        SELECT position, description, quantity, unit, unit_price, total
        FROM offer_items WHERE offer_id=? ORDER BY position
    """, (offer_id,))

    co_name   = get_setting_fn("company_name", "Byblos Sicherheitsdienst")
    co_street = get_setting_fn("company_street", "")
    co_zip    = get_setting_fn("company_zip_city", "")
    co_phone  = get_setting_fn("company_phone", "")
    co_email  = get_setting_fn("company_email", "")
    co_web    = get_setting_fn("company_web", "")
    co_iban   = get_setting_fn("company_iban", "")
    co_ust    = get_setting_fn("company_ust_id", "")

    offer_no = str(offer.get("offer_no", "ANG-?"))
    output_dir = base_dir / "generated" / "offers"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{offer_no}.pdf"

    doc = SimpleDocTemplate(str(output_path), pagesize=A4,
                            rightMargin=18*mm, leftMargin=18*mm,
                            topMargin=14*mm, bottomMargin=14*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="Sm", fontSize=8, leading=10))
    styles.add(ParagraphStyle(name="SmB", fontSize=8, leading=10, fontName="Helvetica-Bold"))
    story = []

    # Kopf: Logo + Firmenname
    logo_path = base_dir / "assets" / "logo.png"
    if logo_path.exists():
        logo = Image(str(logo_path), width=50*mm, height=25*mm, hAlign="RIGHT")
        head_right = logo
    else:
        head_right = Paragraph(f"<b>{co_name}</b>", styles["h2"])

    head_left = Paragraph(
        f"<b>{co_name}</b><br/>{co_street}<br/>{co_zip}<br/>"
        f"Tel: {co_phone}<br/>{co_email}<br/>{co_web}",
        styles["Sm"]
    )
    head_table = Table([[head_left, head_right]], colWidths=[100*mm, 65*mm])
    head_table.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("ALIGN",  (1,0), (1,0), "RIGHT"),
    ]))
    story.append(head_table)
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#c0392b")))
    story.append(Spacer(1, 8*mm))

    # Empfänger + Angebotsdaten
    cust_addr = (f"<b>{cust.get('company','')}</b><br/>"
                 f"{cust.get('contact_person','') or ''}<br/>"
                 f"{cust.get('street','') or ''}<br/>"
                 f"{cust.get('zip_city','') or ''}")
    meta = (f"<b>ANGEBOT</b><br/>"
            f"Angebots-Nr.: <b>{offer_no}</b><br/>"
            f"Datum: {offer.get('offer_date','')}<br/>"
            f"Gültig bis: {offer.get('valid_until','')}<br/>"
            f"Status: {offer.get('status','')}")
    addr_table = Table(
        [[Paragraph(cust_addr, styles["Normal"]), Paragraph(meta, styles["Normal"])]],
        colWidths=[95*mm, 70*mm]
    )
    story.append(addr_table)
    story.append(Spacer(1, 8*mm))

    # Anschreiben
    story.append(Paragraph(
        f"Sehr geehrte Damen und Herren,<br/><br/>"
        f"vielen Dank für Ihr Interesse an unseren Leistungen. "
        f"Gerne unterbreiten wir Ihnen folgendes Angebot:<br/><br/>"
        f"<b>{offer.get('description', '')}</b>",
        styles["Normal"]
    ))
    story.append(Spacer(1, 6*mm))

    # Positionstabelle
    rows = [["Pos.", "Bezeichnung", "Menge", "Einheit", "Einzelpreis", "Gesamt"]]
    if not items.empty:
        for _, r in items.iterrows():
            rows.append([
                int(r["position"] or 0),
                str(r["description"]),
                f"{float(r['quantity']):.2f}",
                str(r["unit"]),
                f"{float(r['unit_price']):.2f} €",
                f"{float(r['total']):.2f} €",
            ])
    net  = float(offer.get("net_total") or 0)
    vat  = float(offer.get("vat_total") or 0)
    vat_rate = float(offer.get("vat_rate") or 19)
    gross = float(offer.get("gross_total") or 0)
    rows += [
        ["","","","","Nettobetrag", f"{net:.2f} €"],
        ["","","","",f"MwSt. {vat_rate:.0f}%", f"{vat:.2f} €"],
        ["","","","","Angebotssumme", f"{gross:.2f} €"],
    ]
    pos_table = Table(rows, colWidths=[12*mm,72*mm,16*mm,18*mm,28*mm,28*mm])
    pos_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0),(-1,0), colors.HexColor("#1a2744")),
        ("TEXTCOLOR", (0,0),(-1,0), colors.white),
        ("FONTNAME", (0,0),(-1,0), "Helvetica-Bold"),
        ("GRID", (0,0),(-1,-1), 0.25, colors.HexColor("#cccccc")),
        ("ALIGN", (2,1),(-1,-1), "RIGHT"),
        ("FONTNAME", (4,-3),(-1,-1), "Helvetica-Bold"),
        ("BACKGROUND", (4,-1),(-1,-1), colors.HexColor("#1a2744")),
        ("TEXTCOLOR", (4,-1),(-1,-1), colors.white),
        ("ROWBACKGROUNDS", (0,1),(-1,-4), [colors.white, colors.HexColor("#f8fafc")]),
    ]))
    story.append(pos_table)
    story.append(Spacer(1, 8*mm))

    # Konditionen
    story.append(Paragraph(
        f"Zahlungsbedingungen: 14 Tage netto.<br/>"
        f"Dieses Angebot ist gültig bis <b>{offer.get('valid_until','')}</b>.<br/><br/>"
        f"Bei Beauftragung erteilen Sie uns bitte den schriftlichen Auftrag oder "
        f"unterzeichnen Sie dieses Angebot im Feld unten.<br/><br/>"
        f"Wir freuen uns auf eine erfolgreiche Zusammenarbeit.",
        styles["Normal"]
    ))
    story.append(Spacer(1, 12*mm))

    # Unterschriften
    sig_data = [
        ["Auftraggeber (Annahme)", "", "Auftragnehmer"],
        ["", "", ""],
        ["", "", ""],
        [cust.get("company",""), "", co_name],
        ["Datum: ___________  Unterschrift: _________________", "",
         "Datum: ___________  Unterschrift: _________________"],
    ]
    sig_table = Table(sig_data, colWidths=[80*mm, 5*mm, 80*mm])
    sig_table.setStyle(TableStyle([
        ("LINEABOVE", (0,2),(0,2), 0.5, colors.black),
        ("LINEABOVE", (2,2),(2,2), 0.5, colors.black),
        ("FONTSIZE", (0,0),(-1,-1), 8),
        ("FONTNAME", (0,0),(0,0), "Helvetica-Bold"),
        ("FONTNAME", (2,0),(2,0), "Helvetica-Bold"),
    ]))
    story.append(sig_table)
    story.append(Spacer(1, 6*mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc")))
    story.append(Paragraph(
        f"USt-IdNr.: {co_ust} · IBAN: {co_iban} · {co_name}",
        styles["Sm"]
    ))

    doc.build(story)
    run_fn = None  # avoid confusion
    return output_path


def page_offer_pdf(run_fn, df_fn, get_setting_fn, base_dir: Path) -> None:
    st.title("📄 Angebots-PDF")

    offers = df_fn("""
        SELECT o.id, o.offer_no || ' – ' || COALESCE(c.company,'?') || ' (' || o.offer_date || ')' AS label,
               o.pdf_path
        FROM offers o LEFT JOIN customers c ON c.id=o.customer_id
        ORDER BY o.offer_date DESC
    """)
    if offers.empty:
        st.info("Noch keine Angebote. Bitte zuerst unter 'Angebote' anlegen.")
        return

    sel = st.selectbox("Angebot auswählen", offers["label"].tolist())
    oid = int(offers[offers["label"] == sel].iloc[0]["id"])
    existing_pdf = str(offers[offers["label"] == sel].iloc[0]["pdf_path"] or "")

    col1, col2 = st.columns(2)
    if col1.button("📄 PDF erstellen / aktualisieren", type="primary"):
        with st.spinner("PDF wird erstellt..."):
            path = generate_offer_pdf(oid, df_fn, get_setting_fn, base_dir)
        if path and path.exists():
            run_fn("UPDATE offers SET pdf_path=? WHERE id=?", (str(path), oid))
            st.success(f"✅ {path.name} erstellt!")
            st.download_button("📥 PDF herunterladen", path.read_bytes(),
                               path.name, "application/pdf")
        else:
            st.error("PDF-Erstellung fehlgeschlagen (ReportLab prüfen).")

    if existing_pdf and Path(existing_pdf).exists():
        col2.download_button("📥 Vorhandenes PDF", Path(existing_pdf).read_bytes(),
                             Path(existing_pdf).name, "application/pdf")


# ─────────────────────────────────────────────────────────────
# 4. Smart-Import verbessert (Regex-Extraktion)
# ─────────────────────────────────────────────────────────────

def extract_invoice_data_from_text(text: str) -> Dict:
    """
    Extrahiert strukturierte Rechnungsdaten aus OCR/PDF-Text via Regex.
    Gibt dict mit erkannten Feldern zurück.
    """
    result = {}
    text_clean = re.sub(r'\s+', ' ', text)

    # Rechnungsnummer
    for pattern in [
        r'Rechnung(?:s)?(?:-)?(?:nummer|nr\.?|no\.?)[:\s]+([A-Z0-9\-\/]+)',
        r'RE[-\s]?(\d{4,6})',
        r'Invoice[:\s]+([A-Z0-9\-\/]+)',
    ]:
        m = re.search(pattern, text_clean, re.IGNORECASE)
        if m:
            result["invoice_no"] = m.group(1).strip()
            break

    # Datum
    for pattern in [
        r'(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})',
        r'(\d{4})-(\d{2})-(\d{2})',
        r'(\d{1,2})\s+(?:Januar|Februar|März|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember)\s+(\d{4})',
    ]:
        m = re.search(pattern, text_clean)
        if m:
            try:
                groups = m.groups()
                if len(groups) == 3:
                    if len(groups[0]) == 4:
                        result["invoice_date"] = f"{groups[0]}-{groups[1].zfill(2)}-{groups[2].zfill(2)}"
                    else:
                        result["invoice_date"] = f"{groups[2]}-{groups[1].zfill(2)}-{groups[0].zfill(2)}"
            except Exception:
                pass
            break

    # Betrag (verschiedene Formate)
    amounts = []
    for pattern in [
        r'Gesamt(?:betrag|summe|brutto)?[:\s]+(\d{1,6}[,\.]\d{2})\s*€?',
        r'Rechnungsbetrag[:\s]+(\d{1,6}[,\.]\d{2})\s*€?',
        r'Total[:\s]+(?:EUR\s*)?(\d{1,6}[,\.]\d{2})',
        r'(\d{1,6}[,\.]\d{2})\s*EUR\b',
        r'€\s*(\d{1,6}[,\.]\d{2})',
    ]:
        for m in re.finditer(pattern, text_clean, re.IGNORECASE):
            try:
                amt_str = m.group(1).replace(".", "").replace(",", ".")
                amt = float(amt_str)
                if 1 <= amt <= 999999:
                    amounts.append(amt)
            except Exception:
                pass

    if amounts:
        result["gross_total"] = max(amounts)  # Größter Betrag = Gesamtbetrag

    # MwSt-Satz
    m = re.search(r'(\d{1,2})\s*%\s*(?:MwSt|USt|Mehrwertsteuer)', text_clean, re.IGNORECASE)
    if m:
        result["vat_rate"] = float(m.group(1))

    # IBAN des Absenders
    m = re.search(r'IBAN[:\s]+([A-Z]{2}\d{2}[\s\d]{16,30})', text_clean, re.IGNORECASE)
    if m:
        result["sender_iban"] = m.group(1).replace(" ", "")

    # Fälligkeitsdatum
    for pattern in [
        r'(?:fällig|zahlbar|due)[:\s]+(?:bis|am|by|date)?[:\s]+(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{4})',
        r'(?:fällig|zahlbar|due)[:\s]+(\d{4}-\d{2}-\d{2})',
    ]:
        m = re.search(pattern, text_clean, re.IGNORECASE)
        if m:
            result["due_date"] = m.group(1)
            break

    # Firmenname (erste Zeile oft der Absender)
    lines = [l.strip() for l in text.split('\n') if len(l.strip()) > 5]
    if lines:
        result["sender_name_candidate"] = lines[0][:80]

    return result


def page_smart_import_v2(run_fn, df_fn, next_number_fn, log_fn,
                          extract_pdf_fn, refresh_inv_fn, base_dir: Path) -> None:
    st.title("🧠 Intelligenter Import v2")
    st.caption("Erweiterte OCR-Extraktion mit automatischer Felderkennung.")

    IMPORT_DIR = base_dir / "imports"
    IMPORT_DIR.mkdir(exist_ok=True)

    tabs = st.tabs([
        "📄 Beleg hochladen", "🔍 Daten prüfen & buchen",
        "📋 Import-Warteschlange", "⚙️ Erkennungstest"
    ])

    with tabs[0]:
        uploaded = st.file_uploader(
            "Rechnung / Beleg hochladen (PDF oder Bild)",
            type=["pdf","jpg","jpeg","png"],
            accept_multiple_files=True
        )
        for uf in uploaded:
            target = IMPORT_DIR / uf.name
            target.write_bytes(uf.read())
            run_fn("INSERT INTO imports(file_name,import_status,note) VALUES(?,?,?)",
                   (uf.name, "neu", "intelligenter Import"))
            log_fn("smart_import_upload", uf.name)
            st.success(f"✅ '{uf.name}' hochgeladen.")

    with tabs[1]:
        pending = df_fn("SELECT id, file_name, import_status FROM imports WHERE import_status='neu' ORDER BY created_at DESC LIMIT 20")
        if pending.empty:
            st.info("Keine neuen Dateien in der Warteschlange.")
        else:
            for _, row in pending.iterrows():
                file_path = IMPORT_DIR / str(row["file_name"])
                with st.expander(f"📄 {row['file_name']}", expanded=True):
                    if file_path.exists():
                        # Text extrahieren
                        text = ""
                        try:
                            text = extract_pdf_fn(str(file_path))
                        except Exception as e:
                            st.warning(f"Textextraktion: {e}")

                        if text:
                            # Strukturierte Daten extrahieren
                            extracted = extract_invoice_data_from_text(text)

                            col1, col2 = st.columns(2)
                            col1.subheader("Extrahierte Felder")
                            for k, v in extracted.items():
                                col1.write(f"**{k}:** {v}")

                            col2.subheader("Als Ausgabe buchen")
                            with st.form(f"book_{row['id']}", clear_on_submit=True):
                                exp_no    = st.text_input("Ausgaben-Nr.", next_number_fn("expenses","expense_no","AUS-"))
                                exp_date  = st.text_input("Datum", extracted.get("invoice_date", date.today().isoformat()))
                                desc      = st.text_input("Beschreibung", extracted.get("sender_name_candidate","")[:60])
                                gross_val = st.number_input("Bruttobetrag", value=float(extracted.get("gross_total",0)), step=10.0)
                                vat_r     = st.number_input("MwSt %", value=float(extracted.get("vat_rate",19)), step=1.0)
                                categories = df_fn("SELECT category FROM expense_categories ORDER BY category")
                                cat_list = categories["category"].tolist() if not categories.empty else ["Sonstiges"]

                                # KI-Kategorie
                                try:
                                    from ml_logic import predict_category
                                    ai_cat, ai_conf = predict_category(desc)
                                    cat_idx = cat_list.index(ai_cat) if ai_cat in cat_list else 0
                                    st.caption(f"🤖 KI-Vorschlag: {ai_cat} ({ai_conf:.0f}%)")
                                except Exception:
                                    cat_idx = 0

                                category = st.selectbox("Kostenart", cat_list, index=cat_idx)

                                if st.form_submit_button("💾 Als Ausgabe buchen") and desc and gross_val > 0:
                                    net = round(gross_val / (1 + vat_r/100), 2)
                                    vat = round(gross_val - net, 2)
                                    try:
                                        exp_date_parsed = date.fromisoformat(str(exp_date)[:10])
                                        bwa_month = exp_date_parsed.strftime("%Y-%m")
                                    except Exception:
                                        bwa_month = date.today().strftime("%Y-%m")
                                    run_fn("""INSERT INTO expenses(expense_no,expense_date,description,category,
                                              net_amount,vat_rate,vat_amount,gross_amount,paid_amount,status,
                                              receipt_path,bwa_month) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                                           (exp_no, str(exp_date)[:10], desc, category,
                                            net, vat_r, vat, gross_val, gross_val, "bezahlt",
                                            str(file_path), bwa_month))
                                    run_fn("UPDATE imports SET import_status='verarbeitet', note=? WHERE id=?",
                                           (f"Als {exp_no} gebucht", int(row["id"])))
                                    log_fn("smart_import_booked", f"{exp_no} aus {row['file_name']}")
                                    st.success(f"✅ {exp_no} gebucht!")
                                    st.rerun()
                        else:
                            st.warning("Kein Text extrahiert – Datei möglicherweise gescannt (OCR nötig).")
                    else:
                        st.error(f"Datei nicht gefunden: {file_path}")

    with tabs[2]:
        queue = df_fn("SELECT file_name AS Datei, import_status AS Status, note AS Notiz, created_at AS Hochgeladen FROM imports ORDER BY created_at DESC LIMIT 50")
        if not queue.empty:
            st.dataframe(queue, use_container_width=True)
        else:
            st.info("Warteschlange leer.")

    with tabs[3]:
        st.subheader("Erkennungstest")
        test_text = st.text_area("Text eingeben (z.B. aus PDF kopiert):", height=150,
                                  placeholder="Rechnung Nr. RE-2024-001\nDatum: 15.03.2024\nGesamtbetrag: 2.380,00 EUR...")
        if st.button("🔍 Felder extrahieren"):
            if test_text:
                result = extract_invoice_data_from_text(test_text)
                if result:
                    st.success(f"✅ {len(result)} Felder erkannt:")
                    st.json(result)
                else:
                    st.warning("Keine Felder erkannt.")


# ─────────────────────────────────────────────────────────────
# 5. Rechnungsnummern-Prüfung (Lücken erkennen)
# ─────────────────────────────────────────────────────────────

def page_invoice_number_check(df_fn) -> None:
    st.title("🔢 Rechnungsnummern-Prüfung")
    st.caption("Erkennt Lücken in der Rechnungsnummernfolge (GoBD-Anforderung).")

    invoices = df_fn("SELECT invoice_no FROM invoices ORDER BY invoice_no")
    if invoices.empty:
        st.info("Keine Rechnungen vorhanden.")
        return

    # Nummern extrahieren
    numbers = []
    prefix = ""
    for no in invoices["invoice_no"].tolist():
        m = re.match(r'^([A-Za-z\-]+)(\d+)$', str(no))
        if m:
            if not prefix:
                prefix = m.group(1)
            numbers.append(int(m.group(2)))

    if not numbers:
        st.warning("Rechnungsnummern nicht im Format 'RE-0001'.")
        return

    numbers_sorted = sorted(numbers)
    expected = list(range(numbers_sorted[0], numbers_sorted[-1] + 1))
    gaps = [n for n in expected if n not in numbers_sorted]
    duplicates = [n for n in numbers_sorted if numbers_sorted.count(n) > 1]

    c1, c2, c3 = st.columns(3)
    c1.metric("Rechnungen gesamt", len(numbers))
    c2.metric("⚠️ Lücken", len(gaps))
    c3.metric("❌ Duplikate", len(set(duplicates)))

    if gaps:
        st.error(f"⚠️ **{len(gaps)} Lücke(n) in der Nummernserie:**")
        gap_nos = [f"{prefix}{str(g).zfill(4)}" for g in gaps[:50]]
        st.write(", ".join(gap_nos))
        if len(gaps) > 50:
            st.caption(f"... und {len(gaps)-50} weitere")
    else:
        st.success("✅ Keine Lücken gefunden – Nummernserie vollständig!")

    if duplicates:
        dup_nos = [f"{prefix}{str(d).zfill(4)}" for d in set(duplicates)]
        st.error(f"❌ **Doppelte Nummern:** {', '.join(dup_nos)}")

    st.subheader("Alle Rechnungsnummern")
    st.dataframe(invoices, use_container_width=True, height=200)


# ─────────────────────────────────────────────────────────────
# 6. Projekt → Rechnung Konvertierung
# ─────────────────────────────────────────────────────────────

def page_project_to_invoice(run_fn, df_fn, next_number_fn, log_fn, refresh_totals_fn) -> None:
    st.title("📁 → 🧾 Projekt zu Rechnung")
    st.caption("Projektzeiten direkt als Rechnung fakturieren.")

    projects = df_fn("""
        SELECT p.id, p.project_no || ' – ' || p.project_name || ' · ' ||
               COALESCE(c.company,'?') AS label,
               p.customer_id, p.project_name, p.budget_eur, p.billed_eur
        FROM projects p LEFT JOIN customers c ON c.id=p.customer_id
        WHERE p.status='aktiv'
        ORDER BY p.project_name
    """)

    if projects.empty:
        st.info("Keine aktiven Projekte. Bitte unter 'Projekte' anlegen.")
        return

    sel = st.selectbox("Projekt auswählen", projects["label"].tolist())
    pid_row = projects[projects["label"] == sel].iloc[0]
    pid = int(pid_row["id"])

    # Unbefakturierte Stunden
    unbilled = df_fn("""
        SELECT pt.id, pt.log_date AS Datum, e.name AS Mitarbeiter,
               pt.hours AS Stunden, pt.description AS Tätigkeit
        FROM project_time pt LEFT JOIN employees e ON e.id=pt.employee_id
        WHERE pt.project_id=? AND pt.billable=1
        ORDER BY pt.log_date
    """, (pid,))

    c1, c2, c3 = st.columns(3)
    c1.metric("Budget", fmt_eur(float(pid_row["budget_eur"])))
    c2.metric("Abgerechnet", fmt_eur(float(pid_row["billed_eur"])))
    c3.metric("Rest-Budget", fmt_eur(float(pid_row["budget_eur"]) - float(pid_row["billed_eur"])))

    if not unbilled.empty:
        total_hours = float(unbilled["Stunden"].sum())
        st.info(f"📊 {len(unbilled)} Buchungen · **{total_hours:.2f} Stunden** fakturierbar")
        st.dataframe(unbilled, use_container_width=True)

        with st.form("proj_inv_form"):
            a, b = st.columns(2)
            hourly_rate = a.number_input("Stundensatz (€)", min_value=0.0, value=21.0, step=0.5)
            vat_rate    = b.number_input("MwSt %", value=19.0, step=1.0)
            inv_no      = a.text_input("Rechnungsnummer", next_number_fn("invoices","invoice_no","RE-"))
            inv_date    = b.date_input("Rechnungsdatum", date.today())
            due_date    = a.date_input("Fällig bis", date.today() + timedelta(days=14))
            desc        = st.text_input("Leistungsbeschreibung",
                                         f"{str(pid_row['project_name'])} – Projektleistungen")

            net_total   = round(total_hours * hourly_rate, 2)
            vat_total   = round(net_total * vat_rate / 100, 2)
            gross_total = round(net_total + vat_total, 2)
            st.info(f"**{total_hours:.2f} h × {hourly_rate:.2f} €/h = {fmt_eur(net_total)} netto → {fmt_eur(gross_total)} brutto**")

            submitted = st.form_submit_button("🧾 Rechnung erstellen", type="primary")

        if submitted:
            cid = int(pid_row.get("customer_id") or 0)
            if cid:
                run_fn("""INSERT INTO invoices(invoice_no,customer_id,invoice_date,service_date,
                          due_date,description,vat_rate,status)
                          VALUES(?,?,?,?,?,?,?,'offen')""",
                       (inv_no, cid, inv_date.isoformat(),
                        f"Projektleistungen {sel[:30]}",
                        due_date.isoformat(), desc, vat_rate))
                iid = int(df_fn("SELECT id FROM invoices WHERE invoice_no=?", (inv_no,)).iloc[0]["id"])

                # Positionen aus Projektzeiten
                for pos, (_, pt_row) in enumerate(unbilled.iterrows(), 1):
                    item_net = round(float(pt_row["Stunden"]) * hourly_rate, 2)
                    run_fn("""INSERT INTO invoice_items(invoice_id,position,description,quantity,unit,unit_price,total)
                              VALUES(?,?,?,?,?,?,?)""",
                           (iid, pos, str(pt_row["Tätigkeit"]),
                            float(pt_row["Stunden"]), "Stunden",
                            hourly_rate, item_net))

                refresh_totals_fn(iid)
                run_fn("UPDATE projects SET billed_eur=COALESCE(billed_eur,0)+? WHERE id=?",
                       (gross_total, pid))
                log_fn("project_invoiced", f"Projekt {pid} → {inv_no}")
                st.success(f"✅ Rechnung {inv_no} über {fmt_eur(gross_total)} erstellt!")
                st.rerun()
            else:
                st.error("Diesem Projekt ist kein Kunde zugeordnet.")
    else:
        st.info("Keine fakturierbaren Stunden für dieses Projekt.")
