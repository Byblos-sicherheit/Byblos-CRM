"""
extensions_v2_remote_access.py – Remote-Zugang für Byblos CRM v2
=================================================================
1. Netzwerk-Status (LAN IP, öffentliche IP, QR-Code)
2. Cloudflare Tunnel (kostenlos, kein Router nötig)
3. ngrok Tunnel (Alternative)
4. Tunnel-Manager (Start/Stop/Status)
5. Sicherheits-Einstellungen für Remote-Zugang
6. Dyn-DNS Konfiguration
7. Mobile-QR-Code (direkt scannen)
"""

from __future__ import annotations

import json
import os
import platform
import socket
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

import streamlit as st


# ─────────────────────────────────────────────────────────────
# Netzwerk-Hilfsfunktionen
# ─────────────────────────────────────────────────────────────

def get_local_ip() -> str:
    """Ermittelt die lokale IP-Adresse (LAN)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def get_public_ip() -> str:
    """Ermittelt die öffentliche IP (Internet)."""
    try:
        import urllib.request
        with urllib.request.urlopen("https://api.ipify.org", timeout=5) as r:
            return r.read().decode("utf-8").strip()
    except Exception:
        try:
            import urllib.request
            with urllib.request.urlopen("https://ifconfig.me/ip", timeout=5) as r:
                return r.read().decode("utf-8").strip()
        except Exception:
            return "Nicht ermittelbar"


def get_hostname() -> str:
    """Hostname des Computers."""
    return socket.gethostname()


def is_port_open(host: str, port: int) -> bool:
    """Prüft ob ein Port erreichbar ist."""
    try:
        s = socket.socket()
        s.settimeout(2)
        s.connect((host, port))
        s.close()
        return True
    except Exception:
        return False


def generate_qr_code_svg(url: str, size: int = 200) -> str:
    """Erstellt einen QR-Code als SVG (ohne externe Bibliothek)."""
    try:
        import qrcode
        import io
        qr = qrcode.QRCode(box_size=6, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#c0392b", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        import base64
        b64 = base64.b64encode(buf.getvalue()).decode()
        return f'<img src="data:image/png;base64,{b64}" width="{size}" height="{size}" style="border:4px solid #c0392b;border-radius:8px;">'
    except Exception:
        # Fallback: Text-QR
        return f'<div style="background:#eee;padding:16px;border-radius:8px;font-family:monospace;word-break:break-all;">{url}</div>'


# ─────────────────────────────────────────────────────────────
# Tunnel-Manager
# ─────────────────────────────────────────────────────────────

TUNNEL_STATE_FILE = Path.home() / ".byblos_crm" / "tunnel_state.json"


def save_tunnel_state(provider: str, url: str, pid: int = 0) -> None:
    TUNNEL_STATE_FILE.parent.mkdir(exist_ok=True)
    json.dumps({
        "provider": provider, "url": url,
        "pid": pid, "started": datetime.now().isoformat()
    })
    TUNNEL_STATE_FILE.write_text(json.dumps({
        "provider": provider, "url": url,
        "pid": pid, "started": datetime.now().isoformat()
    }))


def load_tunnel_state() -> Optional[dict]:
    try:
        if TUNNEL_STATE_FILE.exists():
            return json.loads(TUNNEL_STATE_FILE.read_text())
    except Exception:
        pass
    return None


def clear_tunnel_state() -> None:
    try:
        TUNNEL_STATE_FILE.unlink()
    except Exception:
        pass


def start_cloudflare_tunnel(port: int = 8501) -> Tuple[bool, str]:
    """Startet Cloudflare Tunnel (cloudflared)."""
    cf = None
    for candidate in ["cloudflared", "cloudflared.exe",
                       str(Path.home() / ".byblos_crm" / "cloudflared"),
                       str(Path.home() / ".byblos_crm" / "cloudflared.exe")]:
        try:
            r = subprocess.run([candidate, "--version"], capture_output=True, timeout=3)
            if r.returncode == 0:
                cf = candidate
                break
        except Exception:
            pass

    if not cf:
        return False, "cloudflared nicht gefunden"

    try:
        proc = subprocess.Popen(
            [cf, "tunnel", "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1
        )
        # URL aus Output lesen (bis zu 30 Sekunden)
        start = time.time()
        url = ""
        for line in proc.stdout:
            if "trycloudflare.com" in line or ".cfargotunnel.com" in line:
                import re
                m = re.search(r'https://[\w\-\.]+\.(?:trycloudflare|cfargotunnel)\.com', line)
                if m:
                    url = m.group(0)
                    break
            if time.time() - start > 30:
                break

        if url:
            save_tunnel_state("cloudflare", url, proc.pid)
            return True, url
        else:
            proc.terminate()
            return False, "Cloudflare-URL nicht ermittelt"
    except Exception as e:
        return False, str(e)


def start_ngrok_tunnel(port: int = 8501, token: str = "") -> Tuple[bool, str]:
    """Startet ngrok Tunnel."""
    ngrok_cmd = None
    for candidate in ["ngrok", "ngrok.exe",
                       str(Path.home() / ".byblos_crm" / "ngrok"),
                       str(Path.home() / ".byblos_crm" / "ngrok.exe")]:
        try:
            r = subprocess.run([candidate, "--version"], capture_output=True, timeout=3)
            if r.returncode == 0:
                ngrok_cmd = candidate
                break
        except Exception:
            pass

    if not ngrok_cmd:
        return False, "ngrok nicht gefunden"

    try:
        if token:
            subprocess.run([ngrok_cmd, "authtoken", token],
                           capture_output=True, timeout=10)

        proc = subprocess.Popen(
            [ngrok_cmd, "http", str(port)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        time.sleep(4)  # ngrok braucht Zeit

        # URL via ngrok API
        import urllib.request
        try:
            with urllib.request.urlopen("http://localhost:4040/api/tunnels", timeout=5) as r:
                data = json.loads(r.read())
                for t in data.get("tunnels", []):
                    if t.get("proto") == "https":
                        url = t["public_url"]
                        save_tunnel_state("ngrok", url, proc.pid)
                        return True, url
        except Exception:
            pass

        return False, "ngrok API nicht erreichbar"
    except Exception as e:
        return False, str(e)


def stop_tunnel() -> None:
    """Stoppt aktiven Tunnel."""
    state = load_tunnel_state()
    if state and state.get("pid"):
        try:
            import signal
            os.kill(state["pid"], signal.SIGTERM)
        except Exception:
            pass
        try:
            if platform.system() == "Windows":
                subprocess.run(["taskkill", "/F", "/IM", "cloudflared.exe"], capture_output=True)
                subprocess.run(["taskkill", "/F", "/IM", "ngrok.exe"], capture_output=True)
            else:
                subprocess.run(["pkill", "-f", "cloudflared"], capture_output=True)
                subprocess.run(["pkill", "-f", "ngrok"], capture_output=True)
        except Exception:
            pass
    clear_tunnel_state()


def download_cloudflared(dest_dir: Path) -> Tuple[bool, str]:
    """Lädt cloudflared herunter."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == "windows":
        url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
        fname = "cloudflared.exe"
    elif system == "darwin":
        url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tar.gz"
        fname = "cloudflared"
    else:
        if "arm" in machine or "aarch" in machine:
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64"
        else:
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"
        fname = "cloudflared"

    dest = dest_dir / fname
    try:
        import urllib.request
        with st.spinner(f"Lade cloudflared herunter..."):
            urllib.request.urlretrieve(url, str(dest))
        if system != "windows":
            os.chmod(str(dest), 0o755)
        return True, str(dest)
    except Exception as e:
        return False, str(e)


# ─────────────────────────────────────────────────────────────
# Haupt-Seite: Netzwerk-Zugang
# ─────────────────────────────────────────────────────────────

def page_network_access(run_fn, df_fn, get_setting_fn, set_setting_fn) -> None:
    st.title("🌐 Netzwerk & Remote-Zugang")
    st.caption("Byblos CRM vom Handy, Tablet oder jedem Gerät aus erreichbar machen.")

    PORT = int(get_setting_fn("app_port", "8501"))
    local_ip = get_local_ip()
    hostname  = get_hostname()
    lan_url   = f"http://{local_ip}:{PORT}"
    local_url = f"http://localhost:{PORT}"

    tabs = st.tabs([
        "📡 Status & QR-Code",
        "☁️ Cloudflare Tunnel",
        "🔌 ngrok Tunnel",
        "🔒 Sicherheit",
        "⚙️ Einstellungen",
        "📖 Anleitung",
    ])

    # ── Tab 0: Status ─────────────────────────────────────────
    with tabs[0]:
        # Live-Status
        app_running = is_port_open("localhost", PORT)
        c1, c2, c3 = st.columns(3)
        c1.metric("App-Status",   "🟢 Läuft"    if app_running else "🔴 Gestoppt")
        c2.metric("Lokale IP",    local_ip)
        c3.metric("Hostname",     hostname)

        st.divider()
        col1, col2 = st.columns([1, 1])

        with col1:
            st.subheader("📱 Im gleichen WLAN (Handy/Tablet)")
            st.info(f"**URL:**\n\n`{lan_url}`")
            st.markdown(generate_qr_code_svg(lan_url, 180), unsafe_allow_html=True)
            st.caption("QR-Code mit Handy-Kamera scannen")

        with col2:
            st.subheader("🌍 Aktueller Tunnel (Internet)")
            tunnel_state = load_tunnel_state()
            if tunnel_state and tunnel_state.get("url"):
                t_url = tunnel_state["url"]
                st.success(f"**Aktiver Tunnel:**\n\n`{t_url}`")
                st.markdown(generate_qr_code_svg(t_url, 180), unsafe_allow_html=True)
                st.caption(f"Anbieter: {tunnel_state.get('provider','–')} · Gestartet: {tunnel_state.get('started','–')[:16]}")
                if st.button("⛔ Tunnel beenden"):
                    stop_tunnel()
                    st.rerun()
            else:
                st.warning("Kein Tunnel aktiv")
                st.caption("Nutze Cloudflare- oder ngrok-Tab um einen Tunnel zu starten.")

        st.divider()
        # Verbindungstest
        st.subheader("🔍 Verbindungstest")
        col_a, col_b, col_c = st.columns(3)
        col_a.metric("Lokal (localhost)", "✅ OK" if is_port_open("localhost",PORT) else "❌ Offline")
        col_b.metric("LAN (WLAN)", "✅ OK" if is_port_open(local_ip,PORT) else "❌ Offline")
        pub_ip = get_public_ip()
        col_c.metric("Öffentliche IP", pub_ip)

    # ── Tab 1: Cloudflare ─────────────────────────────────────
    with tabs[1]:
        st.subheader("☁️ Cloudflare Tunnel")
        st.markdown("""
**Vorteile:**
- ✅ Komplett kostenlos
- ✅ Kein Router-Port öffnen nötig
- ✅ HTTPS automatisch
- ✅ Funktioniert hinter NAT/Firewalls
- ✅ Keine Registrierung für Quick-Tunnel

**Nachteile:**
- ⚠️ URL ändert sich bei jedem Start (Quick-Tunnel)
- ⚠️ Für feste URL: Cloudflare-Account nötig
        """)

        tool_dir = Path.home() / ".byblos_crm"
        cf_exists = any((tool_dir / cf).exists() for cf in ["cloudflared", "cloudflared.exe"])

        if not cf_exists:
            st.warning("cloudflared noch nicht installiert.")
            if st.button("⬇️ cloudflared herunterladen (kostenlos)", type="primary"):
                ok, result = download_cloudflared(tool_dir)
                if ok:
                    st.success(f"✅ cloudflared heruntergeladen: {result}")
                    st.rerun()
                else:
                    st.error(f"Download fehlgeschlagen: {result}")
                    st.info("Manuell: https://developers.cloudflare.com/cloudflared/get-started/")
        else:
            st.success("✅ cloudflared installiert")
            tunnel_active = load_tunnel_state()

            if tunnel_active and tunnel_active.get("provider") == "cloudflare":
                st.success(f"**Tunnel aktiv:** {tunnel_active['url']}")
                if st.button("⛔ Tunnel beenden"):
                    stop_tunnel()
                    st.rerun()
            else:
                col1, col2 = st.columns(2)
                cf_type = col1.selectbox("Tunnel-Art",
                    ["Quick-Tunnel (kostenlos, URL ändert sich)",
                     "Named-Tunnel (Cloudflare-Account)"])
                cf_domain = col2.text_input("Domain (optional bei Named-Tunnel)",
                                             get_setting_fn("cloudflare_domain",""))

                if st.button("🚀 Cloudflare-Tunnel starten", type="primary"):
                    with st.spinner("Tunnel wird gestartet... (bis zu 30 Sek.)"):
                        ok, result = start_cloudflare_tunnel(PORT)
                    if ok:
                        st.success(f"✅ Tunnel aktiv: {result}")
                        st.markdown(generate_qr_code_svg(result, 200), unsafe_allow_html=True)
                        st.balloons()
                    else:
                        st.error(f"Fehler: {result}")
                        st.info("Versuche ngrok als Alternative.")

    # ── Tab 2: ngrok ──────────────────────────────────────────
    with tabs[2]:
        st.subheader("🔌 ngrok Tunnel")
        st.markdown("""
**Vorteile:**
- ✅ Sehr einfach zu bedienen
- ✅ Kostenlos (begrenzt)
- ✅ HTTPS automatisch
- ✅ Stabile URL mit Auth-Token

**Kostenlos:** 1 Tunnel, zufällige URL
**Bezahlt:** Feste Subdomain, mehr Tunnel
        """)

        tool_dir = Path.home() / ".byblos_crm"
        ngrok_exists = any((tool_dir / ng).exists() for ng in ["ngrok", "ngrok.exe"])

        if not ngrok_exists:
            st.warning("ngrok nicht installiert.")
            col1, col2 = st.columns(2)
            if col1.button("⬇️ Installationsanleitung"):
                st.info("1. https://ngrok.com/download → Binary herunterladen\n2. In ~/.byblos_crm/ ablegen\n3. Hier Auth-Token eintragen")
        else:
            st.success("✅ ngrok installiert")

        saved_token = get_setting_fn("ngrok_token","")
        token = st.text_input("ngrok Auth-Token (empfohlen)", saved_token,
                               type="password",
                               help="Kostenloses Token: ngrok.com → Dashboard → Authtoken")

        if token != saved_token and token:
            set_setting_fn("ngrok_token", token)

        if ngrok_exists:
            tunnel_active = load_tunnel_state()
            if tunnel_active and tunnel_active.get("provider") == "ngrok":
                st.success(f"**Tunnel aktiv:** {tunnel_active['url']}")
                if st.button("⛔ ngrok beenden"):
                    stop_tunnel(); st.rerun()
            else:
                if st.button("🚀 ngrok-Tunnel starten", type="primary"):
                    with st.spinner("ngrok startet..."):
                        ok, result = start_ngrok_tunnel(PORT, token)
                    if ok:
                        st.success(f"✅ {result}")
                        st.markdown(generate_qr_code_svg(result, 200), unsafe_allow_html=True)
                    else:
                        st.error(f"Fehler: {result}")

    # ── Tab 3: Sicherheit ─────────────────────────────────────
    with tabs[3]:
        st.subheader("🔒 Sicherheits-Einstellungen für Remote-Zugang")

        st.warning("⚠️ Beim Remote-Zugang ist Sicherheit wichtig! Bitte konfigurieren:")

        with st.form("security_form"):
            st.subheader("IP-Whitelist (optional)")
            ip_whitelist = st.text_area(
                "Erlaubte IP-Adressen (eine pro Zeile, leer = alle erlaubt)",
                get_setting_fn("ip_whitelist",""),
                help="z.B. 192.168.1.0/24 für gesamtes Heimnetz"
            )

            st.subheader("Sitzungs-Einstellungen")
            col1, col2 = st.columns(2)
            session_timeout = col1.number_input(
                "Automatischer Logout nach (Minuten)",
                min_value=15, max_value=480,
                value=int(get_setting_fn("session_timeout_minutes","120"))
            )
            require_2fa_remote = col2.checkbox(
                "2FA für Remote-Zugang erzwingen",
                value=get_setting_fn("require_2fa_remote","0") == "1"
            )

            st.subheader("Benachrichtigungen")
            notify_remote_login = st.checkbox(
                "Bei Remote-Login per Telegram benachrichtigen",
                value=get_setting_fn("notify_remote_login","0") == "1"
            )

            if st.form_submit_button("💾 Sicherheits-Einstellungen speichern", type="primary"):
                set_setting_fn("ip_whitelist", ip_whitelist)
                set_setting_fn("session_timeout_minutes", str(session_timeout))
                set_setting_fn("require_2fa_remote", "1" if require_2fa_remote else "0")
                set_setting_fn("notify_remote_login", "1" if notify_remote_login else "0")
                st.success("✅ Gespeichert!")

        # Sicherheits-Checkliste
        st.divider()
        st.subheader("✅ Sicherheits-Checkliste")
        checks = [
            (get_setting_fn("require_2fa_remote","0")=="1", "2FA für Remote-Zugang aktiv"),
            (get_setting_fn("session_timeout_minutes","480") != "480", "Automatischer Logout konfiguriert"),
            (bool(get_setting_fn("ip_whitelist","")), "IP-Whitelist definiert (optional)"),
            (bool(get_setting_fn("telegram_token","")), "Telegram-Benachrichtigungen aktiv"),
        ]
        for ok, label in checks:
            st.markdown(f"{'✅' if ok else '⚠️'} {label}")

    # ── Tab 4: Einstellungen ──────────────────────────────────
    with tabs[4]:
        st.subheader("⚙️ App-Einstellungen")
        with st.form("app_settings"):
            col1, col2 = st.columns(2)
            new_port = col1.number_input("App-Port", min_value=1024,
                                          max_value=65535, value=PORT)
            bind_addr = col2.selectbox("Bind-Adresse",
                ["localhost (nur lokal)", "0.0.0.0 (LAN + Internet)"],
                index=0 if get_setting_fn("app_bind","localhost") == "localhost" else 1)

            st.info("""
**Bind-Adresse Erklärung:**
- `localhost` = Nur auf diesem PC erreichbar (sicher)
- `0.0.0.0` = Alle Netzwerk-Schnittstellen (LAN-Zugang ohne Tunnel)
            """)

            dyndns_domain = st.text_input("DynDNS-Domain (optional)",
                                            get_setting_fn("dyndns_domain",""),
                                            placeholder="crm.beispiel.dyndns.org")
            dyndns_provider = st.selectbox("DynDNS-Anbieter",
                ["–", "DuckDNS", "No-IP", "DynDNS", "Strato DynDNS"])

            if st.form_submit_button("💾 Speichern und Neustart", type="primary"):
                set_setting_fn("app_port", str(new_port))
                bind = "localhost" if "localhost" in bind_addr else "0.0.0.0"
                set_setting_fn("app_bind", bind)
                set_setting_fn("dyndns_domain", dyndns_domain)
                set_setting_fn("dyndns_provider", dyndns_provider)
                st.success(f"✅ Gespeichert. Bitte App neu starten für Port-Änderung.")

                if dyndns_domain:
                    st.info(f"DynDNS URL: http://{dyndns_domain}:{new_port}")

    # ── Tab 5: Anleitung ──────────────────────────────────────
    with tabs[5]:
        st.subheader("📖 Schritt-für-Schritt Anleitung")

        with st.expander("📱 Handy im gleichen WLAN (einfachste Methode)", expanded=True):
            st.markdown(f"""
**Voraussetzung:** Handy und PC im selben WLAN

**Schritt 1:** App auf PC starten (`DIREKTINSTALL.bat` → `ByblosCRM_Starten.bat`)

**Schritt 2:** Diese URL auf dem Handy öffnen:
```
{lan_url}
```

**Schritt 3:** QR-Code mit Kamera scannen (im Tab "Status & QR-Code")

**Fertig!** ✅ Kein Router-Setup nötig.
            """)

        with st.expander("🌍 Von überall (anderes WLAN / Mobilfunk)"):
            st.markdown("""
**Methode 1: Cloudflare Quick-Tunnel (empfohlen, kostenlos)**

1. Tab "☁️ Cloudflare Tunnel" → cloudflared herunterladen
2. "Tunnel starten" klicken
3. Generierte HTTPS-URL auf Handy öffnen
4. Fertig! URL ist ~8 Stunden gültig

**Methode 2: ngrok**

1. ngrok.com → kostenlos registrieren → Auth-Token kopieren
2. Tab "🔌 ngrok" → Token eintragen → Tunnel starten
3. URL auf Handy öffnen

**Methode 3: Router-Port-Weiterleitung (für dauerhaften Zugang)**

1. Router-Admin öffnen (meist 192.168.1.1 oder 192.168.0.1)
2. "Port-Weiterleitung" → Port 8501 → zu PC-IP {get_local_ip()}
3. DynDNS einrichten (z.B. DuckDNS.org kostenlos)
4. URL: `http://deine-domain.duckdns.org:8501`
            """.replace("{get_local_ip()}", get_local_ip()))

        with st.expander("🔐 Sicherheits-Tipps für Remote-Zugang"):
            st.markdown("""
**Wichtig bei Internet-Zugang:**

1. **Passwort ändern** — Standard `admin123` ist unsicher!
   → Einstellungen → Benutzer & Rollen

2. **2FA aktivieren** — Doppelte Absicherung
   → Sicherheit → Zwei-Faktor-Auth

3. **Tunnel bevorzugen** — Cloudflare/ngrok sind sicherer als Port-Weiterleitung

4. **Automatischer Logout** — 120 Minuten Inaktivität
   → Tab "Sicherheit" hier konfigurieren

5. **Kein öffentliches WLAN** — App nur über verschlüsselte Verbindung nutzen
            """)

        with st.expander("🖥️ Dauerhafter Server (für Unternehmen)"):
            st.markdown("""
**Auf Server (VPS) deployen:**

```bash
# Server: Ubuntu 22.04 (z.B. Hetzner CX11 = 4€/Monat)
git clone https://github.com/... # oder ZIP hochladen
cd byblos_crm_v2
./INSTALL_LINUX_MAC.sh

# Mit HTTPS (Let's Encrypt):
docker compose --profile production up -d

# Zugang: https://ihre-domain.de
```

**Empfohlene Anbieter:**
- **Hetzner** (Deutschland): ab 3,90 €/Monat, DSGVO-konform
- **Netcup**: ab 2,99 €/Monat
- **Contabo**: ab 4,99 €/Monat
            """)
