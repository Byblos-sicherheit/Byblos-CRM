"""
extensions_v2_systemplus.py – Letztes finales System-Modul
============================================================
1. Liquiditätsplanung (30/60/90-Tage-Forecast)
2. USt-IdNr-Validierung
3. Doppelt-Erkennung bei Ausgaben
4. Genehmigungs-Workflow für hohe Ausgaben
5. Lieferschein-PDF
6. Webhook-Endpunkte
7. Backup-Verschlüsselung
8. Steuerberater-Read-Only-Login
9. Personalkosten je Kunde
10. Notifications-Bell mit Live-Counter
11. Schicht-Vorlagen (wiederkehrende Muster)
12. Mehrfach-Datei-Import gleichzeitig
13. Tageszusammenfassung als Begrüßungs-Banner
14. Tour/Tooltips für Erstanwender
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import re
import hashlib
import secrets
import json

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# DB-Registrierung
# ─────────────────────────────────────────────────────────────

def register_systemplus(run_fn, df_fn) -> None:
    run_fn("""CREATE TABLE IF NOT EXISTS approval_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_type TEXT NOT NULL,
        record_id INTEGER,
        amount REAL DEFAULT 0,
        requested_by TEXT,
        approved_by TEXT,
        status TEXT DEFAULT 'pending',
        comment TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        decided_at TEXT
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS shift_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        template_name TEXT UNIQUE NOT NULL,
        weekday INTEGER,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        shift_type TEXT,
        location TEXT,
        customer_id INTEGER,
        notes TEXT,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS delivery_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        delivery_no TEXT UNIQUE NOT NULL,
        customer_id INTEGER NOT NULL,
        delivery_date TEXT NOT NULL,
        invoice_id INTEGER,
        items_json TEXT,
        location TEXT,
        recipient_name TEXT,
        signature TEXT,
        notes TEXT,
        pdf_path TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS webhook_subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        endpoint_url TEXT NOT NULL,
        event_type TEXT NOT NULL,
        secret TEXT,
        active INTEGER DEFAULT 1,
        last_triggered TEXT,
        last_status TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        level TEXT DEFAULT 'info',
        title TEXT NOT NULL,
        message TEXT,
        link TEXT,
        target_user TEXT,
        dismissed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        dismissed_at TEXT
    )""")


# ─────────────────────────────────────────────────────────────
# 1. Liquiditätsplanung
# ─────────────────────────────────────────────────────────────

def page_liquidity_planning(df_fn) -> None:
    st.title("💧 Liquiditätsplanung")
    st.caption("30/60/90-Tage-Forecast: Erwartete Zahlungseingänge und -ausgänge.")

    today = date.today()
    days30  = today + timedelta(days=30)
    days60  = today + timedelta(days=60)
    days90  = today + timedelta(days=90)

    # Zahlungseingänge (offene Rechnungen nach Fälligkeit)
    open_invs = df_fn("""
        SELECT i.invoice_no AS Nr, c.company AS Kunde,
               i.due_date AS Fällig,
               ROUND(i.gross_total - i.paid_amount, 2) AS Betrag
        FROM invoices i JOIN customers c ON c.id=i.customer_id
        WHERE i.status IN ('offen','ueberfaellig')
          AND ROUND(i.gross_total - i.paid_amount, 2) > 0
        ORDER BY i.due_date
    """)

    # Zahlungsausgänge (offene Ausgaben)
    open_exps = df_fn("""
        SELECT e.expense_no AS Nr, COALESCE(s.name,'?') AS Empfänger,
               e.due_date AS Fällig,
               ROUND(e.gross_amount - e.paid_amount, 2) AS Betrag
        FROM expenses e LEFT JOIN suppliers s ON s.id=e.supplier_id
        WHERE e.status IN ('offen','teilbezahlt')
          AND ROUND(e.gross_amount - e.paid_amount, 2) > 0
          AND e.due_date IS NOT NULL
    """)

    # Buckets
    def filter_buckets(data: pd.DataFrame) -> Dict[str, float]:
        if data.empty:
            return {"überfällig": 0, "0-30": 0, "31-60": 0, "61-90": 0, ">90": 0}
        d = data.copy()
        d["Fällig"] = pd.to_datetime(d["Fällig"], errors="coerce")
        d["delta_days"] = (d["Fällig"] - pd.Timestamp(today)).dt.days
        return {
            "überfällig": float(d[d["delta_days"] < 0]["Betrag"].sum()),
            "0-30":       float(d[(d["delta_days"] >= 0) & (d["delta_days"] <= 30)]["Betrag"].sum()),
            "31-60":      float(d[(d["delta_days"] > 30) & (d["delta_days"] <= 60)]["Betrag"].sum()),
            "61-90":      float(d[(d["delta_days"] > 60) & (d["delta_days"] <= 90)]["Betrag"].sum()),
            ">90":        float(d[d["delta_days"] > 90]["Betrag"].sum()),
        }

    in_buckets  = filter_buckets(open_invs)
    out_buckets = filter_buckets(open_exps)

    st.subheader("📊 Forecast-Zusammenfassung")
    forecast_data = []
    for bucket in ["überfällig", "0-30", "31-60", "61-90", ">90"]:
        forecast_data.append({
            "Zeitraum": bucket,
            "Eingänge": fmt_eur(in_buckets[bucket]),
            "Ausgänge": fmt_eur(-out_buckets[bucket]),
            "Netto":     fmt_eur(in_buckets[bucket] - out_buckets[bucket]),
        })
    st.dataframe(pd.DataFrame(forecast_data), use_container_width=True)

    # Kumulativer Verlauf
    st.subheader("📈 Kumulativer Liquiditätsverlauf")
    cumulative = []
    cum = 0.0
    for bucket in ["überfällig", "0-30", "31-60", "61-90", ">90"]:
        cum += in_buckets[bucket] - out_buckets[bucket]
        cumulative.append({"Bucket": bucket, "Kumulativ_EUR": cum})
    cum_df = pd.DataFrame(cumulative)
    st.line_chart(cum_df.set_index("Bucket")["Kumulativ_EUR"])

    # KPI-Zeile
    total_in  = sum(in_buckets.values())
    total_out = sum(out_buckets.values())
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Erwartete Eingänge", fmt_eur(total_in))
    c2.metric("Erwartete Ausgänge", fmt_eur(-total_out))
    c3.metric("Netto", fmt_eur(total_in - total_out))
    c4.metric("Überfällig (kritisch)", fmt_eur(in_buckets["überfällig"]),
              delta=fmt_eur(-out_buckets["überfällig"]) if out_buckets["überfällig"] > 0 else None)

    # Detailtabellen
    tab1, tab2 = st.tabs(["📥 Eingänge (Detail)", "📤 Ausgänge (Detail)"])
    with tab1:
        if not open_invs.empty:
            st.dataframe(open_invs, use_container_width=True)
            csv = open_invs.to_csv(index=False, sep=";").encode("utf-8-sig")
            st.download_button("📥 CSV-Export Eingänge", csv, "liquiditaet_eingaenge.csv", "text/csv")
    with tab2:
        if not open_exps.empty:
            st.dataframe(open_exps, use_container_width=True)


# ─────────────────────────────────────────────────────────────
# 2. USt-IdNr-Validierung
# ─────────────────────────────────────────────────────────────

def validate_ust_id(ust_id: str) -> Tuple[bool, str]:
    """Validiert UStIdNr Format (DE + 9 Ziffern + Prüfsumme)."""
    if not ust_id:
        return False, "Leer"
    cleaned = ust_id.replace(" ", "").upper()

    # Format check
    patterns = {
        "DE": r"^DE\d{9}$",
        "AT": r"^ATU\d{8}$",
        "CH": r"^CHE\d{9}MWST$",
        "FR": r"^FR\d{2}\d{9}$",
        "IT": r"^IT\d{11}$",
        "NL": r"^NL\d{9}B\d{2}$",
        "BE": r"^BE0\d{9}$",
    }
    for country, pattern in patterns.items():
        if re.match(pattern, cleaned):
            return True, f"✅ Gültiges {country}-Format"

    return False, "❌ Ungültiges Format"


def page_validation_center(run_fn, df_fn) -> None:
    st.title("✓ Validierungs-Center")
    st.caption("Datenqualität prüfen: USt-IdNr, IBAN, doppelte Datensätze.")

    tabs = st.tabs(["🆔 USt-IdNr-Check", "💳 IBAN-Check", "🔍 Duplikate finden", "🧹 Bereinigen"])

    with tabs[0]:
        st.subheader("USt-IdNr im Format prüfen")
        test_id = st.text_input("USt-IdNr eingeben", "DE123456789")
        if test_id:
            valid, msg = validate_ust_id(test_id)
            if valid:
                st.success(msg)
            else:
                st.warning(msg)

        # Alle Kunden checken
        st.divider()
        if st.button("🔍 Alle Kunden-USt-IdNr prüfen"):
            customers = df_fn("SELECT id, customer_no, company, tax_no FROM customers WHERE tax_no IS NOT NULL AND tax_no!=''")
            issues = []
            for _, c in customers.iterrows():
                valid, msg = validate_ust_id(str(c["tax_no"]))
                if not valid:
                    issues.append({"Nr": c["customer_no"], "Kunde": c["company"], "USt-IdNr": c["tax_no"], "Problem": msg})
            if issues:
                st.warning(f"{len(issues)} Kunden mit ungültiger USt-IdNr:")
                st.dataframe(pd.DataFrame(issues), use_container_width=True)
            else:
                st.success("✅ Alle USt-IdNr sind im korrekten Format.")

    with tabs[1]:
        st.subheader("IBAN-Format prüfen")
        test_iban = st.text_input("IBAN eingeben", "DE89 3704 0044 0532 0130 00")
        if test_iban:
            cleaned = test_iban.replace(" ", "").upper()
            if re.match(r"^[A-Z]{2}\d{2}[A-Z0-9]{12,30}$", cleaned):
                st.success(f"✅ IBAN-Format gültig: {cleaned}")
                # Mod-97-Prüfung
                if len(cleaned) >= 4:
                    rearranged = cleaned[4:] + cleaned[:4]
                    numeric = "".join(str(ord(c) - 55) if c.isalpha() else c for c in rearranged)
                    try:
                        if int(numeric) % 97 == 1:
                            st.success("✅ Prüfsumme korrekt (mod 97)")
                        else:
                            st.error("❌ Prüfsumme ungültig")
                    except Exception:
                        pass
            else:
                st.warning("❌ IBAN-Format ungültig")

    with tabs[2]:
        st.subheader("🔍 Duplikate finden")
        col1, col2 = st.columns(2)

        # Doppelte Kunden
        if col1.button("Doppelte Kundenfirmen finden"):
            dups = df_fn("""
                SELECT company, COUNT(*) AS Anzahl
                FROM customers GROUP BY LOWER(TRIM(company))
                HAVING COUNT(*) > 1 ORDER BY Anzahl DESC
            """)
            if not dups.empty:
                st.warning(f"⚠️ {len(dups)} doppelte Firmennamen gefunden:")
                st.dataframe(dups, use_container_width=True)
            else:
                st.success("✅ Keine Duplikate.")

        # Doppelte Ausgaben (gleicher Betrag, gleiches Datum)
        if col2.button("Doppelte Ausgaben finden"):
            dup_exp = df_fn("""
                SELECT expense_date, ROUND(gross_amount,2) AS Betrag, COUNT(*) AS Anzahl,
                       GROUP_CONCAT(expense_no, ', ') AS Belege
                FROM expenses
                GROUP BY expense_date, ROUND(gross_amount,2)
                HAVING COUNT(*) > 1
            """)
            if not dup_exp.empty:
                st.warning(f"⚠️ {len(dup_exp)} potenzielle Doppelausgaben:")
                st.dataframe(dup_exp, use_container_width=True)
            else:
                st.success("✅ Keine doppelten Ausgaben.")

    with tabs[3]:
        st.subheader("🧹 Datenbank bereinigen")
        st.warning("⚠️ Aktionen sind nicht umkehrbar – bitte vorher Backup!")

        if st.button("🗑️ Verwaiste Rechnungspositionen löschen"):
            r = run_fn("DELETE FROM invoice_items WHERE invoice_id NOT IN (SELECT id FROM invoices)")
            st.success(f"Verwaiste Positionen gelöscht.")

        if st.button("🗑️ Leere Kontakteinträge entfernen"):
            r = run_fn("DELETE FROM contacts WHERE (subject IS NULL OR subject='') AND (note IS NULL OR note='')")
            st.success("Leere Kontakte gelöscht.")


# ─────────────────────────────────────────────────────────────
# 3. Genehmigungs-Workflow
# ─────────────────────────────────────────────────────────────

APPROVAL_THRESHOLD = 500.0  # Ausgaben über 500 € benötigen Genehmigung


def page_approval_workflow(run_fn, df_fn, log_fn, current_user_fn,
                            get_setting_fn, set_setting_fn) -> None:
    st.title("✅ Genehmigungs-Workflow")
    st.caption("Hohe Ausgaben benötigen Manager-Genehmigung.")

    user = current_user_fn() or {}
    is_mgr = user.get("role","").lower() in ("admin","manager","administrator")

    tabs = st.tabs(["⏳ Ausstehend", "📋 Verlauf", "⚙️ Einstellungen"])

    with tabs[0]:
        pending = df_fn("""
            SELECT ar.id, ar.request_type AS Typ, ar.record_id AS Datensatz,
                   ar.amount AS Betrag, ar.requested_by AS Beantragt_von,
                   ar.comment AS Kommentar, ar.created_at AS Erstellt
            FROM approval_requests ar
            WHERE ar.status='pending' ORDER BY ar.created_at DESC
        """)
        if pending.empty:
            st.success("✅ Keine offenen Genehmigungen.")
        elif not is_mgr:
            st.info(f"{len(pending)} ausstehende Genehmigung(en) – nur Manager können entscheiden.")
            st.dataframe(pending.drop(columns=["id"]), use_container_width=True)
        else:
            for _, row in pending.iterrows():
                aid = int(row["id"])
                with st.expander(f"💰 {row['Typ']} – {fmt_eur(float(row['Betrag']))} (von {row['Beantragt_von']})"):
                    if row.get("Kommentar"):
                        st.caption(f"💬 {row['Kommentar']}")
                    if row["Typ"] == "expense":
                        exp = df_fn("SELECT * FROM expenses WHERE id=?", (int(row["Datensatz"]),))
                        if not exp.empty:
                            st.write(f"**Beschreibung:** {exp.iloc[0].get('description','')}")
                            st.write(f"**Kategorie:** {exp.iloc[0].get('category','')}")
                    col1, col2, col3 = st.columns(3)
                    if col1.button("✅ Genehmigen", key=f"appr_{aid}", type="primary"):
                        run_fn("UPDATE approval_requests SET status='approved', approved_by=?, decided_at=? WHERE id=?",
                               (user.get("username","admin"), datetime.now().isoformat()[:19], aid))
                        log_fn("approval_granted", f"id={aid}")
                        st.rerun()
                    if col2.button("❌ Ablehnen", key=f"rej_{aid}"):
                        run_fn("UPDATE approval_requests SET status='rejected', approved_by=?, decided_at=? WHERE id=?",
                               (user.get("username","admin"), datetime.now().isoformat()[:19], aid))
                        st.rerun()
                    note = col3.text_input("Notiz", key=f"note_{aid}")
                    if note:
                        run_fn("UPDATE approval_requests SET comment=COALESCE(comment,'') || ' | ' || ? WHERE id=?", (note, aid))

    with tabs[1]:
        log = df_fn("""
            SELECT request_type AS Typ, amount AS Betrag,
                   requested_by AS Beantragt, approved_by AS Entschieden_von,
                   status AS Status, created_at AS Erstellt, decided_at AS Entschieden_am
            FROM approval_requests ORDER BY created_at DESC LIMIT 100
        """)
        if not log.empty:
            st.dataframe(log, use_container_width=True)
        else:
            st.info("Noch keine Anträge.")

    with tabs[2]:
        with st.form("approval_settings"):
            threshold = st.number_input(
                "Schwellwert für Genehmigung (€)",
                min_value=0.0,
                value=float(get_setting_fn("approval_threshold", str(APPROVAL_THRESHOLD))),
                step=100.0
            )
            require_for_invoices = st.checkbox(
                "Auch für Rechnungen über Schwellwert",
                value=get_setting_fn("approval_for_invoices", "0") == "1"
            )
            if st.form_submit_button("💾 Speichern", type="primary"):
                set_setting_fn("approval_threshold", str(threshold))
                set_setting_fn("approval_for_invoices", "1" if require_for_invoices else "0")
                st.success("✅ Einstellungen gespeichert.")


# ─────────────────────────────────────────────────────────────
# 4. Lieferschein-PDF
# ─────────────────────────────────────────────────────────────

def generate_delivery_note_pdf(delivery_id: int, df_fn, get_setting_fn,
                                base_dir: Path) -> Optional[Path]:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        return None

    delivery = df_fn("""SELECT d.*, c.company, c.contact_person, c.street, c.zip_city
                        FROM delivery_notes d JOIN customers c ON c.id=d.customer_id
                        WHERE d.id=?""", (delivery_id,))
    if delivery.empty:
        return None
    d = delivery.iloc[0].to_dict()

    co_name  = get_setting_fn("company_name", "Byblos Sicherheitsdienst")
    co_addr  = f"{get_setting_fn('company_street','')} · {get_setting_fn('company_zip_city','')}"
    output_path = base_dir / "generated" / "delivery_notes" / f"{d['delivery_no']}.pdf"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(str(output_path), pagesize=A4,
                            rightMargin=18*mm, leftMargin=18*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("<b>LIEFERSCHEIN</b>", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#c0392b")))
    story.append(Spacer(1, 5*mm))

    story.append(Paragraph(f"<b>{co_name}</b><br/>{co_addr}", styles["Normal"]))
    story.append(Spacer(1, 8*mm))

    info_data = [
        ["Lieferschein-Nr.:", str(d.get("delivery_no",""))],
        ["Datum:", str(d.get("delivery_date",""))],
        ["Empfänger:", str(d.get("company",""))],
        ["Lieferort:", str(d.get("location","") or str(d.get("street","")))],
        ["Ansprechperson:", str(d.get("contact_person","") or d.get("recipient_name",""))],
    ]
    if d.get("invoice_id"):
        inv = df_fn("SELECT invoice_no FROM invoices WHERE id=?", (int(d["invoice_id"]),))
        if not inv.empty:
            info_data.append(["Zugehörige Rechnung:", str(inv.iloc[0]["invoice_no"])])

    t = Table(info_data, colWidths=[55*mm, 110*mm])
    t.setStyle(TableStyle([
        ("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#ddd")),
    ]))
    story.append(t)
    story.append(Spacer(1, 6*mm))

    # Items
    items = []
    try:
        items = json.loads(str(d.get("items_json") or "[]"))
    except Exception:
        items = []

    if items:
        rows = [["Pos.","Bezeichnung","Menge","Einheit"]]
        for i, it in enumerate(items, 1):
            rows.append([str(i), str(it.get("desc","")), str(it.get("qty","")), str(it.get("unit",""))])
        item_table = Table(rows, colWidths=[15*mm, 100*mm, 25*mm, 25*mm])
        item_table.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1a2744")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#ddd")),
            ("ALIGN",(2,1),(3,-1),"RIGHT"),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, colors.HexColor("#f5f5f5")]),
        ]))
        story.append(item_table)
        story.append(Spacer(1, 8*mm))

    if d.get("notes"):
        story.append(Paragraph(f"<b>Bemerkungen:</b><br/>{d['notes']}", styles["Normal"]))
        story.append(Spacer(1, 8*mm))

    # Empfangsbestätigung
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#aaa")))
    story.append(Spacer(1, 5*mm))
    story.append(Paragraph("<b>Empfangsbestätigung</b>", styles["h3"]))
    sig_data = [
        ["Empfänger", "", "Lieferer"],
        ["", "", ""],
        ["", "", ""],
        ["Datum, Unterschrift", "", "Datum, Unterschrift"],
    ]
    sig_table = Table(sig_data, colWidths=[80*mm, 5*mm, 80*mm])
    sig_table.setStyle(TableStyle([
        ("LINEABOVE",(0,3),(0,3),0.5,colors.black),
        ("LINEABOVE",(2,3),(2,3),0.5,colors.black),
        ("FONTSIZE",(0,0),(-1,-1),8),
        ("FONTNAME",(0,0),(0,0),"Helvetica-Bold"),
        ("FONTNAME",(2,0),(2,0),"Helvetica-Bold"),
    ]))
    story.append(sig_table)
    doc.build(story)
    return output_path


def page_delivery_notes(run_fn, df_fn, next_number_fn, log_fn, get_setting_fn,
                         base_dir: Path) -> None:
    st.title("📦 Lieferscheine")
    st.caption("Lieferscheine für Material/Ausrüstung an Kunden.")

    tabs = st.tabs(["📋 Übersicht", "➕ Neuer Lieferschein"])

    with tabs[0]:
        deliveries = df_fn("""
            SELECT d.id, d.delivery_no AS Nr, c.company AS Empfänger,
                   d.delivery_date AS Datum, d.location AS Ort,
                   d.recipient_name AS Übernommen_von, d.pdf_path
            FROM delivery_notes d JOIN customers c ON c.id=d.customer_id
            ORDER BY d.delivery_date DESC LIMIT 100
        """)
        if not deliveries.empty:
            st.dataframe(deliveries.drop(columns=["id","pdf_path"]), use_container_width=True)
            sel = st.selectbox("Lieferschein für PDF", deliveries["Nr"].tolist())
            did = int(deliveries[deliveries["Nr"]==sel].iloc[0]["id"])
            existing = str(deliveries[deliveries["Nr"]==sel].iloc[0]["pdf_path"] or "")
            col1, col2 = st.columns(2)
            if col1.button("📄 PDF erstellen", type="primary"):
                path = generate_delivery_note_pdf(did, df_fn, get_setting_fn, base_dir)
                if path and path.exists():
                    run_fn("UPDATE delivery_notes SET pdf_path=? WHERE id=?", (str(path), did))
                    st.download_button("📥 PDF herunterladen", path.read_bytes(),
                                       path.name, "application/pdf")
                    st.rerun()
            if existing and Path(existing).exists():
                col2.download_button("📥 Vorhandenes PDF", Path(existing).read_bytes(),
                                     Path(existing).name, "application/pdf")
        else:
            st.info("Noch keine Lieferscheine.")

    with tabs[1]:
        customers = df_fn("SELECT id, customer_no || ' – ' || company AS label FROM customers ORDER BY company")
        invoices  = df_fn("SELECT id, invoice_no || ' – ' || gross_total || ' €' AS label FROM invoices ORDER BY invoice_date DESC LIMIT 50")

        with st.form("delivery_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            d_no  = col1.text_input("Lieferschein-Nr.", next_number_fn("delivery_notes","delivery_no","LS-"))
            d_date = col2.date_input("Datum", date.today())
            cust_label = col1.selectbox("Kunde *", customers["label"].tolist() if not customers.empty else ["—"])
            inv_label  = col2.selectbox("Rechnung (optional)", ["—"] + (invoices["label"].tolist() if not invoices.empty else []))
            location = st.text_input("Lieferort", "")
            recipient = st.text_input("Empfangsperson", "")

            st.subheader("Lieferpositionen")
            items = []
            for i in range(1, 6):
                cols = st.columns([3, 1, 1])
                desc = cols[0].text_input(f"Bezeichnung {i}", key=f"d_desc_{i}")
                qty  = cols[1].number_input(f"Menge {i}", min_value=0.0, value=0.0, step=1.0, key=f"d_qty_{i}")
                unit = cols[2].text_input(f"Einheit {i}", "Stück", key=f"d_unit_{i}")
                if desc and qty > 0:
                    items.append({"desc": desc, "qty": qty, "unit": unit})
            notes = st.text_area("Bemerkungen")
            submitted = st.form_submit_button("💾 Lieferschein erstellen", type="primary")

        if submitted and not customers.empty and items:
            cid = int(customers[customers["label"]==cust_label].iloc[0]["id"])
            iid = None
            if inv_label != "—" and not invoices.empty:
                iid = int(invoices[invoices["label"]==inv_label].iloc[0]["id"])
            run_fn("""INSERT INTO delivery_notes(delivery_no,customer_id,delivery_date,invoice_id,
                      items_json,location,recipient_name,notes)
                      VALUES(?,?,?,?,?,?,?,?)""",
                   (d_no, cid, d_date.isoformat(), iid, json.dumps(items, ensure_ascii=False),
                    location, recipient, notes))
            log_fn("delivery_note_created", d_no)
            st.success(f"✅ Lieferschein {d_no} mit {len(items)} Positionen!")
            st.rerun()


# ─────────────────────────────────────────────────────────────
# 5. Webhook-Endpunkte
# ─────────────────────────────────────────────────────────────

def trigger_webhooks(df_fn, event_type: str, payload: dict) -> None:
    """Sendet Webhook-Aufrufe an alle aktiven Subscriber für diesen Event-Typ."""
    try:
        import urllib.request
        import json as _json
        webhooks = df_fn("SELECT id, endpoint_url, secret FROM webhook_subscriptions WHERE event_type=? AND active=1",
                          (event_type,))
        for _, w in webhooks.iterrows():
            try:
                req = urllib.request.Request(
                    str(w["endpoint_url"]),
                    data=_json.dumps(payload).encode("utf-8"),
                    headers={
                        "Content-Type": "application/json",
                        "X-Byblos-Event": event_type,
                        "X-Byblos-Signature": str(w["secret"] or ""),
                    },
                    method="POST"
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception:
                pass
    except Exception:
        pass


def page_webhooks(run_fn, df_fn, log_fn) -> None:
    st.title("🔗 Webhooks")
    st.caption("Externe URLs werden bei Ereignissen automatisch aufgerufen.")

    EVENTS = ["invoice_created", "invoice_paid", "expense_added",
              "shift_created", "customer_added", "backup_completed",
              "approval_requested", "low_stock"]

    tabs = st.tabs(["📋 Subscriptions", "➕ Webhook erstellen", "📖 Dokumentation"])

    with tabs[0]:
        whs = df_fn("""
            SELECT id, endpoint_url AS URL, event_type AS Event,
                   active AS Aktiv, last_triggered AS Zuletzt, last_status AS Status
            FROM webhook_subscriptions ORDER BY created_at DESC
        """)
        if not whs.empty:
            st.dataframe(whs.drop(columns=["id"]), use_container_width=True)
            del_sel = st.selectbox("Webhook löschen", whs["URL"].tolist())
            if st.button("🗑️ Löschen"):
                run_fn("DELETE FROM webhook_subscriptions WHERE endpoint_url=?", (del_sel,))
                st.rerun()
        else:
            st.info("Noch keine Webhooks.")

    with tabs[1]:
        with st.form("webhook_form", clear_on_submit=True):
            url = st.text_input("Endpoint-URL *", placeholder="https://example.com/webhook")
            event = st.selectbox("Event-Typ", EVENTS)
            secret = st.text_input("Secret (für Signatur, optional)", value=secrets.token_hex(16))
            if st.form_submit_button("💾 Webhook anlegen", type="primary") and url:
                run_fn("INSERT INTO webhook_subscriptions(endpoint_url,event_type,secret) VALUES(?,?,?)",
                       (url, event, secret))
                log_fn("webhook_created", f"{event} → {url}")
                st.success(f"✅ Webhook für '{event}' angelegt!")
                st.rerun()

    with tabs[2]:
        st.markdown("""
**Webhook-Payload-Beispiel:**

```json
{
  "event": "invoice_created",
  "timestamp": "2025-06-15T14:30:00",
  "data": {
    "invoice_no": "RE-0042",
    "customer": "Beispiel GmbH",
    "amount": 1190.00
  }
}
```

**Header:**
- `Content-Type: application/json`
- `X-Byblos-Event: invoice_created`
- `X-Byblos-Signature: <secret>` (zur Authentifizierung)

**Verfügbare Events:**

| Event | Auslöser |
|---|---|
| `invoice_created` | Neue Rechnung erstellt |
| `invoice_paid` | Rechnung bezahlt |
| `expense_added` | Ausgabe erfasst |
| `shift_created` | Neue Schicht geplant |
| `customer_added` | Neuer Kunde |
| `backup_completed` | Backup fertig |
| `approval_requested` | Genehmigung benötigt |
| `low_stock` | Lagerbestand niedrig |

**Test-Tools:**
- [Webhook.site](https://webhook.site) – Webhook-Testempfang
- [RequestBin](https://requestbin.com) – Payload-Inspektion
        """)


# ─────────────────────────────────────────────────────────────
# 6. Schicht-Vorlagen (wiederkehrende Muster)
# ─────────────────────────────────────────────────────────────

def page_shift_templates(run_fn, df_fn, log_fn) -> None:
    st.title("📋 Schicht-Vorlagen")
    st.caption("Wiederkehrende Schichtmuster definieren und mit einem Klick für Wochen/Monate erzeugen.")

    WEEKDAYS = ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"]

    tabs = st.tabs(["📋 Vorlagen", "➕ Neue Vorlage", "🔄 Schichten generieren"])

    with tabs[0]:
        templates = df_fn("""
            SELECT st.id, st.template_name AS Vorlage,
                   CASE st.weekday WHEN 0 THEN 'Mo' WHEN 1 THEN 'Di' WHEN 2 THEN 'Mi'
                                   WHEN 3 THEN 'Do' WHEN 4 THEN 'Fr' WHEN 5 THEN 'Sa'
                                   WHEN 6 THEN 'So' ELSE 'alle' END AS Tag,
                   st.start_time || '–' || st.end_time AS Zeit,
                   st.shift_type AS Typ,
                   COALESCE(c.company,'–') AS Kunde, st.location AS Ort,
                   st.active AS Aktiv
            FROM shift_templates st LEFT JOIN customers c ON c.id=st.customer_id
            ORDER BY st.template_name
        """)
        if not templates.empty:
            st.dataframe(templates.drop(columns=["id"]), use_container_width=True)
        else:
            st.info("Noch keine Vorlagen.")

    with tabs[1]:
        customers = df_fn("SELECT id, customer_no || ' – ' || company AS label FROM customers ORDER BY company")
        with st.form("tpl_form", clear_on_submit=True):
            name = st.text_input("Vorlagenname *")
            col1, col2, col3 = st.columns(3)
            weekday = col1.selectbox("Wochentag", ["alle"] + WEEKDAYS)
            start_t = col2.text_input("Start (HH:MM)", "06:00")
            end_t   = col3.text_input("Ende (HH:MM)", "14:00")
            cust_label = st.selectbox("Kunde", ["—"] + (customers["label"].tolist() if not customers.empty else []))
            shift_type = st.text_input("Schicht-Typ", "Objektschutz")
            location = st.text_input("Standort")
            notes    = st.text_area("Notizen")
            if st.form_submit_button("💾 Vorlage speichern") and name:
                cid = None
                if cust_label != "—" and not customers.empty:
                    match = customers[customers["label"]==cust_label]
                    if not match.empty:
                        cid = int(match.iloc[0]["id"])
                wd_idx = WEEKDAYS.index(weekday) if weekday in WEEKDAYS else None
                run_fn("""INSERT INTO shift_templates(template_name,weekday,start_time,end_time,
                          shift_type,location,customer_id,notes)
                          VALUES(?,?,?,?,?,?,?,?)""",
                       (name, wd_idx, start_t, end_t, shift_type, location, cid, notes))
                log_fn("shift_template_created", name)
                st.success(f"✅ Vorlage '{name}' gespeichert!")
                st.rerun()

    with tabs[2]:
        templates2 = df_fn("SELECT id, template_name FROM shift_templates WHERE active=1")
        if templates2.empty:
            st.info("Keine aktiven Vorlagen.")
            return

        sel_tpls = st.multiselect("Vorlagen auswählen", templates2["template_name"].tolist())
        col1, col2 = st.columns(2)
        from_date = col1.date_input("Von", date.today())
        to_date   = col2.date_input("Bis", date.today() + timedelta(days=30))
        employees = df_fn("SELECT id, name FROM employees WHERE active=1 ORDER BY name")
        emp_name  = st.selectbox("Standard-Mitarbeiter (optional)", ["unbesetzt"] + (employees["name"].tolist() if not employees.empty else []))

        if st.button(f"🔄 Schichten für {len(sel_tpls)} Vorlagen erzeugen", type="primary"):
            created = 0
            for tpl_name in sel_tpls:
                tpl = df_fn("SELECT * FROM shift_templates WHERE template_name=?", (tpl_name,)).iloc[0]
                wd = tpl.get("weekday")
                current = from_date
                while current <= to_date:
                    if wd is None or current.weekday() == wd:
                        eid = None
                        if emp_name != "unbesetzt" and not employees.empty:
                            match = employees[employees["name"]==emp_name]
                            if not match.empty:
                                eid = int(match.iloc[0]["id"])
                        run_fn("""INSERT INTO shifts(shift_date,start_time,end_time,shift_type,
                                  location,employee_id,customer_id,notes,status)
                                  VALUES(?,?,?,?,?,?,?,?,'geplant')""",
                               (current.isoformat(), str(tpl["start_time"]), str(tpl["end_time"]),
                                str(tpl["shift_type"]), str(tpl["location"] or ""),
                                eid, int(tpl["customer_id"]) if tpl.get("customer_id") else None,
                                str(tpl.get("notes","") or "")))
                        created += 1
                    current += timedelta(days=1)
            log_fn("shifts_generated", f"{created} aus {len(sel_tpls)} Vorlagen")
            st.success(f"✅ {created} Schichten erstellt!")
            st.rerun()


# ─────────────────────────────────────────────────────────────
# 7. Backup-Verschlüsselung
# ─────────────────────────────────────────────────────────────

def encrypt_backup(input_path: Path, password: str, output_path: Path) -> bool:
    """Verschlüsselt eine Datei mit AES-256 (passwortbasiert)."""
    try:
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        import base64, os
    except ImportError:
        return False

    salt = os.urandom(16)
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    f = Fernet(key)
    encrypted = f.encrypt(input_path.read_bytes())
    output_path.write_bytes(salt + encrypted)
    return True


def page_backup_encryption(run_fn, df_fn, base_dir: Path) -> None:
    st.title("🔐 Backup-Verschlüsselung")
    st.caption("Backups vor dem Cloud-Upload mit AES-256 verschlüsseln.")

    backups = df_fn("SELECT id, file_path, file_size, created_at FROM backups ORDER BY created_at DESC LIMIT 20")
    if backups.empty:
        st.info("Noch keine Backups vorhanden.")
        return

    st.dataframe(backups[["file_path","file_size","created_at"]], use_container_width=True)

    sel = st.selectbox("Backup auswählen", backups["file_path"].tolist())
    backup_path = Path(str(sel))

    if not backup_path.exists():
        st.error("Backup-Datei nicht gefunden!")
        return

    password = st.text_input("Verschlüsselungs-Passwort", type="password")
    password_confirm = st.text_input("Passwort bestätigen", type="password")

    if st.button("🔐 Backup verschlüsseln", type="primary"):
        if password != password_confirm:
            st.error("Passwörter stimmen nicht überein.")
        elif len(password) < 12:
            st.error("Passwort muss mindestens 12 Zeichen haben.")
        else:
            output_path = backup_path.with_suffix(".enc")
            with st.spinner("Wird verschlüsselt..."):
                ok = encrypt_backup(backup_path, password, output_path)
            if ok:
                st.success(f"✅ Verschlüsselt: {output_path.name}")
                st.download_button("📥 Verschlüsseltes Backup", output_path.read_bytes(),
                                   output_path.name, "application/octet-stream")
                st.warning(f"⚠️ Passwort sicher aufbewahren! Ohne Passwort ist das Backup unwiederbringlich verloren.")
            else:
                st.error("Verschlüsselung nicht möglich. `pip install cryptography` nötig.")

    st.divider()
    st.markdown("""
**Hinweise zur Verschlüsselung:**
- Algorithmus: **AES-256-GCM** (Fernet)
- Schlüsselableitung: **PBKDF2-HMAC-SHA256** mit 480.000 Iterationen
- Salt: zufällig 16 Bytes pro Backup
- Erforderlich: `pip install cryptography`

Verschlüsselte Backups können mit dem gleichen Passwort wieder entschlüsselt werden.
Das Passwort wird **nicht** in der Datenbank gespeichert.
    """)


# ─────────────────────────────────────────────────────────────
# 8. Personalkosten je Kunde
# ─────────────────────────────────────────────────────────────

def page_personnel_costs(df_fn) -> None:
    st.title("💼 Personalkosten je Kunde / Objekt")
    st.caption("Aufstellung wieviel Personal-Aufwand pro Kunde anfällt.")

    col1, col2 = st.columns(2)
    year  = col1.selectbox("Jahr", list(range(date.today().year, date.today().year-3,-1)))
    month = col2.selectbox("Monat (leer = ganzes Jahr)", ["alle"] + list(range(1,13)))

    where = f"substr(s.shift_date,1,4)='{year}'"
    if month != "alle":
        where = f"substr(s.shift_date,1,7)='{year}-{int(month):02d}'"

    data = df_fn(f"""
        SELECT COALESCE(c.company,'–') AS Kunde,
               COUNT(s.id) AS Schichten,
               COUNT(DISTINCT s.employee_id) AS MA_eingesetzt,
               ROUND(SUM(
                   CAST((strftime('%s', s.shift_date || ' ' ||
                       CASE WHEN s.end_time < s.start_time
                           THEN s.end_time || '+1 day' ELSE s.end_time END)
                   - strftime('%s', s.shift_date || ' ' || s.start_time)) AS REAL) / 3600.0
               ),1) AS Stunden_gesamt,
               ROUND(SUM(
                   CAST((strftime('%s', s.shift_date || ' ' ||
                       CASE WHEN s.end_time < s.start_time
                           THEN s.end_time || '+1 day' ELSE s.end_time END)
                   - strftime('%s', s.shift_date || ' ' || s.start_time)) AS REAL) / 3600.0
               ) * 15.0,2) AS Personal_Aufwand_EUR
        FROM shifts s LEFT JOIN customers c ON c.id=s.customer_id
        WHERE {where} AND s.status IN ('abgeschlossen','bestätigt','geplant')
        GROUP BY c.id ORDER BY Personal_Aufwand_EUR DESC
    """)

    if not data.empty:
        st.caption("⚠️ Personalkosten basieren auf Ø 15 €/Std. (Schätzwert)")
        st.dataframe(data, use_container_width=True)

        # Vergleich Personalkosten vs. Umsatz je Kunde
        revenue = df_fn(f"""
            SELECT c.company AS Kunde,
                   ROUND(SUM(CASE WHEN i.status='bezahlt' THEN i.gross_total ELSE 0 END),2) AS Umsatz
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            WHERE substr(i.invoice_date,1,4)='{year}'
            GROUP BY c.id
        """)

        if not revenue.empty:
            merged = data.merge(revenue, on="Kunde", how="left").fillna(0)
            merged["Marge_EUR"] = merged["Umsatz"] - merged["Personal_Aufwand_EUR"]
            merged["Marge_Pct"] = (merged["Marge_EUR"] / merged["Umsatz"].replace(0,1) * 100).round(1)
            st.subheader("📊 Marge je Kunde")
            st.dataframe(merged[["Kunde","Schichten","Stunden_gesamt","Personal_Aufwand_EUR","Umsatz","Marge_EUR","Marge_Pct"]], use_container_width=True)
            st.bar_chart(merged.head(10).set_index("Kunde")[["Personal_Aufwand_EUR","Umsatz"]])
    else:
        st.info("Keine Schichtdaten für diesen Zeitraum.")


# ─────────────────────────────────────────────────────────────
# 9. Notifications-Bell mit Live-Counter
# ─────────────────────────────────────────────────────────────

def get_unread_notifications_count(df_fn, username: str = "") -> int:
    """Zählt ungelesene Hinweise."""
    try:
        result = df_fn("SELECT COUNT(*) AS n FROM notifications WHERE dismissed=0 AND (target_user IS NULL OR target_user=? OR target_user='alle')",
                       (username,))
        return int(result.iloc[0]["n"]) if not result.empty else 0
    except Exception:
        return 0


def add_notification(run_fn, level: str, title: str, message: str = "",
                      target_user: str = None, link: str = None) -> None:
    """Fügt eine Benachrichtigung hinzu."""
    run_fn("INSERT INTO notifications(level,title,message,target_user,link) VALUES(?,?,?,?,?)",
           (level, title, message, target_user, link))


def page_notifications_bell(run_fn, df_fn, current_user_fn) -> None:
    st.title("🔔 Hinweis-Center")

    user = current_user_fn() or {}
    me = user.get("username", "")

    # Tabs für Status
    tabs = st.tabs(["📬 Aktuelle", "✅ Erledigte", "⚙️ Auto-Hinweise generieren"])

    with tabs[0]:
        active = df_fn("""
            SELECT id, level AS Level, title AS Titel, message AS Nachricht,
                   created_at AS Zeit, link AS Link
            FROM notifications WHERE dismissed=0
              AND (target_user IS NULL OR target_user=? OR target_user='alle')
            ORDER BY created_at DESC
        """, (me,))

        if not active.empty:
            for _, n in active.iterrows():
                level_colors = {"danger":"#c0392b","warning":"#e67e22","info":"#2980b9","success":"#27ae60"}
                color = level_colors.get(str(n.get("Level","info")), "#888")
                with st.container():
                    col1, col2 = st.columns([5, 1])
                    col1.markdown(
                        f'<div style="border-left:4px solid {color};padding:8px 12px;background:{color}11;border-radius:4px;">'
                        f'<strong>{n["Titel"]}</strong><br/>'
                        f'<span style="color:#ddd;font-size:.88rem;">{n.get("Nachricht","") or ""}</span><br/>'
                        f'<span style="color:#888;font-size:.75rem;">{str(n["Zeit"])[:16]}</span></div>',
                        unsafe_allow_html=True
                    )
                    if col2.button("✕", key=f"dismiss_{n['id']}"):
                        run_fn("UPDATE notifications SET dismissed=1, dismissed_at=? WHERE id=?",
                               (datetime.now().isoformat()[:19], int(n["id"])))
                        st.rerun()
        else:
            st.success("✅ Keine offenen Hinweise.")

    with tabs[1]:
        done = df_fn("""
            SELECT title AS Titel, level AS Level, created_at AS Erstellt, dismissed_at AS Erledigt
            FROM notifications WHERE dismissed=1 ORDER BY dismissed_at DESC LIMIT 50
        """)
        if not done.empty:
            st.dataframe(done, use_container_width=True)

    with tabs[2]:
        st.subheader("Automatisch Hinweise generieren")
        st.caption("Prüft alle Bedingungen und legt entsprechende Hinweise an.")

        if st.button("🔄 Auto-Hinweise jetzt prüfen", type="primary"):
            count = 0
            # Überfällige Rechnungen
            overdue = int(df_fn("SELECT COUNT(*) AS n FROM invoices WHERE status='ueberfaellig'").iloc[0]["n"])
            if overdue > 0:
                add_notification(run_fn, "danger", f"{overdue} überfällige Rechnung(en)",
                                  "Bitte Mahnungen prüfen.", "alle", "Mahnwesen")
                count += 1
            # Backup älter als 7 Tage
            last_bk = df_fn("SELECT MAX(created_at) AS ts FROM backups")
            if not last_bk.empty and last_bk.iloc[0]["ts"]:
                try:
                    age = (datetime.now() - datetime.fromisoformat(str(last_bk.iloc[0]["ts"])[:19])).days
                    if age > 7:
                        add_notification(run_fn, "warning", "Backup älter als 7 Tage",
                                          f"Letztes Backup vor {age} Tagen.", "admin", "Cloud-Backup")
                        count += 1
                except Exception:
                    pass
            # Unbesetzte Schichten morgen
            tomorrow = (date.today() + timedelta(days=1)).isoformat()
            unbes = int(df_fn("SELECT COUNT(*) AS n FROM shifts WHERE shift_date=? AND employee_id IS NULL",
                               (tomorrow,)).iloc[0]["n"])
            if unbes > 0:
                add_notification(run_fn, "warning", f"{unbes} unbesetzte Schicht(en) morgen",
                                  "Mitarbeiter zuweisen!", "alle", "Dienstplan v2")
                count += 1
            # Ablaufende Qualifikationen
            try:
                exp_qual = int(df_fn("""
                    SELECT COUNT(*) AS n FROM employee_qualifications
                    WHERE expiry_date IS NOT NULL AND expiry_date <= date('now','+30 days')
                      AND expiry_date >= date('now','-1 day')
                """).iloc[0]["n"])
                if exp_qual > 0:
                    add_notification(run_fn, "warning", f"{exp_qual} Qualifikation(en) laufen ab",
                                      "Rezertifizierung nötig.", "admin", "Qualifikationen")
                    count += 1
            except Exception:
                pass
            st.success(f"✅ {count} Hinweise erstellt.")
            st.rerun()
