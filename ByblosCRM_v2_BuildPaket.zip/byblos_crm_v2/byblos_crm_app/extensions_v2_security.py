"""
extensions_v2_security.py – Sicherheit + Benachrichtigungen + ZUGFeRD + Signaturen
====================================================================================
1. Session-Security (Auto-Logout, Token-Rotation)
2. In-App Notification Bell
3. Rate-Limiting & Brute-Force-Schutz
4. ZUGFeRD 2.3 E-Rechnung (XML in PDF eingebettet)
5. Dokumenten-Signaturen (E-Mail-Link + Token)
6. Schema-Migrations-System (Versionierung)
7. WhatsApp Business Webhook
8. Kunden-Scoring in Kundenliste
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import hashlib
import json
import secrets
import time

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# DB-Registrierung
# ─────────────────────────────────────────────────────────────

def register_security(run_fn, df_fn) -> None:
    run_fn("""CREATE TABLE IF NOT EXISTS session_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        token TEXT UNIQUE NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_activity TEXT DEFAULT CURRENT_TIMESTAMP,
        ip_address TEXT,
        user_agent TEXT,
        active INTEGER DEFAULT 1
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS rate_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        identifier TEXT NOT NULL,
        action TEXT NOT NULL,
        attempt_time TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        level TEXT DEFAULT 'info',
        title TEXT NOT NULL,
        message TEXT,
        link_page TEXT,
        dismissed INTEGER DEFAULT 0,
        auto_dismiss_after INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS document_signatures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_type TEXT NOT NULL,
        document_id INTEGER,
        recipient_name TEXT,
        recipient_email TEXT NOT NULL,
        token TEXT UNIQUE NOT NULL,
        status TEXT DEFAULT 'ausstehend',
        signed_at TEXT,
        ip_address TEXT,
        signature_image TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS schema_migrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        version INTEGER UNIQUE NOT NULL,
        name TEXT NOT NULL,
        applied_at TEXT DEFAULT CURRENT_TIMESTAMP,
        checksum TEXT
    )""")
    # Basis-Schema-Version eintragen
    for v, name in [
        (1, "Initial schema"),
        (2, "Add audit_log"),
        (3, "Add notifications"),
        (4, "Add bank_transactions"),
        (5, "Add recurring_invoices"),
        (6, "Add leave_requests"),
        (7, "Add projects"),
        (8, "Add gps_checkins"),
        (9, "Add contract_monitoring"),
        (10, "Add security tables v2"),
    ]:
        try:
            run_fn("INSERT OR IGNORE INTO schema_migrations(version,name) VALUES(?,?)", (v, name))
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
# 1. Session-Security
# ─────────────────────────────────────────────────────────────

SESSION_TIMEOUT_MINUTES = 480  # 8 Stunden


def create_session_token(username: str, run_fn) -> str:
    token = secrets.token_urlsafe(32)
    run_fn("""INSERT INTO session_tokens(username,token,last_activity)
              VALUES(?,?,?)""",
           (username, token, datetime.now().isoformat()))
    return token


def validate_session(token: str, df_fn, run_fn) -> Optional[str]:
    """Gibt Username zurück wenn gültig, sonst None."""
    sess = df_fn("SELECT * FROM session_tokens WHERE token=? AND active=1", (token,))
    if sess.empty:
        return None
    row = sess.iloc[0]
    last_act = str(row.get("last_activity",""))[:19]
    try:
        age_m = (datetime.now() - datetime.fromisoformat(last_act)).total_seconds() / 60
        if age_m > SESSION_TIMEOUT_MINUTES:
            run_fn("UPDATE session_tokens SET active=0 WHERE token=?", (token,))
            return None
    except Exception:
        pass
    # Aktivität aktualisieren
    run_fn("UPDATE session_tokens SET last_activity=? WHERE token=?",
           (datetime.now().isoformat(), token))
    return str(row["username"])


def logout_session(token: str, run_fn) -> None:
    run_fn("UPDATE session_tokens SET active=0 WHERE token=?", (token,))


def check_session_security(df_fn, run_fn) -> None:
    """Prüft Session-Timeout und zeigt Warnung."""
    if "_session_token" not in st.session_state:
        return
    token = st.session_state["_session_token"]
    # Bereits in DB validiert beim Login, hier nur lokale Prüfung
    start = st.session_state.get("_session_start", datetime.now())
    elapsed_h = (datetime.now() - start).total_seconds() / 3600
    remaining_h = SESSION_TIMEOUT_MINUTES / 60 - elapsed_h
    if remaining_h < 0.5:  # Warnung 30 Minuten vorher
        st.warning(f"⏱️ **Sitzung läuft in {int(remaining_h*60)} Minuten ab.** "
                   f"Bitte Arbeit speichern und neu einloggen.")


# ─────────────────────────────────────────────────────────────
# 2. Rate-Limiting & Brute-Force-Schutz
# ─────────────────────────────────────────────────────────────

def check_rate_limit(identifier: str, action: str, df_fn, run_fn,
                      max_attempts: int = 5,
                      window_minutes: int = 15) -> Tuple[bool, int]:
    """
    Prüft Rate-Limit.
    Gibt (allowed, remaining_attempts) zurück.
    """
    cutoff = (datetime.now() - timedelta(minutes=window_minutes)).isoformat()
    attempts = df_fn("""
        SELECT COUNT(*) AS n FROM rate_limits
        WHERE identifier=? AND action=? AND attempt_time > ?
    """, (identifier, action, cutoff))
    count = int(attempts.iloc[0]["n"]) if not attempts.empty else 0

    if count >= max_attempts:
        return False, 0

    # Versuch registrieren
    run_fn("INSERT INTO rate_limits(identifier,action) VALUES(?,?)", (identifier, action))
    return True, max_attempts - count - 1


def cleanup_rate_limits(run_fn) -> None:
    """Löscht alte Rate-Limit-Einträge (>24h)."""
    cutoff = (datetime.now() - timedelta(hours=24)).isoformat()
    run_fn("DELETE FROM rate_limits WHERE attempt_time < ?", (cutoff,))


def page_rate_limit_monitor(df_fn, run_fn) -> None:
    st.title("🚧 Rate-Limiting & Brute-Force-Schutz")

    tabs = st.tabs(["📊 Übersicht", "⚙️ Konfiguration", "🔓 IP entsperren"])

    with tabs[0]:
        # Login-Versuche
        recent = df_fn("""
            SELECT identifier AS IP_Benutzer, action AS Aktion,
                   COUNT(*) AS Versuche,
                   MAX(attempt_time) AS Letzter_Versuch
            FROM rate_limits
            WHERE attempt_time > datetime('now','-24 hours')
            GROUP BY identifier, action
            ORDER BY Versuche DESC
        """)
        if not recent.empty:
            st.metric("Aktive Rate-Limit-Einträge", len(recent))
            blocked = recent[recent["Versuche"] >= 5]
            if not blocked.empty:
                st.error(f"🔴 {len(blocked)} IP(s)/Benutzer gesperrt:")
                st.dataframe(blocked, use_container_width=True)
            st.dataframe(recent, use_container_width=True)
        else:
            st.success("✅ Keine Rate-Limit-Aktivitäten in den letzten 24h.")

        # Login-Protokoll
        logins = df_fn("""
            SELECT username AS Benutzer, success AS Erfolgreich,
                   attempt_time AS Zeit, ip_address AS IP
            FROM login_attempts ORDER BY attempt_time DESC LIMIT 50
        """)
        if not logins.empty:
            st.subheader("Login-Protokoll (letzte 50)")
            st.dataframe(logins, use_container_width=True)

    with tabs[1]:
        st.markdown("""
**Rate-Limiting Konfiguration:**

| Aktion | Max. Versuche | Zeitfenster | Sperrzeit |
|---|---|---|---|
| Login | 5 | 15 Minuten | 15 Minuten |
| API-Anfragen | 100 | 1 Minute | 1 Minute |
| Passwort-Reset | 3 | 60 Minuten | 60 Minuten |
| PDF-Erstellung | 20 | 1 Minute | 1 Minute |

**Automatische Bereinigung:** Alte Einträge (>24h) werden bei der Tagesroutine gelöscht.
        """)

    with tabs[2]:
        blocked_ids = df_fn("""
            SELECT identifier, COUNT(*) AS n
            FROM rate_limits
            WHERE attempt_time > datetime('now','-15 minutes')
            GROUP BY identifier HAVING n >= 5
        """)
        if not blocked_ids.empty:
            sel = st.selectbox("Gesperrte Entität", blocked_ids["identifier"].tolist())
            if st.button("🔓 Sperre aufheben"):
                run_fn("DELETE FROM rate_limits WHERE identifier=?", (sel,))
                st.success(f"✅ Sperre für '{sel}' aufgehoben.")
                st.rerun()
        else:
            st.info("Keine aktiven Sperren.")

        if st.button("🗑️ Alle alten Rate-Limit-Einträge löschen"):
            cleanup_rate_limits(run_fn)
            st.success("Bereinigt.")
            st.rerun()


# ─────────────────────────────────────────────────────────────
# 3. In-App Notification Bell
# ─────────────────────────────────────────────────────────────

def create_notification(run_fn, title: str, message: str = "",
                          level: str = "info", link_page: str = "",
                          username: str = None, auto_dismiss_after: int = 0) -> None:
    """Erstellt eine In-App-Benachrichtigung."""
    run_fn("""INSERT INTO notifications(username,level,title,message,link_page,auto_dismiss_after)
              VALUES(?,?,?,?,?,?)""",
           (username, level, title, message, link_page, auto_dismiss_after))


def render_notification_bell(df_fn, run_fn, current_user_fn) -> None:
    """Rendert die Benachrichtigungs-Glocke in der Sidebar."""
    user = current_user_fn() or {}
    username = user.get("username", "")

    unread = df_fn("""
        SELECT COUNT(*) AS n FROM notifications
        WHERE dismissed=0 AND (username=? OR username IS NULL)
    """, (username,)).iloc[0]["n"] if username else 0

    unread = int(unread)
    bell_icon = f"🔔 ({unread})" if unread > 0 else "🔔"

    with st.sidebar:
        if st.button(bell_icon, key="notif_bell",
                     help="Benachrichtigungen anzeigen"):
            st.session_state["show_notifications"] = not st.session_state.get("show_notifications", False)

    if st.session_state.get("show_notifications", False):
        notifs = df_fn("""
            SELECT id, level, title, message, link_page, created_at
            FROM notifications
            WHERE dismissed=0 AND (username=? OR username IS NULL)
            ORDER BY created_at DESC LIMIT 20
        """, (username,))

        with st.sidebar:
            st.markdown("---")
            st.subheader("🔔 Benachrichtigungen")
            if notifs.empty:
                st.info("Keine neuen Nachrichten.")
            else:
                level_icons = {"danger":"🔴", "warning":"🟡",
                                "info":"🔵", "success":"🟢"}
                for _, n in notifs.iterrows():
                    icon = level_icons.get(str(n["level"]), "ℹ️")
                    nid = int(n["id"])
                    col1, col2 = st.columns([4, 1])
                    col1.markdown(f"{icon} **{n['title']}**")
                    if n.get("message"):
                        col1.caption(str(n["message"])[:60])
                    if col2.button("✖", key=f"dismiss_{nid}"):
                        run_fn("UPDATE notifications SET dismissed=1 WHERE id=?", (nid,))
                        st.rerun()

                if st.button("✅ Alle gelesen"):
                    run_fn("UPDATE notifications SET dismissed=1 WHERE username=? OR username IS NULL",
                           (username,))
                    st.rerun()


def page_notifications_manager(run_fn, df_fn, current_user_fn) -> None:
    st.title("🔔 Benachrichtigungen")

    user = current_user_fn() or {}
    username = user.get("username", "")
    is_admin = user.get("role","").lower() in ("admin","administrator")

    tabs = st.tabs(["📋 Meine Nachrichten", "➕ Neue Meldung", "📊 Alle Meldungen"])

    with tabs[0]:
        notifs = df_fn("""
            SELECT id, level AS Level, title AS Titel, message AS Nachricht,
                   link_page AS Seite, created_at AS Erstellt,
                   CASE WHEN dismissed=0 THEN '🔴 Neu' ELSE '✅ Gelesen' END AS Status
            FROM notifications
            WHERE username=? OR username IS NULL
            ORDER BY created_at DESC LIMIT 50
        """, (username,))

        if not notifs.empty:
            unread_count = len(notifs[notifs["Status"] == "🔴 Neu"])
            c1, c2 = st.columns(2)
            c1.metric("Ungelesen", unread_count)
            c2.metric("Gesamt", len(notifs))
            st.dataframe(notifs.drop(columns=["id"]), use_container_width=True, height=300)

            if st.button("✅ Alle als gelesen markieren"):
                run_fn("UPDATE notifications SET dismissed=1 WHERE username=? OR username IS NULL",
                       (username,))
                st.rerun()
        else:
            st.info("Keine Benachrichtigungen.")

    with tabs[1]:
        with st.form("notif_form", clear_on_submit=True):
            level  = st.selectbox("Typ", ["info","success","warning","danger"],
                                   format_func=lambda x: {"info":"ℹ️ Info","success":"✅ Erfolg",
                                                            "warning":"⚠️ Warnung","danger":"🔴 Kritisch"}[x])
            title  = st.text_input("Titel *")
            message = st.text_area("Nachricht")
            link_page = st.text_input("Verlinkte Seite (optional, z.B. 'Dashboard')")
            target = st.selectbox("Empfänger", ["alle Benutzer", "nur mich", "nur Admins"])
            if st.form_submit_button("📨 Senden", type="primary") and title:
                t_username = None if target == "alle Benutzer" else username
                create_notification(run_fn, title, message, level, link_page, t_username)
                st.success("✅ Benachrichtigung erstellt!")
                st.rerun()

    with tabs[2]:
        if not is_admin:
            st.info("Nur Admins sehen alle Benachrichtigungen.")
            return
        all_notifs = df_fn("""
            SELECT username AS Benutzer, level AS Level, title AS Titel,
                   dismissed AS Gelesen, created_at AS Erstellt
            FROM notifications ORDER BY created_at DESC LIMIT 100
        """)
        if not all_notifs.empty:
            st.dataframe(all_notifs, use_container_width=True)
        if st.button("🗑️ Alle Benachrichtigungen löschen"):
            run_fn("DELETE FROM notifications WHERE dismissed=1")
            st.success("Gelesene gelöscht.")
            st.rerun()


# ─────────────────────────────────────────────────────────────
# 4. ZUGFeRD 2.3 E-Rechnung (XML-Einbettung)
# ─────────────────────────────────────────────────────────────

def generate_zugferd_xml(invoice: dict, customer: dict, items: list,
                           seller: dict) -> str:
    """
    Erstellt ZUGFeRD 2.3 / EN-16931 kompatibles XML für elektronische Rechnungen.
    Das XML wird in die PDF eingebettet (Factur-X / ZUGFeRD 2.3).
    """
    inv_date = str(invoice.get("invoice_date",""))[:10].replace("-","")
    due_date  = str(invoice.get("due_date",""))[:10].replace("-","")
    net       = float(invoice.get("net_total", 0))
    vat_r     = float(invoice.get("vat_rate", 19))
    vat_t     = float(invoice.get("vat_total", round(net * vat_r / 100, 2)))
    gross     = float(invoice.get("gross_total", net + vat_t))
    inv_no    = str(invoice.get("invoice_no",""))
    desc      = str(invoice.get("description",""))

    line_items_xml = ""
    for i, item in enumerate(items, 1):
        qty   = float(item.get("quantity", 1))
        price = float(item.get("unit_price", 0))
        total = float(item.get("total", round(qty * price, 2)))
        line_items_xml += f"""
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument>
        <ram:LineID>{i}</ram:LineID>
      </ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct>
        <ram:Name>{item.get("description","")}</ram:Name>
      </ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice>
          <ram:ChargeAmount>{price:.2f}</ram:ChargeAmount>
        </ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery>
        <ram:BilledQuantity unitCode="{item.get("unit","C62")}">{qty:.2f}</ram:BilledQuantity>
      </ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:TypeCode>VAT</ram:TypeCode>
          <ram:CategoryCode>S</ram:CategoryCode>
          <ram:RateApplicablePercent>{vat_r:.2f}</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation>
          <ram:LineTotalAmount>{total:.2f}</ram:LineTotalAmount>
        </ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>"""

    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice
  xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
  xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
  xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:en16931</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>{inv_no}</ram:ID>
    <ram:TypeCode>380</ram:TypeCode>
    <ram:IssueDateTime>
      <udt:DateTimeString format="102">{inv_date}</udt:DateTimeString>
    </ram:IssueDateTime>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    {line_items_xml}
    <ram:ApplicableHeaderTradeAgreement>
      <ram:SellerTradeParty>
        <ram:Name>{seller.get("name","")}</ram:Name>
        <ram:PostalTradeAddress>
          <ram:LineOne>{seller.get("street","")}</ram:LineOne>
          <ram:CountryID>DE</ram:CountryID>
        </ram:PostalTradeAddress>
        <ram:SpecifiedTaxRegistration>
          <ram:ID schemeID="VA">{seller.get("ust_id","")}</ram:ID>
        </ram:SpecifiedTaxRegistration>
      </ram:SellerTradeParty>
      <ram:BuyerTradeParty>
        <ram:Name>{customer.get("company","")}</ram:Name>
        <ram:PostalTradeAddress>
          <ram:LineOne>{customer.get("street","")}</ram:LineOne>
          <ram:CountryID>DE</ram:CountryID>
        </ram:PostalTradeAddress>
      </ram:BuyerTradeParty>
    </ram:ApplicableHeaderTradeAgreement>
    <ram:ApplicableHeaderTradeDelivery/>
    <ram:ApplicableHeaderTradeSettlement>
      <ram:PaymentReference>{inv_no}</ram:PaymentReference>
      <ram:InvoiceCurrencyCode>EUR</ram:InvoiceCurrencyCode>
      <ram:SpecifiedTradePaymentTerms>
        <ram:DueDateDateTime>
          <udt:DateTimeString format="102">{due_date}</udt:DateTimeString>
        </ram:DueDateDateTime>
      </ram:SpecifiedTradePaymentTerms>
      <ram:ApplicableTradeTax>
        <ram:CalculatedAmount>{vat_t:.2f}</ram:CalculatedAmount>
        <ram:TypeCode>VAT</ram:TypeCode>
        <ram:BasisAmount>{net:.2f}</ram:BasisAmount>
        <ram:CategoryCode>S</ram:CategoryCode>
        <ram:RateApplicablePercent>{vat_r:.2f}</ram:RateApplicablePercent>
      </ram:ApplicableTradeTax>
      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>
        <ram:LineTotalAmount>{net:.2f}</ram:LineTotalAmount>
        <ram:TaxBasisTotalAmount>{net:.2f}</ram:TaxBasisTotalAmount>
        <ram:TaxTotalAmount currencyID="EUR">{vat_t:.2f}</ram:TaxTotalAmount>
        <ram:GrandTotalAmount>{gross:.2f}</ram:GrandTotalAmount>
        <ram:DuePayableAmount>{gross:.2f}</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>
    </ram:ApplicableHeaderTradeSettlement>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>"""
    return xml


def page_zugferd_export(df_fn, get_setting_fn, base_dir: Path) -> None:
    st.title("🧾 ZUGFeRD 2.3 E-Rechnung")
    st.caption("Elektronische Rechnungen nach EN-16931 / Factur-X Standard.")

    tabs = st.tabs(["📤 XML exportieren", "ℹ️ Standard-Info"])

    with tabs[0]:
        invoices = df_fn("""
            SELECT i.id, i.invoice_no || ' – ' || c.company AS label
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            ORDER BY i.invoice_date DESC LIMIT 100
        """)
        if invoices.empty:
            st.info("Keine Rechnungen vorhanden.")
            return

        sel = st.selectbox("Rechnung", invoices["label"].tolist())
        iid = int(invoices[invoices["label"] == sel].iloc[0]["id"])

        if st.button("📄 ZUGFeRD-XML erstellen", type="primary"):
            inv = df_fn("SELECT i.*, c.* FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=?",
                        (iid,)).iloc[0].to_dict()
            items_data = df_fn("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY position", (iid,))
            items_list = items_data.to_dict("records") if not items_data.empty else []

            seller = {
                "name":    get_setting_fn("company_name", "Byblos Sicherheitsdienst"),
                "street":  get_setting_fn("company_street", ""),
                "ust_id":  get_setting_fn("company_ust_id", ""),
                "iban":    get_setting_fn("company_iban", ""),
            }
            customer = {
                "company": str(inv.get("company","")),
                "street":  str(inv.get("street","")),
            }

            xml = generate_zugferd_xml(inv, customer, items_list, seller)
            xml_path = base_dir / "generated" / f"zugferd_{inv.get('invoice_no','')}.xml"
            xml_path.parent.mkdir(exist_ok=True)
            xml_path.write_text(xml, encoding="utf-8")

            st.success(f"✅ ZUGFeRD-XML erstellt")
            st.download_button("📥 XML herunterladen",
                               xml.encode("utf-8"),
                               xml_path.name, "application/xml")
            st.code(xml[:500] + "...", language="xml")

    with tabs[1]:
        st.markdown("""
**ZUGFeRD 2.3 / Factur-X / EN-16931**

Elektronische Rechnungen, die maschinenlesbar sind und in herkömmliche PDFs eingebettet werden können.

| Standard | Kompatibilität | Profil |
|---|---|---|
| ZUGFeRD 2.3 | Deutschland | EN16931 (Komfort) |
| Factur-X | Frankreich/DE | EN16931 |
| XRechnung | Öffentliche Hand | CII (D16B) |

**Schritte für ZUGFeRD-konforme Rechnungen:**
1. XML-Datei mit dieser Funktion erstellen
2. PDF-Rechnung mit normaler PDF-Funktion erstellen
3. XML in PDF einbetten (Tool: `pikepdf` oder `pdftk`)
4. Kunden können PDF in ihrer Buchhaltungssoftware direkt importieren

**Installation für vollständige Einbettung:**
```bash
pip install pikepdf
```

**Hinweis:** Dieses Modul erstellt das konforme XML. 
Vollautomatische PDF-Einbettung wird in v3 implementiert.
        """)


# ─────────────────────────────────────────────────────────────
# 5. Dokumenten-Signaturen (Token-basiert)
# ─────────────────────────────────────────────────────────────

def page_document_signatures(run_fn, df_fn, get_setting_fn, queue_email_fn, log_fn) -> None:
    st.title("✍️ Dokumenten-Signaturen")
    st.caption("Kunden digital unterschreiben lassen per E-Mail-Link.")

    tabs = st.tabs(["📨 Signaturanfrage senden", "📋 Offene Anfragen",
                    "✅ Unterschriebene Dokumente"])

    with tabs[0]:
        doc_type = st.selectbox("Dokumenttyp",
                                 ["Rechnung", "Angebot", "Vertrag", "Einsatzbericht",
                                  "Sonstiges"])
        invoices = df_fn("""
            SELECT i.id, i.invoice_no || ' – ' || c.company || ' · ' ||
                   ROUND(i.gross_total,2) || ' €' AS label, c.email, c.company
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            WHERE i.status IN ('offen','ueberfaellig')
            ORDER BY i.invoice_date DESC LIMIT 50
        """)

        doc_id = None
        recipient_email = ""
        recipient_name  = ""

        if doc_type in ("Rechnung","Angebot") and not invoices.empty:
            sel = st.selectbox("Dokument", invoices["label"].tolist())
            row = invoices[invoices["label"] == sel].iloc[0]
            doc_id = int(row["id"])
            recipient_email = st.text_input("Empfänger E-Mail", str(row.get("email","")))
            recipient_name  = st.text_input("Empfänger Name", str(row.get("company","")))
        else:
            recipient_email = st.text_input("Empfänger E-Mail")
            recipient_name  = st.text_input("Empfänger Name")

        co_name   = get_setting_fn("company_name","Byblos Sicherheitsdienst")
        base_url  = get_setting_fn("payment_base_url","http://localhost:8501")

        if st.button("📨 Signaturanfrage senden", type="primary") and recipient_email:
            token = secrets.token_urlsafe(32)
            run_fn("""INSERT INTO document_signatures(document_type,document_id,
                      recipient_name,recipient_email,token)
                      VALUES(?,?,?,?,?)""",
                   (doc_type, doc_id, recipient_name, recipient_email, token))

            sign_url = f"{base_url}?sign_token={token}"
            body = (f"Sehr geehrte(r) {recipient_name},\n\n"
                    f"{co_name} bittet Sie, das folgende Dokument digital zu unterzeichnen:\n\n"
                    f"Dokumenttyp: {doc_type}\n"
                    f"Signatur-Link: {sign_url}\n\n"
                    f"Der Link ist 30 Tage gültig.\n\n"
                    f"Mit freundlichen Grüßen\n{co_name}")

            queue_email_fn(recipient_email,
                           f"Signaturanfrage: {doc_type} – {co_name}",
                           body, "")
            log_fn("signature_requested", f"{doc_type} → {recipient_email}")
            st.success(f"✅ Signaturanfrage an {recipient_email} gesendet!")
            st.code(sign_url, language="text")

    with tabs[1]:
        pending = df_fn("""
            SELECT id, document_type AS Typ, recipient_name AS Empfänger,
                   recipient_email AS E_Mail, status AS Status,
                   created_at AS Gesendet,
                   CAST(julianday('now') - julianday(created_at) AS INT) AS Tage_alt
            FROM document_signatures WHERE status='ausstehend'
            ORDER BY created_at DESC
        """)
        if not pending.empty:
            st.metric("Ausstehende Unterschriften", len(pending))
            st.dataframe(pending.drop(columns=["id"]), use_container_width=True)

            # Erinnerung senden
            sel = st.selectbox("Erinnerung senden an",
                                pending["Empfänger"].tolist())
            if st.button("📧 Erinnerung senden"):
                row = pending[pending["Empfänger"] == sel].iloc[0]
                sid = int(row["id"])
                token = df_fn("SELECT token FROM document_signatures WHERE id=?", (sid,)).iloc[0]["token"]
                base_url = get_setting_fn("payment_base_url","http://localhost:8501")
                sign_url = f"{base_url}?sign_token={token}"
                queue_email_fn(str(row["E_Mail"]),
                               f"Erinnerung: Ausstehende Unterschrift",
                               f"Bitte Dokument unterzeichnen: {sign_url}", "")
                st.success("Erinnerung gesendet.")
        else:
            st.success("✅ Keine ausstehenden Unterschriften.")

    with tabs[2]:
        signed = df_fn("""
            SELECT document_type AS Typ, recipient_name AS Unterzeichner,
                   recipient_email AS E_Mail, signed_at AS Unterzeichnet,
                   ip_address AS IP
            FROM document_signatures WHERE status='unterzeichnet'
            ORDER BY signed_at DESC
        """)
        if not signed.empty:
            st.metric("Unterzeichnete Dokumente", len(signed))
            st.dataframe(signed, use_container_width=True)
        else:
            st.info("Noch keine unterzeichneten Dokumente.")


# ─────────────────────────────────────────────────────────────
# 6. Schema-Migrations-System
# ─────────────────────────────────────────────────────────────

def page_schema_migrations(df_fn) -> None:
    st.title("🔄 Datenbank-Migrationen")
    st.caption("Schema-Versioning und Migrations-Historie.")

    tabs = st.tabs(["📋 Migrations-Historie", "📊 Schema-Info"])

    with tabs[0]:
        migrations = df_fn("""
            SELECT version AS Version, name AS Migration,
                   applied_at AS Angewendet
            FROM schema_migrations ORDER BY version DESC
        """)
        if not migrations.empty:
            st.metric("Schema-Versionen", len(migrations))
            st.metric("Aktuelle Version", int(migrations.iloc[0]["Version"]))
            st.dataframe(migrations, use_container_width=True)
        else:
            st.info("Keine Migrations-Historie.")

        # DB-Tabellen
        tables = df_fn("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name")
        st.metric("Tabellen gesamt", len(tables))

    with tabs[1]:
        st.subheader("Datenbankstruktur")
        tables2 = df_fn("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        if not tables2.empty:
            sel = st.selectbox("Tabelle", tables2["name"].tolist())
            cols = df_fn(f"PRAGMA table_info([{sel}])")
            if not cols.empty:
                st.dataframe(cols[["name","type","notnull","dflt_value","pk"]],
                             use_container_width=True)


# ─────────────────────────────────────────────────────────────
# 7. WhatsApp Business Webhook-Vorbereitung
# ─────────────────────────────────────────────────────────────

def page_whatsapp_integration(run_fn, df_fn, get_setting_fn, set_setting_fn) -> None:
    st.title("📱 WhatsApp Business Integration")
    st.caption("WhatsApp-Nachrichten für Mahnungen und Benachrichtigungen.")

    tabs = st.tabs(["⚙️ Konfiguration", "📨 Nachricht senden", "📖 Anleitung"])

    with tabs[0]:
        with st.form("wa_form"):
            wa_token = st.text_input("WhatsApp Cloud API Token",
                                      get_setting_fn("wa_token",""), type="password")
            wa_phone_id = st.text_input("Phone Number ID",
                                         get_setting_fn("wa_phone_id",""))
            wa_verify_token = st.text_input("Webhook Verify Token",
                                              get_setting_fn("wa_verify_token",
                                                              secrets.token_hex(16)))
            wa_enabled = st.checkbox("WhatsApp-Versand aktiv",
                                     value=get_setting_fn("wa_enabled","0") == "1")
            if st.form_submit_button("💾 Speichern", type="primary"):
                for k,v in [("wa_token",wa_token),("wa_phone_id",wa_phone_id),
                            ("wa_verify_token",wa_verify_token),
                            ("wa_enabled","1" if wa_enabled else "0")]:
                    set_setting_fn(k, v)
                st.success("✅ WhatsApp-Einstellungen gespeichert.")

    with tabs[1]:
        wa_token  = get_setting_fn("wa_token","")
        phone_id  = get_setting_fn("wa_phone_id","")

        if not wa_token or not phone_id:
            st.warning("Bitte zuerst Token und Phone-ID konfigurieren.")
            return

        to_number = st.text_input("Empfänger (internationale Nummer, z.B. 4917612345678)")
        template  = st.selectbox("Nachrichtentyp", ["Freitext","Mahnung","Zahlungseingang"])
        if template == "Freitext":
            message = st.text_area("Nachricht")
        elif template == "Mahnung":
            message = st.text_input("Rechnung-Nr.", "RE-0001")

        if st.button("📱 WhatsApp senden", type="primary") and to_number:
            try:
                import urllib.request as ureq
                import json as jmod

                if template == "Freitext":
                    payload = {
                        "messaging_product": "whatsapp",
                        "to": to_number.replace("+","").replace(" ",""),
                        "type": "text",
                        "text": {"body": message},
                    }
                else:
                    payload = {
                        "messaging_product": "whatsapp",
                        "to": to_number.replace("+","").replace(" ",""),
                        "type": "text",
                        "text": {"body": f"🛡️ Byblos: Ihre Rechnung {message} ist fällig."},
                    }

                url = f"https://graph.facebook.com/v18.0/{phone_id}/messages"
                data = jmod.dumps(payload).encode("utf-8")
                req = ureq.Request(url, data=data, headers={
                    "Authorization": f"Bearer {wa_token}",
                    "Content-Type": "application/json",
                })
                with ureq.urlopen(req, timeout=10) as resp:
                    result = jmod.loads(resp.read())
                    if result.get("messages"):
                        st.success(f"✅ WhatsApp-Nachricht gesendet!")
                    else:
                        st.error(f"API-Fehler: {result}")
            except Exception as e:
                st.error(f"Fehler: {e}")

    with tabs[2]:
        st.markdown("""
**WhatsApp Business API einrichten:**

1. **Meta Business Account** erstellen: https://business.facebook.com
2. **WhatsApp Business App** einrichten
3. **Testnummer** oder eigene Nummer verifizieren
4. **Access Token** generieren (System User Token)
5. **Phone Number ID** aus dem Dashboard kopieren

**Webhook für eingehende Nachrichten:**
```bash
# Webhook-URL in Meta-Developer-Portal:
https://crm.byblos.de/api/v1/webhook

# Verify Token (oben konfiguriert) eingeben
```

**Kosten:** Meta berechnet pro Konversation (nicht pro Nachricht).
Detaillierte Preise: https://developers.facebook.com/docs/whatsapp/pricing

**Alternative für Tests:** WhatsApp Web + Browser-Automation  
(nicht für Produktion empfohlen).
        """)


# ─────────────────────────────────────────────────────────────
# 8. Kunden-Scoring in Kundenliste
# ─────────────────────────────────────────────────────────────

def page_customers_with_scoring(df_fn, run_fn, next_number_fn, log_fn) -> None:
    """Erweiterte Kundenliste mit integrierten Scoring-Badges."""
    st.title("👥 Kunden")

    tabs = st.tabs(["📋 Kundenliste (mit Scoring)", "➕ Neu", "📊 Auswertung"])

    with tabs[0]:
        col_s, col_f = st.columns([3, 1])
        q        = col_s.text_input("🔍 Suche")
        sort_by  = col_f.selectbox("Sortierung",
                                    ["Firmenname","Umsatz","Score"])

        # Kunden mit Umsatz und Scoring
        base = """
            SELECT c.id, c.customer_no AS Nr, c.company AS Firma,
                   c.contact_person AS Ansprechperson,
                   c.email AS E_Mail, c.phone AS Telefon,
                   ROUND(COALESCE((SELECT SUM(i.gross_total)
                                   FROM invoices i WHERE i.customer_id=c.id
                                   AND i.status='bezahlt'),0),0) AS Umsatz_bezahlt,
                   COALESCE((SELECT COUNT(*) FROM invoices i
                              WHERE i.customer_id=c.id
                              AND i.status IN ('offen','ueberfaellig')),0) AS Offene_Rechnungen
            FROM customers c
        """
        params = []
        if q:
            base += " WHERE c.company LIKE ? OR c.email LIKE ? OR c.customer_no LIKE ?"
            params += [f"%{q}%"] * 3

        order = {"Firmenname":"c.company", "Umsatz":"Umsatz_bezahlt DESC",
                  "Score":"c.company"}[sort_by]
        base += f" ORDER BY {order if 'DESC' in order else order + ' ASC'}"

        customers = df_fn(base, tuple(params))

        if not customers.empty:
            # Scoring hinzufügen (lazy – nur wenn nicht zu viele)
            try:
                from ml_logic import score_customer
                scores = {}
                for _, row in customers.iterrows():
                    s = score_customer(int(row["id"]), df_fn)
                    scores[int(row["id"])] = (s["grade"], s["color"])
            except Exception:
                scores = {}

            c1, c2, c3 = st.columns(3)
            c1.metric("Kunden gesamt", len(customers))
            c2.metric("Umsatz gesamt", fmt_eur(float(customers["Umsatz_bezahlt"].sum())))
            c3.metric("Mit offenen Rechnungen",
                      len(customers[customers["Offene_Rechnungen"] > 0]))

            # Tabellarische Anzeige mit Score-Badge
            for _, row in customers.iterrows():
                cid = int(row["id"])
                grade, color = scores.get(cid, ("–", "#888"))
                col1, col2, col3, col4, col5 = st.columns([2, 2, 1, 1, 1])
                col1.markdown(f"**{row['Firma']}**  \n{row.get('Ansprechperson','') or ''}")
                col2.caption(f"📧 {row.get('E_Mail','') or '–'}  \n📞 {row.get('Telefon','') or '–'}")
                col3.markdown(
                    f'<div style="background:{color}33;border:1px solid {color};'
                    f'border-radius:8px;padding:2px 8px;text-align:center;'
                    f'font-weight:bold;color:{color};">{grade}</div>',
                    unsafe_allow_html=True
                )
                col4.metric("", fmt_eur(float(row["Umsatz_bezahlt"])),
                             label_visibility="collapsed")
                if int(row["Offene_Rechnungen"]) > 0:
                    col5.warning(f"⚠️ {row['Offene_Rechnungen']}")
                else:
                    col5.success("✅")
                st.divider()
        else:
            st.info("Keine Kunden gefunden.")

    with tabs[1]:
        with st.form("cust_new_scoring", clear_on_submit=True):
            a, b = st.columns(2)
            cust_no = a.text_input("Kundennummer", next_number_fn("customers","customer_no","SD-"))
            company = b.text_input("Firmenname *")
            contact = a.text_input("Ansprechperson")
            email   = b.text_input("E-Mail")
            phone   = a.text_input("Telefon")
            street  = b.text_input("Straße")
            zip_c   = a.text_input("PLZ Ort")
            notes   = st.text_area("Notizen")
            if st.form_submit_button("💾 Speichern", type="primary") and company:
                run_fn("""INSERT INTO customers(customer_no,company,contact_person,
                          email,phone,street,zip_city,notes)
                          VALUES(?,?,?,?,?,?,?,?)""",
                       (cust_no, company, contact, email, phone, street, zip_c, notes))
                log_fn("customer_created", company)
                st.success(f"✅ {company} angelegt!")
                st.rerun()

    with tabs[2]:
        try:
            from ml_logic import score_all_customers
            scores_df = score_all_customers(df_fn)
            if not scores_df.empty:
                c1, c2, c3 = st.columns(3)
                c1.metric("Analysiert", len(scores_df))
                c2.metric("Ø Score", f"{scores_df['Score'].mean():.0f}/100")
                c3.metric("Note A/A+", len(scores_df[scores_df["Note"].isin(["A","A+"])]))
                st.dataframe(scores_df, use_container_width=True)
                st.bar_chart(scores_df.set_index("Kunde")["Score"])
        except Exception as e:
            st.error(f"Scoring-Fehler: {e}")
