"""
extensions_v2_prod2.py – Tests, CI/CD, Druckansicht, Mitarbeiter-Mini-App
==========================================================================
1. Dienstplan Druckansicht (A4-optimiert)
2. Mitarbeiter-Mini-App (eigenes Login, nur Schichten/Urlaub)
3. Interne Nachrichten (einfacher Chat)
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import calendar

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# DB-Registrierung
# ─────────────────────────────────────────────────────────────

def register_prod2(run_fn, df_fn) -> None:
    run_fn("""CREATE TABLE IF NOT EXISTS internal_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender TEXT NOT NULL,
        recipient TEXT,
        message TEXT NOT NULL,
        read_by TEXT DEFAULT '',
        priority TEXT DEFAULT 'normal',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")


# ─────────────────────────────────────────────────────────────
# 1. Dienstplan Druckansicht
# ─────────────────────────────────────────────────────────────

def page_print_schedule(df_fn) -> None:
    st.title("🖨️ Dienstplan Druckansicht")
    st.caption("A4-optimierte Wochenansicht zum Ausdrucken.")

    col1, col2 = st.columns(2)
    year  = col1.number_input("Jahr", value=date.today().year, min_value=2020, max_value=2035)
    week_no = col2.number_input("Kalenderwoche", value=date.today().isocalendar()[1],
                                 min_value=1, max_value=53)

    # Wochendaten
    week_start = date.fromisocalendar(int(year), int(week_no), 1)
    week_end   = week_start + timedelta(days=6)
    week_days  = [week_start + timedelta(days=i) for i in range(7)]

    shifts = df_fn("""
        SELECT s.shift_date AS datum, s.start_time AS von, s.end_time AS bis,
               s.shift_type AS typ, s.location AS ort,
               COALESCE(e.name,'⚠️ UNBESETZT') AS mitarbeiter,
               COALESCE(c.company,'–') AS kunde, s.status AS status
        FROM shifts s
        LEFT JOIN employees e ON e.id=s.employee_id
        LEFT JOIN customers c ON c.id=s.customer_id
        WHERE s.shift_date BETWEEN ? AND ?
        ORDER BY s.shift_date, s.start_time
    """, (week_start.isoformat(), week_end.isoformat()))

    # Druckoptimiertes HTML/CSS
    days_de = ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"]

    html = f"""
    <style>
    @media print {{
        body {{ margin: 0; padding: 0; }}
        .no-print {{ display: none !important; }}
        .print-table {{ page-break-inside: avoid; }}
        @page {{ size: A4 landscape; margin: 10mm; }}
    }}
    .plan-container {{
        font-family: Arial, sans-serif;
        font-size: 9pt;
        width: 100%;
    }}
    .plan-header {{
        background: #1a2744;
        color: white;
        padding: 8px;
        font-size: 14pt;
        font-weight: bold;
        text-align: center;
        margin-bottom: 8px;
    }}
    .plan-table {{
        width: 100%;
        border-collapse: collapse;
    }}
    .plan-table th {{
        background: #c0392b;
        color: white;
        padding: 4px;
        text-align: center;
        font-size: 8pt;
        border: 1px solid #aaa;
    }}
    .plan-table td {{
        border: 1px solid #ccc;
        padding: 3px 4px;
        vertical-align: top;
        min-height: 50px;
    }}
    .shift-block {{
        background: #e8f0fe;
        border-left: 3px solid #1a73e8;
        padding: 2px 4px;
        margin-bottom: 2px;
        font-size: 8pt;
        border-radius: 2px;
    }}
    .shift-unbesetzt {{
        background: #fce8e6;
        border-left: 3px solid #d93025;
    }}
    .shift-done {{
        background: #e6f4ea;
        border-left: 3px solid #188038;
    }}
    </style>
    <div class='plan-container'>
    <div class='plan-header'>
        🛡️ Byblos Sicherheitsdienst – Dienstplan KW {week_no}/{year}
        &nbsp;·&nbsp; {week_start.strftime('%d.%m.')} – {week_end.strftime('%d.%m.%Y')}
    </div>
    <table class='plan-table'>
    <tr>
    """

    for i, (d, name) in enumerate(zip(week_days, days_de)):
        weekend = "color:darkred;" if i >= 5 else ""
        html += f"<th style='{weekend}'>{name}<br/>{d.strftime('%d.%m.')}</th>"
    html += "</tr><tr>"

    # Schichten je Tag
    for d in week_days:
        day_str = d.isoformat()
        day_shifts = shifts[shifts["datum"] == day_str] if not shifts.empty else pd.DataFrame()
        html += "<td>"
        if not day_shifts.empty:
            for _, s in day_shifts.iterrows():
                cls = "shift-unbesetzt" if "UNBESETZT" in str(s["mitarbeiter"]) else \
                      "shift-done" if s["status"] == "abgeschlossen" else "shift-block"
                html += (f"<div class='{cls}'>"
                         f"<b>{str(s['von'])[:5]}–{str(s['bis'])[:5]}</b><br/>"
                         f"{s['mitarbeiter']}<br/>"
                         f"<span style='color:#555'>{s['kunde']}</span>"
                         f"</div>")
        else:
            html += "<span style='color:#bbb;font-size:8pt;'>–</span>"
        html += "</td>"

    html += "</tr></table></div>"

    # Statistik
    if not shifts.empty:
        total = len(shifts)
        unbes = len(shifts[shifts["mitarbeiter"] == "⚠️ UNBESETZT"])
        done  = len(shifts[shifts["status"] == "abgeschlossen"])
        c1, c2, c3 = st.columns(3)
        c1.metric(f"KW {week_no} Schichten gesamt", total)
        c2.metric("⚠️ Unbesetzt", unbes)
        c3.metric("✅ Abgeschlossen", done)

    st.markdown(html, unsafe_allow_html=True)
    st.divider()

    # Legende
    st.markdown("""
<div style='font-size:0.8rem;'>
<span style='background:#e8f0fe;border-left:3px solid #1a73e8;padding:2px 8px;margin-right:8px;'>🔵 Geplant</span>
<span style='background:#e6f4ea;border-left:3px solid #188038;padding:2px 8px;margin-right:8px;'>🟢 Abgeschlossen</span>
<span style='background:#fce8e6;border-left:3px solid #d93025;padding:2px 8px;'>🔴 Unbesetzt</span>
</div>
    """, unsafe_allow_html=True)

    st.info("💡 **Drucken:** Browser-Druckfunktion (Strg+P) → Querformat A4 wählen")

    # Auch als PDF-ähnliche Monatsübersicht
    st.divider()
    st.subheader("Monatsdienstplan-Export")
    if st.button("📥 Dienstplan als Excel-Tabelle exportieren"):
        if not shifts.empty:
            excel_df = shifts.copy()
            from io import BytesIO
            buf = BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as writer:
                excel_df.to_excel(writer, sheet_name=f"KW{week_no}_{year}", index=False)
            buf.seek(0)
            st.download_button(
                f"📥 KW{week_no}_{year}_Dienstplan.xlsx",
                buf.read(),
                f"dienstplan_kw{week_no}_{year}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        else:
            st.info("Keine Schichten diese Woche.")


# ─────────────────────────────────────────────────────────────
# 2. Interner Nachrichten-Chat
# ─────────────────────────────────────────────────────────────

def page_internal_chat(run_fn, df_fn, current_user_fn) -> None:
    st.title("💬 Interne Nachrichten")
    st.caption("Schnelle Kommunikation zwischen Mitarbeitern innerhalb des CRM.")

    user = current_user_fn() or {}
    me = user.get("username", "system")

    tabs = st.tabs(["📨 Posteingang", "✏️ Nachricht senden", "📋 Alle Nachrichten"])

    with tabs[0]:
        inbox = df_fn("""
            SELECT id, sender AS Von, message AS Nachricht,
                   priority AS Priorität, created_at AS Zeit
            FROM internal_messages
            WHERE recipient=? OR recipient='alle'
            ORDER BY created_at DESC LIMIT 50
        """, (me,))

        unread = df_fn("""
            SELECT COUNT(*) AS n FROM internal_messages
            WHERE (recipient=? OR recipient='alle')
              AND read_by NOT LIKE ?
        """, (me, f"%{me}%")).iloc[0]["n"]

        if int(unread) > 0:
            st.warning(f"🔔 {unread} ungelesene Nachricht(en)")

        if not inbox.empty:
            for _, msg in inbox.iterrows():
                prio_color = {"hoch":"#c0392b","normal":"#2980b9","niedrig":"#27ae60"}.get(
                    str(msg.get("Priorität","normal")), "#888")
                st.markdown(
                    f'<div style="border-left:3px solid {prio_color};padding:8px 12px;'
                    f'background:{prio_color}11;border-radius:4px;margin-bottom:6px;">'
                    f'<strong>Von: {msg["Von"]}</strong> '
                    f'<span style="color:#888;font-size:.8rem;">{str(msg["Zeit"])[:16]}</span><br/>'
                    f'{msg["Nachricht"]}</div>',
                    unsafe_allow_html=True
                )
                # Als gelesen markieren
                mid = int(msg["id"])
                current_read = df_fn("SELECT read_by FROM internal_messages WHERE id=?", (mid,))
                if not current_read.empty:
                    read_by = str(current_read.iloc[0]["read_by"] or "")
                    if me not in read_by:
                        run_fn("UPDATE internal_messages SET read_by=? WHERE id=?",
                               (f"{read_by},{me}".lstrip(","), mid))
        else:
            st.info("Keine Nachrichten.")

    with tabs[1]:
        users = df_fn("SELECT username FROM users WHERE active=1 ORDER BY username")
        with st.form("msg_form", clear_on_submit=True):
            recipient = st.selectbox("An", ["alle"] + (users["username"].tolist() if not users.empty else []))
            priority  = st.selectbox("Priorität", ["normal","hoch","niedrig"])
            message   = st.text_area("Nachricht *", height=100)
            if st.form_submit_button("📨 Senden", type="primary") and message:
                run_fn("INSERT INTO internal_messages(sender,recipient,message,priority) VALUES(?,?,?,?)",
                       (me, recipient, message, priority))
                st.success("✅ Nachricht gesendet!")
                st.rerun()

    with tabs[2]:
        if user.get("role","").lower() in ("admin","manager","administrator"):
            all_msgs = df_fn("""
                SELECT sender AS Von, recipient AS An, message AS Nachricht,
                       priority AS Priorität, created_at AS Zeit
                FROM internal_messages ORDER BY created_at DESC LIMIT 100
            """)
            if not all_msgs.empty:
                st.dataframe(all_msgs, use_container_width=True, height=400)
        else:
            st.info("Nur Admins/Manager sehen alle Nachrichten.")


# ─────────────────────────────────────────────────────────────
# 3. Mitarbeiter-Mini-App (eingeschränktes Dashboard)
# ─────────────────────────────────────────────────────────────

def page_employee_portal(df_fn, current_user_fn) -> None:
    st.title("👷 Mein Bereich")
    st.caption("Persönliche Übersicht: Schichten, Urlaub, Lohnzettel.")

    user = current_user_fn() or {}
    username = user.get("username", "")
    role     = user.get("role", "").lower()

    # Mitarbeiter-Datensatz zu diesem Login
    emp = df_fn("SELECT * FROM employees WHERE LOWER(name)=? OR employee_no=?",
                (username.lower(), username))

    if emp.empty:
        # Versuche via Settings
        emp = df_fn("SELECT * FROM employees WHERE active=1 ORDER BY name LIMIT 1")
        if emp.empty:
            st.info("Kein Mitarbeiterprofil gefunden. Bitte Admin kontaktieren.")
            return
        st.caption(f"Demo-Ansicht für: {emp.iloc[0]['name']}")

    eid = int(emp.iloc[0]["id"])
    emp_name = str(emp.iloc[0]["name"])

    st.subheader(f"👋 Hallo, {emp_name}!")

    tabs = st.tabs(["📅 Meine Schichten", "🏖️ Mein Urlaub", "💶 Mein Lohn", "💬 Nachrichten"])

    with tabs[0]:
        today = date.today().isoformat()
        next_month = (date.today() + timedelta(days=30)).isoformat()
        my_shifts = df_fn("""
            SELECT s.shift_date AS Datum, s.start_time AS Von, s.end_time AS Bis,
                   s.shift_type AS Typ, s.location AS Ort,
                   COALESCE(c.company,'–') AS Kunde, s.status AS Status
            FROM shifts s LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.employee_id=? AND s.shift_date >= ?
            ORDER BY s.shift_date, s.start_time LIMIT 30
        """, (eid, today))

        past_shifts = df_fn("""
            SELECT COUNT(*) AS n FROM shifts
            WHERE employee_id=? AND shift_date < ? AND status='abgeschlossen'
        """, (eid, today)).iloc[0]["n"]

        c1, c2 = st.columns(2)
        c1.metric("Kommende Schichten", len(my_shifts))
        c2.metric("Abgeschlossene (gesamt)", int(past_shifts))

        if not my_shifts.empty:
            st.dataframe(my_shifts, use_container_width=True)
        else:
            st.info("Keine zukünftigen Schichten geplant.")

    with tabs[1]:
        year_v = date.today().year
        balance = df_fn("SELECT * FROM leave_balances WHERE employee_id=? AND year=?", (eid, year_v))
        if not balance.empty:
            b = balance.iloc[0]
            c1, c2, c3 = st.columns(3)
            c1.metric("Jahresanspruch", f"{float(b.get('entitlement',24))} Tage")
            c2.metric("Genommen", f"{float(b.get('taken',0))} Tage")
            c3.metric("Rest", f"{float(b.get('entitlement',24)) - float(b.get('taken',0))} Tage")
        else:
            st.info("Noch kein Urlaubskonto für dieses Jahr angelegt.")

        my_leaves = df_fn("""
            SELECT leave_type AS Art, start_date AS Von, end_date AS Bis,
                   days_requested AS Tage, status AS Status
            FROM leave_requests WHERE employee_id=? ORDER BY start_date DESC LIMIT 20
        """, (eid,))
        if not my_leaves.empty:
            st.dataframe(my_leaves, use_container_width=True)

    with tabs[2]:
        my_pay = df_fn("""
            SELECT payroll_month AS Monat, gross_salary AS Brutto,
                   net_salary AS Netto, hours_worked AS Stunden
            FROM payroll_records WHERE employee_id=?
            ORDER BY payroll_month DESC LIMIT 12
        """, (eid,))
        if not my_pay.empty:
            st.dataframe(my_pay, use_container_width=True)
            st.bar_chart(my_pay.set_index("Monat")[["Netto"]])
        else:
            st.info("Noch keine Lohnabrechnungen vorhanden.")

    with tabs[3]:
        msgs = df_fn("""
            SELECT sender AS Von, message AS Nachricht, created_at AS Zeit
            FROM internal_messages
            WHERE recipient=? OR recipient='alle'
            ORDER BY created_at DESC LIMIT 20
        """, (username,))
        if not msgs.empty:
            st.dataframe(msgs, use_container_width=True)
        else:
            st.info("Keine Nachrichten.")
