# SMTP Setup Byblos Sicherheitsdienst

Standardwerte in dieser Version:

- SMTP Host: `mail.byblos-sicherheit.de`
- SMTP Port: `465`
- SSL: `aktiviert`
- Benutzer / Absender: `info@byblos-sicherheit.de`

Wichtig:
- Das echte Passwort wird nicht im Paket gespeichert.
- Passwort in der App unter **Einstellungen > SMTP** eintragen.
- Bei Port 465 muss SSL aktiv sein. STARTTLS ist für diese Konfiguration nicht vorgesehen.

Testablauf:
1. App starten.
2. Login als Admin.
3. Einstellungen öffnen.
4. SMTP-Passwort eintragen und speichern.
5. Eine Testrechnung oder Mahnung per E-Mail senden.
6. E-Mail-Protokoll prüfen.

Falls Versand fehlschlägt:
- Passwort prüfen.
- Mailbox/Provider prüfen, ob SMTP aktiviert ist.
- Firewall prüfen, ob ausgehende Verbindung zu Port 465 erlaubt ist.
