"""extensions_v2_sysutils.py – System-Utilities und Open-Source-Features"""
from __future__ import annotations
import secrets, string
from datetime import date, datetime
from pathlib import Path
import streamlit as st

CURRENT_VERSION = "2.0.0"

def generate_password(length=16, upper=True, lower=True, digits=True, symbols=True):
    alphabet = ""
    required = []
    if upper:   alphabet += string.ascii_uppercase; required.append(secrets.choice(string.ascii_uppercase))
    if lower:   alphabet += string.ascii_lowercase; required.append(secrets.choice(string.ascii_lowercase))
    if digits:  alphabet += string.digits; required.append(secrets.choice(string.digits))
    if symbols:
        syms = "!@#$%^&*()-_=+[]{}|;:,.<>?"
        alphabet += syms; required.append(secrets.choice(syms))
    if not alphabet: return ""
    rest = [secrets.choice(alphabet) for _ in range(length - len(required))]
    pw = required + rest
    for i in range(len(pw)-1, 0, -1):
        j = secrets.randbelow(i+1); pw[i], pw[j] = pw[j], pw[i]
    return "".join(pw)

def pw_strength(pw):
    s = 0
    if len(pw) >= 8: s += 20
    if len(pw) >= 12: s += 20
    if any(c.isupper() for c in pw): s += 15
    if any(c.islower() for c in pw): s += 15
    if any(c.isdigit() for c in pw): s += 15
    if any(c in "!@#$%^&*()" for c in pw): s += 15
    color = "#27ae60" if s >= 80 else "#e67e22" if s >= 50 else "#c0392b"
    label = "Sehr stark" if s >= 80 else "Stark" if s >= 60 else "Mittel" if s >= 40 else "Schwach"
    return s, label, color

def inject_mobile_css():
    st.markdown("""<style>
@media (max-width: 768px) {
    .stButton > button { min-height: 48px !important; font-size: 16px !important; }
    [data-testid="stDataFrame"] { overflow-x: auto !important; }
}
.stButton > button:hover { transform: translateY(-1px); transition: all 0.2s; }
[data-testid="metric-container"] { background:#1a1f2e; border:1px solid #2d3142; border-radius:8px; }
</style>""", unsafe_allow_html=True)

def check_for_updates():
    try:
        import urllib.request, json
        with urllib.request.urlopen(
            "https://api.github.com/repos/byblos-security/byblos-crm/releases/latest",
            timeout=4) as r:
            d = json.loads(r.read())
            latest = d.get("tag_name","").lstrip("v")
            return latest, latest != CURRENT_VERSION, d.get("html_url","")
    except Exception:
        return "", False, ""

def page_password_generator(run_fn, df_fn, hash_pw_fn):
    st.title("Passwort-Generator")
    col1, col2 = st.columns(2)
    length  = col1.slider("Laenge", 8, 64, 16)
    upper   = col1.checkbox("Grossbuchstaben", True)
    lower   = col1.checkbox("Kleinbuchstaben", True)
    digits  = col2.checkbox("Zahlen", True)
    symbols = col2.checkbox("Sonderzeichen", True)
    if "pw" not in st.session_state: st.session_state["pw"] = generate_password(length, upper, lower, digits, symbols)
    if col2.button("Neues Passwort", type="primary"):
        st.session_state["pw"] = generate_password(length, upper, lower, digits, symbols)
    pw = st.session_state["pw"]
    st.text_input("Passwort", pw)
    s, lbl, col = pw_strength(pw)
    st.markdown(f'<div style="background:{col}33;border:1px solid {col};padding:6px 12px;border-radius:6px;">Staerke: <b>{lbl}</b> ({s}/100)</div><div style="background:#0e1117;height:6px;border-radius:4px;margin:6px 0;"><div style="background:{col};width:{s}%;height:6px;border-radius:4px;"></div></div>', unsafe_allow_html=True)
    st.divider()
    st.subheader("Benutzer-Passwort aendern")
    users = df_fn("SELECT id, username FROM users ORDER BY username")
    if not users.empty:
        sel = st.selectbox("Benutzer", users["username"].tolist())
        p1 = st.text_input("Neues Passwort", type="password")
        p2 = st.text_input("Wiederholen", type="password")
        if st.button("Passwort setzen", type="primary"):
            if len(p1) < 8: st.error("Mind. 8 Zeichen.")
            elif p1 != p2: st.error("Stimmen nicht ueberein.")
            else:
                uid = int(users[users["username"]==sel].iloc[0]["id"])
                run_fn("UPDATE users SET password_hash=? WHERE id=?", (hash_pw_fn(p1), uid))
                st.success(f"Passwort fuer '{sel}' geaendert!")

def page_update_checker(get_setting_fn, set_setting_fn):
    st.title("Updates & Versionen")
    st.caption(f"Aktuelle Version: {CURRENT_VERSION}")
    auto = st.checkbox("Automatisch pruefen", get_setting_fn("auto_check_updates","1")=="1")
    set_setting_fn("auto_check_updates", "1" if auto else "0")
    if st.button("Jetzt pruefen", type="primary"):
        with st.spinner("Pruefe GitHub..."):
            latest, is_new, url = check_for_updates()
        if is_new:
            st.success(f"Neue Version: v{latest}")
            st.markdown(f"[Herunterladen]({url})")
        elif latest:
            st.success(f"Neueste Version ({CURRENT_VERSION}) bereits installiert")
        else:
            st.warning("GitHub nicht erreichbar: https://github.com/byblos-security/byblos-crm/releases")
    import sys, platform as pl
    st.markdown(f"Python {sys.version[:15]} | {pl.system()} {pl.release()} | Lizenz: MIT Open Source")

def page_protocol_export(df_fn, base_dir: Path):
    st.title("Protokoll-Export")
    from_d = st.date_input("Von", date.today().replace(day=1))
    to_d   = st.date_input("Bis", date.today())
    logs = df_fn(f"SELECT created_at AS Zeit, action AS Aktion, details AS Details FROM audit_log WHERE substr(created_at,1,10) BETWEEN '{from_d}' AND '{to_d}' ORDER BY created_at DESC LIMIT 500")
    if not logs.empty:
        st.metric("Eintraege", len(logs))
        st.dataframe(logs, use_container_width=True, height=350)
        csv = logs.to_csv(index=False, sep=";").encode("utf-8-sig")
        st.download_button("CSV herunterladen", csv, f"protokoll_{from_d}_{to_d}.csv")
    else:
        st.info("Keine Logs in diesem Zeitraum.")
