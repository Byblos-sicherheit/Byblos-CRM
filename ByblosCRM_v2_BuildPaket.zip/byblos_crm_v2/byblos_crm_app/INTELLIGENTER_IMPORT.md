# Intelligenter Import / Matching Engine

Diese Version erkennt neue Daten beim Import und speichert sie automatisch an der richtigen Stelle, wenn die Zuordnung sicher ist.

## Unterstützte Importe

- Bank/Kontoauszug: Datum, Empfänger/Auftraggeber, Verwendungszweck, Betrag
- Kunden: Firma/Kunde, Kundennummer, Ansprechpartner, E-Mail, Telefon, Adresse
- Rechnungen: Rechnungsnummer, Kunde, Datum, Netto/Brutto/Betrag, Beschreibung
- Ausgaben/BWA: Lieferant, Belegnummer, Datum, Betrag, Netto/Brutto, Kostenart

## Zuordnungslogik

1. Rechnungsnummer im Text = 100% Treffer
2. Gelernte Regel = standardmäßig 95% Treffer
3. Kundenname/Kundennummer erkannt = 90%+ Treffer
4. Exakter Restbetrag = Vorschlag
5. Unsichere Treffer bleiben in der Prüfliste

## Sicherheit

- Jeder Importdatensatz bekommt einen SHA-256-Fingerprint.
- Dubletten werden übersprungen.
- Treffer unter 90% werden nicht automatisch gespeichert.
- Manuelle Zuordnung kann als Lernregel gespeichert werden.

## Bedienung

1. In der App links auf `Intelligenter Import` gehen.
2. CSV/XLSX hochladen.
3. Erkannten Typ prüfen.
4. In Warteschlange übernehmen.
5. Sichere Treffer automatisch speichern oder unsichere Treffer einzeln prüfen.

## Wichtig

Automatik ersetzt keine steuerliche Prüfung. DATEV-Konten, BWA-Kategorien und GoBD-Ablage müssen final mit dem Steuerberater abgestimmt werden.
