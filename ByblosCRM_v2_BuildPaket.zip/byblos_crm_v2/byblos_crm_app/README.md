# Byblos CRM Web-App - Betriebs-Version

## Start lokal
```bash
pip install -r requirements.txt
streamlit run app.py
```

Erstlogin:
- Benutzer: `admin`
- Passwort: `admin123`

**Sofort nach dem ersten Login Passwort ändern:** Einstellungen -> Eigenes Passwort ändern.

## Enthalten
- Kundenverwaltung mit Kontakthistorie
- Rechnungen mit fortlaufender Rechnungsnummer, Positionen, MwSt. und PDF-Export
- PDF-Archivierung mit SHA-256-Prüfsumme
- Ausgaben/BWA inklusive Lieferanten, Beleg-Upload, Netto/Vorsteuer/Brutto
- Bankimport und Abgleich-Vorschläge
- DATEV-naher CSV-Export zur Abstimmung mit Steuerberater
- Dienstplan und Mitarbeiterverwaltung
- Dashboard mit KPIs
- Login, Rollen und Benutzerverwaltung
- E-Mail-Versand über SMTP inkl. E-Mail-Protokoll
- Archiv/GoBD-Bereich mit Checkliste
- Vollbackup als ZIP
- Audit-Log
- Dockerfile und docker-compose

## E-Mail-Versand einrichten
In der App: Einstellungen -> SMTP für E-Mail-Versand.
Benötigt werden SMTP Host, Port, Benutzer, Passwort/App-Passwort und Absenderadresse.

## Wichtiger Hinweis zu GoBD/DATEV
Die App unterstützt Archivierung, Audit-Log, Exporte und Prüfsummen. Eine rechtlich/steuerlich verbindliche GoBD- oder DATEV-Freigabe kann nur dein Steuerberater bzw. IT-Dienstleister nach Prüfung deiner konkreten Nutzung geben.

## Backup
In der App: Archiv/GoBD -> Backups -> Vollbackup jetzt erstellen.
Das Backup enthält Datenbank, generierte PDFs, Uploads, Assets und Archivordner.

## Erweiterung: Automatik / Monitoring

Diese Version enthält zusätzlich:
- neue App-Seite **Automatik / Monitoring**
- automatische Markierung überfälliger Rechnungen
- Mahnungen als Entwurf oder direkter SMTP-Versand
- automatische Bankabgleich-Vorschläge für neue Transaktionen
- tägliche KPI-Speicherung
- Vollbackup plus ZIP-/SHA-256-Prüfung
- Skripte für Cronjobs unter `scripts/`

### SMTP Byblos Sicherheitsdienst
Voreingestellt sind:
- Host: `mail.byblos-sicherheit.de`
- Port: `465`
- Benutzer: `info@byblos-sicherheit.de`
- SSL: aktiv

Das echte Passwort muss in der App unter **Einstellungen > SMTP** eingetragen werden.

### Automatische Jobs
Siehe `crontab_examples.txt`. Pfade vor Nutzung an den echten Serverpfad anpassen.

### Wichtiger Steuerhinweis
DATEV-Konten, BWA-Kategorien und GoBD-Prozess müssen final vom Steuerberater bestätigt werden. Die App unterstützt Export, Archiv, Prüfsummen und Audit-Log, ersetzt aber keine steuerliche Prüfung.

## Neu: Intelligenter Import

Die App enthält jetzt eine Matching Engine. Neue CSV/XLSX-Daten werden beim Import erkannt und in die richtige Stelle gespeichert:

- Banktransaktionen → Bankabgleich, Rechnungen oder Ausgaben
- Kundenlisten → Kundenverwaltung
- Rechnungslisten → Rechnungsverwaltung
- Ausgaben/Belege → Ausgaben/BWA

Sichere Treffer werden automatisch verarbeitet. Unsichere Treffer landen in der Prüfliste. Lernregeln können manuell angelegt oder aus geprüften Zuordnungen gespeichert werden.

Siehe: `INTELLIGENTER_IMPORT.md`
