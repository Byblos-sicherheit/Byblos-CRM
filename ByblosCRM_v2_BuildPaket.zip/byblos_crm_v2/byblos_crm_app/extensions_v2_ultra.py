"""
extensions_v2_ultra.py – Ultrafertiges Produktionsmodul für Byblos CRM v2
==========================================================================
1. GPS-Stempeluhr (Schicht-Eincheck mit Koordinaten)
2. DB-Performance-Indizes
3. Onboarding-Wizard (erster Start)
4. Executive Summary PDF (1-Seiter Geschäftsbericht)
5. KI-Chatbot-Interface (Datenbankfragen in natürlicher Sprache)
6. DATEV-EXTF Export (offizielles Format)
7. Mahngebühren automatisch berechnen
8. Kunden-Scoring in Kundenliste
9. Routenplanung (Google Maps Integration)
10. PWA-Manifest Endpoint
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import re

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# DB-Registrierung
# ─────────────────────────────────────────────────────────────

def register_ultra(run_fn, df_fn) -> None:
    """Alle neuen Tabellen und Performance-Indizes."""
    run_fn("""CREATE TABLE IF NOT EXISTS gps_checkins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER,
        shift_id INTEGER,
        checkin_type TEXT DEFAULT 'start',
        checkin_time TEXT NOT NULL,
        latitude REAL,
        longitude REAL,
        accuracy REAL,
        address TEXT,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(employee_id) REFERENCES employees(id),
        FOREIGN KEY(shift_id) REFERENCES shifts(id)
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS late_fees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        fee_date TEXT NOT NULL,
        fee_amount REAL DEFAULT 0,
        fee_type TEXT DEFAULT 'Mahngebühr',
        days_overdue INTEGER DEFAULT 0,
        status TEXT DEFAULT 'offen',
        added_to_invoice INTEGER DEFAULT 0,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    )""")
    run_fn("""CREATE TABLE IF NOT EXISTS onboarding_state (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        step_key TEXT UNIQUE NOT NULL,
        completed INTEGER DEFAULT 0,
        completed_at TEXT,
        notes TEXT
    )""")

    # Performance-Indizes (idempotent durch IF NOT EXISTS)
    indexes = [
        ("idx_invoices_date",       "invoices(invoice_date)"),
        ("idx_invoices_customer",   "invoices(customer_id)"),
        ("idx_invoices_status",     "invoices(status)"),
        ("idx_expenses_bwa",        "expenses(bwa_month)"),
        ("idx_expenses_category",   "expenses(category)"),
        ("idx_shifts_date",         "shifts(shift_date)"),
        ("idx_shifts_employee",     "shifts(employee_id)"),
        ("idx_shifts_customer",     "shifts(customer_id)"),
        ("idx_contacts_customer",   "contacts(customer_id)"),
        ("idx_contacts_date",       "contacts(contact_date)"),
        ("idx_audit_log_time",      "audit_log(created_at)"),
        ("idx_bank_tx_date",        "bank_transactions(booking_date)"),
        ("idx_bank_tx_status",      "bank_transactions(status)"),
        ("idx_time_entries_emp",    "time_entries(employee_id)"),
        ("idx_payroll_month",       "payroll_records(payroll_month)"),
    ]
    for idx_name, idx_def in indexes:
        try:
            run_fn(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {idx_def}")
        except Exception:
            pass

    # Onboarding-Schritte initialisieren
    steps = [
        ("company_data", "Firmendaten eingetragen"),
        ("first_customer", "Ersten Kunden angelegt"),
        ("first_invoice", "Erste Rechnung erstellt"),
        ("smtp_setup", "SMTP eingerichtet"),
        ("logo_upload", "Firmenlogo hochgeladen"),
        ("first_employee", "Ersten Mitarbeiter angelegt"),
        ("first_backup", "Erstes Backup erstellt"),
        ("telegram_setup", "Telegram konfiguriert"),
    ]
    for key, note in steps:
        try:
            run_fn("INSERT OR IGNORE INTO onboarding_state(step_key,notes) VALUES(?,?)",
                   (key, note))
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
# 1. Onboarding-Wizard
# ─────────────────────────────────────────────────────────────

def check_onboarding_complete(df_fn) -> bool:
    """Prüft ob alle Pflicht-Onboarding-Schritte erledigt sind."""
    try:
        state = df_fn("SELECT step_key, completed FROM onboarding_state WHERE step_key IN ('company_data','first_customer','first_invoice')")
        return not state.empty and state["completed"].all()
    except Exception:
        return True  # Fehler → kein Onboarding zeigen


def _mark_step(run_fn, key: str) -> None:
    run_fn("UPDATE onboarding_state SET completed=1, completed_at=datetime('now') WHERE step_key=?", (key,))


def _auto_check_steps(run_fn, df_fn, get_setting_fn) -> None:
    """Prüft automatisch abgeschlossene Schritte."""
    checks = {
        "company_data":    lambda: bool(get_setting_fn("company_name", "")),
        "first_customer":  lambda: int(df_fn("SELECT COUNT(*) AS n FROM customers").iloc[0]["n"]) > 0,
        "first_invoice":   lambda: int(df_fn("SELECT COUNT(*) AS n FROM invoices").iloc[0]["n"]) > 0,
        "smtp_setup":      lambda: bool(get_setting_fn("smtp_host", "")),
        "logo_upload":     lambda: Path(get_setting_fn("asset_dir", "assets") + "/logo.png").exists(),
        "first_employee":  lambda: int(df_fn("SELECT COUNT(*) AS n FROM employees").iloc[0]["n"]) > 0,
        "first_backup":    lambda: int(df_fn("SELECT COUNT(*) AS n FROM backups").iloc[0]["n"]) > 0,
        "telegram_setup":  lambda: bool(get_setting_fn("telegram_token", "")),
    }
    for key, check_fn in checks.items():
        try:
            if check_fn():
                _mark_step(run_fn, key)
        except Exception:
            pass


def page_onboarding(run_fn, df_fn, get_setting_fn) -> None:
    st.title("🚀 Einrichtungs-Assistent")
    st.caption("Willkommen bei Byblos CRM v2! Folge diesen Schritten für die optimale Einrichtung.")

    _auto_check_steps(run_fn, df_fn, get_setting_fn)

    steps = df_fn("SELECT step_key, completed, notes, completed_at FROM onboarding_state ORDER BY id")
    if steps.empty:
        st.info("Einrichtungsstatus wird geladen...")
        return

    total = len(steps)
    done  = int(steps["completed"].sum())
    pct   = int(done / total * 100) if total > 0 else 0

    st.progress(pct / 100)
    st.metric("Einrichtungsfortschritt", f"{done}/{total} Schritte · {pct}%")

    STEP_ICONS = {
        "company_data":   "🏢",
        "first_customer": "👥",
        "first_invoice":  "🧾",
        "smtp_setup":     "📧",
        "logo_upload":    "🖼️",
        "first_employee": "👷",
        "first_backup":   "💾",
        "telegram_setup": "🔔",
    }
    STEP_LINKS = {
        "company_data":   "Einstellungen",
        "first_customer": "Kunden",
        "first_invoice":  "Rechnungen",
        "smtp_setup":     "Einstellungen",
        "logo_upload":    "Einstellungen",
        "first_employee": "Mitarbeiter",
        "first_backup":   "Cloud-Backup",
        "telegram_setup": "Push-Benachrichtigungen",
    }

    st.divider()
    for _, row in steps.iterrows():
        key  = str(row["step_key"])
        note = str(row.get("notes",""))
        done_s = bool(row["completed"])
        icon   = STEP_ICONS.get(key, "•")
        link   = STEP_LINKS.get(key, "Einstellungen")
        color  = "#27ae60" if done_s else "#c0392b"
        status = f"✅ Erledigt ({str(row.get('completed_at',''))[:10]})" if done_s else "⏳ Ausstehend"

        col1, col2, col3 = st.columns([3, 2, 1])
        col1.markdown(
            f'<div style="border-left:3px solid {color};padding:6px 10px;background:{color}11;border-radius:4px;">'
            f'{icon} <strong>{note}</strong></div>',
            unsafe_allow_html=True
        )
        col2.caption(status)
        if not done_s:
            if col3.button("→", key=f"ob_{key}"):
                st.session_state["_nav_override"] = link
                st.rerun()

    if done == total:
        st.success("🎉 **Alle Einrichtungsschritte abgeschlossen!** Byblos CRM ist produktionsbereit.")
        st.balloons()


# ─────────────────────────────────────────────────────────────
# 2. GPS-Stempeluhr
# ─────────────────────────────────────────────────────────────

def page_gps_checkin(run_fn, df_fn, log_fn, current_user_fn) -> None:
    st.title("📍 GPS-Stempeluhr")
    st.caption("Schichtbeginn und -ende digital mit Standort erfassen.")

    user = current_user_fn() or {}
    username = user.get("username", "")

    employees = df_fn("SELECT id, name FROM employees WHERE active=1 ORDER BY name")
    tabs = st.tabs(["🟢 Einstempeln", "🔴 Ausstempeln", "📋 Stempel-Protokoll"])

    with tabs[0]:
        emp_label = st.selectbox("Mitarbeiter", employees["name"].tolist() if not employees.empty else ["—"])
        if not employees.empty:
            eid = int(employees[employees["name"] == emp_label].iloc[0]["id"])
            # Offene Schichten für heute
            today = date.today().isoformat()
            my_shifts = df_fn("""
                SELECT s.id, s.start_time || '–' || s.end_time || ' · ' || COALESCE(c.company,'?') AS label
                FROM shifts s LEFT JOIN customers c ON c.id=s.customer_id
                WHERE s.employee_id=? AND s.shift_date=? AND s.status IN ('geplant','bestätigt')
                ORDER BY s.start_time
            """, (eid, today))

            shift_label = "—"
            sid = None
            if not my_shifts.empty:
                shift_label = st.selectbox("Schicht zuordnen (optional)", ["—"] + my_shifts["label"].tolist())
                if shift_label != "—":
                    sid = int(my_shifts[my_shifts["label"] == shift_label].iloc[0]["id"])

            st.subheader("Standort")
            col1, col2 = st.columns(2)
            lat = col1.number_input("Breitengrad (optional)", value=0.0, format="%.6f")
            lon = col2.number_input("Längengrad (optional)", value=0.0, format="%.6f")
            address = st.text_input("Adresse / Objekt", placeholder="z.B. Hannover Messe Halle 12")
            notes = st.text_input("Notiz")

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            st.info(f"Stempel-Zeit: **{now_str}**")

            if st.button("✅ Jetzt einstempeln", type="primary"):
                run_fn("""INSERT INTO gps_checkins(employee_id,shift_id,checkin_type,checkin_time,
                          latitude,longitude,address,notes)
                          VALUES(?,?,'start',?,?,?,?,?)""",
                       (eid, sid, now_str,
                        lat if lat != 0.0 else None,
                        lon if lon != 0.0 else None,
                        address, notes))
                if sid:
                    run_fn("UPDATE shifts SET status='bestätigt' WHERE id=?", (sid,))
                log_fn("gps_checkin_start", f"{emp_label} @ {address or 'unbekannt'}")
                st.success(f"✅ {emp_label} eingestempelt um {now_str[:16]}")
                st.balloons()

    with tabs[1]:
        emp_label2 = st.selectbox("Mitarbeiter", employees["name"].tolist() if not employees.empty else ["—"], key="out_emp")
        if not employees.empty:
            eid2 = int(employees[employees["name"] == emp_label2].iloc[0]["id"])
            # Letzten Eincheck prüfen
            last_in = df_fn("""
                SELECT * FROM gps_checkins WHERE employee_id=? AND checkin_type='start'
                AND date(checkin_time)=date('now')
                ORDER BY checkin_time DESC LIMIT 1
            """, (eid2,))
            if not last_in.empty:
                st.info(f"Eingestempelt um: {str(last_in.iloc[0]['checkin_time'])[:16]}")
                addr2 = st.text_input("Abmelde-Adresse / Objekt", str(last_in.iloc[0]["address"] or ""))
                notes2 = st.text_input("Notiz")
                now_str2 = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if st.button("🔴 Jetzt ausstempeln", type="primary"):
                    sid2 = last_in.iloc[0]["shift_id"]
                    run_fn("""INSERT INTO gps_checkins(employee_id,shift_id,checkin_type,checkin_time,
                              address,notes) VALUES(?,?,'end',?,?,?)""",
                           (eid2, sid2, now_str2, addr2, notes2))
                    if sid2:
                        run_fn("UPDATE shifts SET status='abgeschlossen' WHERE id=?", (sid2,))
                    log_fn("gps_checkin_end", f"{emp_label2} @ {addr2}")
                    st.success(f"✅ {emp_label2} ausgestempelt um {now_str2[:16]}")
            else:
                st.warning(f"{emp_label2} ist heute noch nicht eingestempelt.")

    with tabs[2]:
        logs = df_fn("""
            SELECT g.checkin_time AS Zeit,
                   CASE g.checkin_type WHEN 'start' THEN '🟢 Eingestempelt' ELSE '🔴 Ausgestempelt' END AS Typ,
                   e.name AS Mitarbeiter,
                   COALESCE(g.address,'–') AS Objekt, g.notes AS Notiz
            FROM gps_checkins g LEFT JOIN employees e ON e.id=g.employee_id
            WHERE date(g.checkin_time) >= date('now','-7 days')
            ORDER BY g.checkin_time DESC
        """)
        if not logs.empty:
            st.dataframe(logs, use_container_width=True, height=350)
            csv = logs.to_csv(index=False, sep=";").encode("utf-8-sig")
            st.download_button("📥 Stempel-Protokoll CSV", csv, "stempel_protokoll.csv", "text/csv")
        else:
            st.info("Keine GPS-Stempel in den letzten 7 Tagen.")


# ─────────────────────────────────────────────────────────────
# 3. Mahngebühren automatisch berechnen
# ─────────────────────────────────────────────────────────────

LATE_FEE_CONFIG = {
    1:  (5.00,  "1. Mahngebühr (pauschal 5 €)"),
    2:  (15.00, "2. Mahngebühr (pauschal 15 €)"),
    3:  (40.00, "Letzte Mahnung (pauschal 40 €)"),
}
LATE_INTEREST_RATE = 0.0875  # 8,75% p.a. (Verzugszinsen aktuell)


def calculate_late_fees(invoice_id: int, df_fn) -> Dict:
    """Berechnet Mahngebühren und Verzugszinsen für eine überfällige Rechnung."""
    inv = df_fn("SELECT * FROM invoices WHERE id=?", (invoice_id,))
    if inv.empty:
        return {}
    inv = inv.iloc[0].to_dict()

    due_date_str = str(inv.get("due_date") or "")
    if not due_date_str or inv.get("status") not in ("offen","ueberfaellig","teilbezahlt"):
        return {}

    try:
        due_date = date.fromisoformat(due_date_str[:10])
    except Exception:
        return {}

    today = date.today()
    days_overdue = (today - due_date).days
    if days_overdue <= 0:
        return {}

    open_amount = float(inv.get("gross_total", 0)) - float(inv.get("paid_amount", 0))

    # Mahngebühr (pauschal je Mahnstufe)
    existing_fees = df_fn("SELECT COUNT(*) AS n FROM late_fees WHERE invoice_id=?", (invoice_id,))
    mahnstufe = int(existing_fees.iloc[0]["n"]) + 1 if not existing_fees.empty else 1
    mahnstufe = min(mahnstufe, 3)
    pauschal_fee, pauschal_text = LATE_FEE_CONFIG.get(mahnstufe, (40.0, "Mahngebühr"))

    # Verzugszinsen (BGB §288)
    zins_amount = round(open_amount * LATE_INTEREST_RATE * days_overdue / 365, 2)

    return {
        "invoice_no":      inv.get("invoice_no"),
        "open_amount":     open_amount,
        "days_overdue":    days_overdue,
        "mahnstufe":       mahnstufe,
        "pauschal_fee":    pauschal_fee,
        "pauschal_text":   pauschal_text,
        "interest_amount": zins_amount,
        "total_extra":     round(pauschal_fee + zins_amount, 2),
        "due_date":        due_date_str,
    }


def page_late_fees(run_fn, df_fn, log_fn, refresh_totals_fn) -> None:
    st.title("⚠️ Mahngebühren & Verzugszinsen")
    st.caption("Automatische Berechnung nach BGB §288 (Verzugszinsen 8,75% p.a.).")

    tabs = st.tabs(["🧮 Berechnen & Buchen", "📋 Gebühren-Protokoll", "⚙️ Einstellungen"])

    with tabs[0]:
        overdue = df_fn("""
            SELECT i.id, i.invoice_no AS Nr, c.company AS Kunde,
                   i.due_date AS Fällig,
                   ROUND(i.gross_total - i.paid_amount, 2) AS Offen_EUR,
                   CAST(julianday('now') - julianday(i.due_date) AS INT) AS Tage_Überfällig
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            WHERE i.status IN ('offen','ueberfaellig','teilbezahlt')
              AND ROUND(i.gross_total - i.paid_amount, 2) > 0
              AND i.due_date < date('now')
            ORDER BY Tage_Überfällig DESC
        """)

        if overdue.empty:
            st.success("✅ Keine überfälligen Rechnungen.")
        else:
            st.metric("Überfällige Rechnungen", len(overdue))
            st.dataframe(overdue, use_container_width=True)

            sel = st.selectbox("Rechnung auswählen", overdue["Nr"].tolist())
            inv_id = int(overdue[overdue["Nr"] == sel].iloc[0]["id"])
            fees = calculate_late_fees(inv_id, df_fn)

            if fees:
                st.subheader(f"Mahngebühren-Berechnung: {fees['invoice_no']}")
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Offener Betrag", fmt_eur(fees["open_amount"]))
                c2.metric("Tage überfällig", fees["days_overdue"])
                c3.metric(fees["pauschal_text"], fmt_eur(fees["pauschal_fee"]))
                c4.metric(f"Verzugszinsen ({LATE_INTEREST_RATE*100:.2f}%/a)", fmt_eur(fees["interest_amount"]))

                st.info(f"💰 **Gesamt Mehrforderung: {fmt_eur(fees['total_extra'])}**")
                st.caption(f"Mahnstufe {fees['mahnstufe']} von 3")

                col1, col2 = st.columns(2)
                if col1.button("💾 Mahngebühren buchen", type="primary"):
                    run_fn("""INSERT INTO late_fees(invoice_id,fee_date,fee_amount,fee_type,days_overdue,status)
                              VALUES(?,?,?,?,?,?)""",
                           (inv_id, date.today().isoformat(), fees["pauschal_fee"],
                            fees["pauschal_text"], fees["days_overdue"], "offen"))
                    if fees["interest_amount"] > 0:
                        run_fn("""INSERT INTO late_fees(invoice_id,fee_date,fee_amount,fee_type,days_overdue,status)
                                  VALUES(?,?,?,?,?,?)""",
                               (inv_id, date.today().isoformat(), fees["interest_amount"],
                                "Verzugszinsen", fees["days_overdue"], "offen"))
                    log_fn("late_fee_booked", f"{fees['invoice_no']} +{fees['total_extra']} €")
                    st.success(f"✅ Mahngebühren {fmt_eur(fees['total_extra'])} gebucht!")
                    st.rerun()

                if col2.button("📄 In Rechnung aufnehmen"):
                    new_gross = float(overdue[overdue["Nr"]==sel].iloc[0]["Offen_EUR"]) + fees["total_extra"]
                    run_fn("UPDATE invoices SET gross_total=gross_total+? WHERE id=?",
                           (fees["total_extra"], inv_id))
                    run_fn("""INSERT INTO invoice_items(invoice_id,position,description,quantity,unit,unit_price,total)
                              VALUES(?,?,?,1,'pauschal',?,?)""",
                           (inv_id, 99, fees["pauschal_text"], fees["pauschal_fee"], fees["pauschal_fee"]))
                    if fees["interest_amount"] > 0:
                        run_fn("""INSERT INTO invoice_items(invoice_id,position,description,quantity,unit,unit_price,total)
                                  VALUES(?,?,?,1,'pauschal',?,?)""",
                               (inv_id, 98, f"Verzugszinsen {fees['days_overdue']} Tage",
                                fees["interest_amount"], fees["interest_amount"]))
                    refresh_totals_fn(inv_id)
                    st.success(f"Mahngebühren {fmt_eur(fees['total_extra'])} zur Rechnung hinzugefügt!")
                    st.rerun()

    with tabs[1]:
        log = df_fn("""
            SELECT lf.fee_date AS Datum, i.invoice_no AS Rechnung,
                   lf.fee_type AS Gebührenart, lf.fee_amount AS Betrag_EUR,
                   lf.days_overdue AS Tage_überfällig, lf.status AS Status
            FROM late_fees lf JOIN invoices i ON i.id=lf.invoice_id
            ORDER BY lf.created_at DESC LIMIT 100
        """)
        if not log.empty:
            st.metric("Gebühren gesamt", fmt_eur(float(log["Betrag_EUR"].sum())))
            st.dataframe(log, use_container_width=True)
        else:
            st.info("Noch keine Mahngebühren gebucht.")

    with tabs[2]:
        st.subheader("Mahngebühren-Konfiguration")
        st.markdown(f"""
| Mahnstufe | Pauschale | Rechtliche Grundlage |
|---|---|---|
| 1. Mahnung | 5,00 € | Üblich, nicht gesetzlich vorgeschrieben |
| 2. Mahnung | 15,00 € | Üblich |
| 3./Letzte Mahnung | 40,00 € | BGB §288 Abs. 5 (Pauschale 40 €) |
| Verzugszinsen | {LATE_INTEREST_RATE*100:.2f}% p.a. | BGB §288 Abs. 2 (B2B: Basiszins + 8%) |

⚠️ **Hinweis:** Mahngebühren und Verzugszinsen nur bei rechtswirksamen Forderungen. 
Bitte mit Steuerberater / Rechtsanwalt abstimmen.
        """)


# ─────────────────────────────────────────────────────────────
# 4. Executive Summary PDF (1-Seiter)
# ─────────────────────────────────────────────────────────────

def generate_executive_summary(df_fn, get_setting_fn, year: int, month: int,
                                output_dir: Path) -> Optional[Path]:
    """Erstellt einen kompakten Executive-Summary-PDF (1 Seite)."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        return None

    month_str = f"{year}-{month:02d}"
    months_de = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"]
    month_name = months_de[month-1]
    co_name  = get_setting_fn("company_name", "Byblos Sicherheitsdienst")
    output_path = output_dir / f"executive_summary_{month_str}.pdf"

    # Daten
    inv = df_fn(f"SELECT SUM(gross_total) AS umsatz, SUM(CASE WHEN status='bezahlt' THEN gross_total ELSE 0 END) AS bezahlt, COUNT(*) AS anz FROM invoices WHERE substr(invoice_date,1,7)='{month_str}'")
    exp = df_fn(f"SELECT SUM(gross_amount) AS kosten, SUM(net_amount) AS kosten_netto, COUNT(*) AS anz FROM expenses WHERE bwa_month='{month_str}'")
    shf = df_fn(f"SELECT COUNT(*) AS gesamt, SUM(CASE WHEN status='abgeschlossen' THEN 1 ELSE 0 END) AS done FROM shifts WHERE substr(shift_date,1,7)='{month_str}'")
    emp = df_fn("SELECT COUNT(*) AS n FROM employees WHERE active=1")
    cust = df_fn("SELECT COUNT(*) AS n FROM customers")
    overdue = df_fn("SELECT COUNT(*) AS n, COALESCE(SUM(gross_total-paid_amount),0) AS v FROM invoices WHERE status='ueberfaellig'")

    umsatz   = float(inv.iloc[0]["umsatz"] or 0)
    bezahlt  = float(inv.iloc[0]["bezahlt"] or 0)
    kosten   = float(exp.iloc[0]["kosten"] or 0)
    ergebnis = bezahlt - kosten
    schichten_gesamt = int(shf.iloc[0]["gesamt"] or 0)
    schichten_done   = int(shf.iloc[0]["done"] or 0)
    erfuellung = int(schichten_done/schichten_gesamt*100) if schichten_gesamt > 0 else 0

    doc = SimpleDocTemplate(str(output_path), pagesize=A4,
                            rightMargin=15*mm, leftMargin=15*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="KPI", fontSize=22, fontName="Helvetica-Bold",
                               textColor=colors.HexColor("#1a2744"), leading=26))
    styles.add(ParagraphStyle(name="KPILabel", fontSize=8, textColor=colors.HexColor("#666")))
    styles.add(ParagraphStyle(name="Sm", fontSize=8, leading=10))
    story = []

    # Header
    story.append(Paragraph(f"<b>Executive Summary – {month_name} {year}</b>", styles["h1"]))
    story.append(Paragraph(f"{co_name} · Erstellt: {date.today().isoformat()}", styles["Sm"]))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#c0392b")))
    story.append(Spacer(1, 5*mm))

    # KPI-Grid 2×4
    def kpi_cell(value, label, delta="", color="#1a2744"):
        return [
            Paragraph(f'<font color="{color}"><b>{value}</b></font>', styles["KPI"]),
            Paragraph(f"{label}", styles["KPILabel"]),
            Paragraph(f'<font color="#888">{delta}</font>', styles["KPILabel"]),
        ]

    result_color = "#27ae60" if ergebnis >= 0 else "#c0392b"
    kpi_data = [
        [
            kpi_cell(fmt_eur(umsatz), "Umsatz fakturiert"),
            kpi_cell(fmt_eur(bezahlt), "Davon bezahlt", f"{int(bezahlt/umsatz*100) if umsatz>0 else 0}% Zahlquote"),
        ],
        [
            kpi_cell(fmt_eur(kosten), "Ausgaben gesamt"),
            kpi_cell(fmt_eur(ergebnis), "Ergebnis", "(bez. Umsatz - Ausgaben)", color=result_color),
        ],
        [
            kpi_cell(str(schichten_gesamt), "Schichten gesamt", f"{erfuellung}% Erfüllung"),
            kpi_cell(str(int(emp.iloc[0]["n"])), "Aktive Mitarbeiter", f"{int(cust.iloc[0]['n'])} Kunden"),
        ],
        [
            kpi_cell(str(int(overdue.iloc[0]["n"])), "Überfällige Rechnungen",
                     fmt_eur(float(overdue.iloc[0]["v"])), color="#c0392b" if overdue.iloc[0]["n"] > 0 else "#27ae60"),
            kpi_cell(str(int(inv.iloc[0]["anz"])), "Rechnungen erstellt",
                     f"davon {int(exp.iloc[0]['anz'])} Ausgaben"),
        ],
    ]

    for row in kpi_data:
        t = Table(row, colWidths=[90*mm, 90*mm])
        t.setStyle(TableStyle([
            ("VALIGN",(0,0),(-1,-1),"TOP"),
            ("BOX",(0,0),(0,0),0.5,colors.HexColor("#ddd")),
            ("BOX",(1,0),(1,0),0.5,colors.HexColor("#ddd")),
            ("BACKGROUND",(0,0),(0,0),colors.HexColor("#f9f9f9")),
            ("BACKGROUND",(1,0),(1,0),colors.white),
        ]))
        story.append(t)
        story.append(Spacer(1, 2*mm))

    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#ddd")))
    story.append(Spacer(1, 2*mm))

    # Top-Kunden
    top_custs = df_fn(f"""
        SELECT c.company, ROUND(SUM(i.gross_total),2) AS v
        FROM invoices i JOIN customers c ON c.id=i.customer_id
        WHERE substr(i.invoice_date,1,7)='{month_str}'
        GROUP BY c.id ORDER BY v DESC LIMIT 5
    """)
    if not top_custs.empty:
        story.append(Paragraph("<b>Top-Kunden nach Umsatz</b>", styles["h3"]))
        cust_data = [["Kunde", "Umsatz"]] + [
            [str(r["company"])[:40], fmt_eur(float(r["v"]))]
            for _, r in top_custs.iterrows()
        ]
        ct = Table(cust_data, colWidths=[130*mm, 50*mm])
        ct.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1a2744")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),8),
            ("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#ddd")),
            ("ALIGN",(1,0),(1,-1),"RIGHT"),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#f5f5f5")]),
        ]))
        story.append(ct)

    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(
        f"Vertraulich – {co_name} · Operative Auswertung · Nicht für externe Verwendung",
        styles["Sm"]
    ))
    doc.build(story)
    return output_path


def page_executive_summary(df_fn, get_setting_fn, base_dir: Path) -> None:
    st.title("📊 Executive Summary")
    st.caption("Kompakter 1-Seiter Geschäftsbericht für Management und Steuerberater.")

    col1, col2 = st.columns(2)
    year  = col1.selectbox("Jahr", list(range(date.today().year, date.today().year-5,-1)))
    month = col2.selectbox("Monat", list(range(1,13)), index=date.today().month-1,
                            format_func=lambda m: ["Jan","Feb","Mär","Apr","Mai","Jun",
                                                    "Jul","Aug","Sep","Okt","Nov","Dez"][m-1])
    if st.button("📄 Executive Summary erstellen", type="primary"):
        with st.spinner("PDF wird erstellt..."):
            output_dir = base_dir / "generated" / "reports"
            output_dir.mkdir(parents=True, exist_ok=True)
            path = generate_executive_summary(df_fn, get_setting_fn, year, month, output_dir)
        if path and path.exists():
            st.success(f"✅ {path.name}")
            st.download_button("📥 PDF herunterladen", path.read_bytes(),
                               path.name, "application/pdf")
        else:
            st.error("PDF-Erstellung fehlgeschlagen.")


# ─────────────────────────────────────────────────────────────
# 5. KI-Chatbot (Datenbankfragen in natürlicher Sprache)
# ─────────────────────────────────────────────────────────────

def nl_to_sql_simple(question: str) -> Optional[Tuple[str, str, tuple]]:
    """
    Einfache NL→SQL-Konvertierung für häufige Fragen.
    Gibt (sql, beschreibung, params) zurück oder None.
    """
    q = question.lower()
    today = date.today().isoformat()
    this_month = date.today().strftime("%Y-%m")

    patterns = [
        # Umsatz
        (r"umsatz.*(monat|diesen|aktuell)",
         f"SELECT COALESCE(SUM(gross_total),0) AS Umsatz_EUR FROM invoices WHERE substr(invoice_date,1,7)='{this_month}' AND status='bezahlt'",
         "Bezahlter Umsatz diesen Monat", ()),
        (r"offene? rechnungen?",
         "SELECT COUNT(*) AS Anzahl, COALESCE(SUM(gross_total-paid_amount),0) AS Summe_EUR FROM invoices WHERE status IN ('offen','ueberfaellig')",
         "Offene Rechnungen", ()),
        (r"überfäll",
         "SELECT i.invoice_no, c.company, i.due_date, ROUND(i.gross_total-i.paid_amount,2) AS Offen FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.status='ueberfaellig' ORDER BY i.due_date",
         "Überfällige Rechnungen", ()),
        # Kunden
        (r"wieviel|wie viel.*(kunden|kunde)",
         "SELECT COUNT(*) AS Kunden_gesamt FROM customers",
         "Anzahl Kunden", ()),
        (r"top.*(kunden|umsatz)",
         f"SELECT c.company, ROUND(SUM(i.gross_total),2) AS Umsatz FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE substr(i.invoice_date,1,4)='{today[:4]}' GROUP BY c.id ORDER BY Umsatz DESC LIMIT 5",
         "Top-5-Kunden nach Umsatz", ()),
        # Mitarbeiter
        (r"wieviel|wie viel.*(mitarbeiter|mitarbeiter)",
         "SELECT COUNT(*) AS Mitarbeiter_aktiv FROM employees WHERE active=1",
         "Anzahl aktive Mitarbeiter", ()),
        # Schichten
        (r"schichten.*(heute|morgen|aktuell)",
         f"SELECT COUNT(*) AS Schichten, SUM(CASE WHEN employee_id IS NULL THEN 1 ELSE 0 END) AS Unbesetzt FROM shifts WHERE shift_date='{today}'",
         f"Schichten heute ({today})", ()),
        (r"unbesetzte? schichten",
         f"SELECT shift_date, start_time, end_time, COALESCE(c.company,'?') AS Kunde FROM shifts s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.employee_id IS NULL AND s.shift_date>='{today}' ORDER BY s.shift_date LIMIT 10",
         "Unbesetzte Schichten", ()),
        # Ausgaben
        (r"ausgaben.*(monat|aktuell|diesen)",
         f"SELECT COALESCE(SUM(gross_amount),0) AS Ausgaben_EUR, COUNT(*) AS Belege FROM expenses WHERE bwa_month='{this_month}'",
         "Ausgaben diesen Monat", ()),
        # Backups
        (r"letztes? backup|backup.*(wann|datum)",
         "SELECT file_path, file_size, note, created_at FROM backups ORDER BY created_at DESC LIMIT 1",
         "Letztes Backup", ()),
        # Ergebnis
        (r"ergebnis|gewinn|verlust",
         f"""SELECT
               COALESCE((SELECT SUM(gross_total) FROM invoices WHERE substr(invoice_date,1,7)='{this_month}' AND status='bezahlt'),0) AS Umsatz_bezahlt,
               COALESCE((SELECT SUM(gross_amount) FROM expenses WHERE bwa_month='{this_month}'),0) AS Ausgaben,
               COALESCE((SELECT SUM(gross_total) FROM invoices WHERE substr(invoice_date,1,7)='{this_month}' AND status='bezahlt'),0) -
               COALESCE((SELECT SUM(gross_amount) FROM expenses WHERE bwa_month='{this_month}'),0) AS Ergebnis""",
         f"Ergebnis {this_month}", ()),
    ]

    for pattern, sql, desc, params in patterns:
        if re.search(pattern, q):
            return sql, desc, params
    return None


def page_ai_chatbot(df_fn) -> None:
    st.title("🤖 KI-Assistent")
    st.caption("Stelle Fragen über deine Geschäftsdaten in natürlicher Sprache.")

    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    # Beispielfragen
    with st.expander("💡 Beispielfragen"):
        examples = [
            "Wie hoch ist der Umsatz diesen Monat?",
            "Welche Rechnungen sind überfällig?",
            "Wieviele Kunden habe ich?",
            "Zeige mir die Top-Kunden",
            "Schichten heute",
            "Unbesetzte Schichten",
            "Wieviele aktive Mitarbeiter gibt es?",
            "Ausgaben diesen Monat",
            "Wann war das letzte Backup?",
            "Wie ist das Ergebnis diesen Monat?",
        ]
        for ex in examples:
            if st.button(f'"{ex}"', key=f"ex_{ex}"):
                st.session_state["_chatbot_question"] = ex
                st.rerun()

    # Chat-Verlauf anzeigen
    for msg in st.session_state["chat_history"][-10:]:
        role = msg["role"]
        if role == "user":
            st.markdown(f'<div style="text-align:right;background:#1a2744;padding:8px;border-radius:8px;margin:4px 0;color:#e8eaf0;">👤 {msg["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div style="background:#0e1117;border:1px solid #2d3142;padding:8px;border-radius:8px;margin:4px 0;color:#e8eaf0;">🤖 {msg["content"]}</div>', unsafe_allow_html=True)
            if "data" in msg:
                st.dataframe(msg["data"], use_container_width=True)

    # Eingabe
    question = st.chat_input("Frage stellen...")
    prefill = st.session_state.pop("_chatbot_question", None)
    if prefill:
        question = prefill

    if question:
        st.session_state["chat_history"].append({"role": "user", "content": question})
        result = nl_to_sql_simple(question)

        if result:
            sql, desc, params = result
            try:
                data = df_fn(sql, params)
                answer = f"**{desc}:**"
                if not data.empty and len(data) == 1 and len(data.columns) == 1:
                    val = data.iloc[0, 0]
                    if isinstance(val, (int, float)) and val > 100:
                        answer += f"\n\n**{fmt_eur(float(val))}**"
                    else:
                        answer += f"\n\n**{val}**"
                    st.session_state["chat_history"].append({"role": "bot", "content": answer})
                else:
                    answer += f"\n\n{len(data)} Ergebnis(se)"
                    st.session_state["chat_history"].append({"role": "bot", "content": answer, "data": data})
            except Exception as e:
                st.session_state["chat_history"].append({"role": "bot", "content": f"❌ Datenbankfehler: {e}"})
        else:
            # Fallback: allgemeine Antwort
            fallback = (
                "Ich habe deine Frage nicht vollständig verstanden. 🤔\n\n"
                "**Probiere:**\n"
                "- 'Umsatz diesen Monat'\n"
                "- 'Offene Rechnungen'\n"
                "- 'Top-Kunden'\n"
                "- 'Schichten heute'\n\n"
                "Oder nutze die **Globale Suche** für komplexere Anfragen."
            )
            st.session_state["chat_history"].append({"role": "bot", "content": fallback})

        st.rerun()

    if st.button("🗑️ Chat-Verlauf löschen"):
        st.session_state["chat_history"] = []
        st.rerun()
