"""
extensions_v2_polish.py – Finales Feinschliff-Modul für Byblos CRM v2
=====================================================================
Enthält:
  1. Verbesserter Schnellstart-Screen (nach Login)
  2. PDF-Monatsbericht (ReportLab)
  3. Globaler Fehler-Handler für Streamlit
  4. Sitzungs-Timeout-Warnung
  5. Druck-Funktion für Berichte
  6. Verbesserte Automatik-E-Mail-Templates
  7. Massenaktionen (Rechnungen als bezahlt markieren)
  8. Globale Suchfunktion (Cross-Table)
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import streamlit as st


def fmt_eur(v: float) -> str:
    return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


# ─────────────────────────────────────────────────────────────
# 1. Globale Suche (Cross-Table)
# ─────────────────────────────────────────────────────────────

def page_global_search(df_fn) -> None:
    """Globale Suche über alle Haupttabellen."""
    st.title("🔍 Globale Suche")

    q = st.text_input("Suchbegriff eingeben (min. 3 Zeichen)", "")
    if len(q) < 3:
        st.info("Bitte mindestens 3 Zeichen eingeben.")
        return

    results_found = 0
    q_like = f"%{q}%"

    with st.spinner("Suche läuft..."):

        # Kunden
        cust = df_fn("""
            SELECT 'Kunde' AS Typ, customer_no AS Nr, company AS Name,
                   email AS Details, NULL AS Betrag
            FROM customers
            WHERE company LIKE ? OR customer_no LIKE ?
               OR contact_person LIKE ? OR email LIKE ?
            LIMIT 20
        """, (q_like, q_like, q_like, q_like))

        # Rechnungen
        inv = df_fn("""
            SELECT 'Rechnung' AS Typ, i.invoice_no AS Nr, c.company AS Name,
                   i.description AS Details, i.gross_total AS Betrag
            FROM invoices i JOIN customers c ON c.id=i.customer_id
            WHERE i.invoice_no LIKE ? OR c.company LIKE ? OR i.description LIKE ?
            LIMIT 20
        """, (q_like, q_like, q_like))

        # Ausgaben
        exp = df_fn("""
            SELECT 'Ausgabe' AS Typ, e.expense_no AS Nr,
                   COALESCE(s.name,'–') AS Name,
                   e.description AS Details, e.gross_amount AS Betrag
            FROM expenses e LEFT JOIN suppliers s ON s.id=e.supplier_id
            WHERE e.expense_no LIKE ? OR e.description LIKE ? OR s.name LIKE ?
            LIMIT 20
        """, (q_like, q_like, q_like))

        # Mitarbeiter
        emp = df_fn("""
            SELECT 'Mitarbeiter' AS Typ, employee_no AS Nr, name AS Name,
                   email AS Details, NULL AS Betrag
            FROM employees
            WHERE name LIKE ? OR employee_no LIKE ? OR email LIKE ?
            LIMIT 10
        """, (q_like, q_like, q_like))

        # Kontakte
        cont = df_fn("""
            SELECT 'Kontakt' AS Typ, co.contact_date AS Nr,
                   c.company AS Name, co.subject AS Details, NULL AS Betrag
            FROM contacts co JOIN customers c ON c.id=co.customer_id
            WHERE co.subject LIKE ? OR co.note LIKE ? OR c.company LIKE ?
            LIMIT 10
        """, (q_like, q_like, q_like))

        # Schichten
        shifts = df_fn("""
            SELECT 'Schicht' AS Typ, s.shift_date AS Nr,
                   COALESCE(e.name,'unbesetzt') AS Name,
                   COALESCE(c.company||' – '||s.location,'') AS Details,
                   NULL AS Betrag
            FROM shifts s
            LEFT JOIN employees e ON e.id=s.employee_id
            LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.shift_date LIKE ? OR s.location LIKE ?
               OR c.company LIKE ? OR e.name LIKE ?
            LIMIT 10
        """, (q_like, q_like, q_like, q_like))

    all_results = pd.concat(
        [df for df in [cust, inv, exp, emp, cont, shifts] if not df.empty],
        ignore_index=True
    )

    if all_results.empty:
        st.warning(f"Keine Ergebnisse für »{q}«")
        return

    results_found = len(all_results)
    st.success(f"**{results_found} Treffer** für »{q}«")

    # Nach Typ gruppiert anzeigen
    for typ in ["Kunde", "Rechnung", "Ausgabe", "Mitarbeiter", "Kontakt", "Schicht"]:
        group = all_results[all_results["Typ"] == typ]
        if not group.empty:
            st.subheader(f"{'👥' if typ=='Kunde' else '🧾' if typ=='Rechnung' else '📤' if typ=='Ausgabe' else '👷' if typ=='Mitarbeiter' else '📞' if typ=='Kontakt' else '📅'} {typ} ({len(group)})")
            disp = group.drop(columns=["Typ"]).copy()
            if "Betrag" in disp.columns:
                disp["Betrag"] = disp["Betrag"].apply(
                    lambda v: fmt_eur(float(v)) if v and str(v) != "nan" else ""
                )
            st.dataframe(disp, use_container_width=True)


# ─────────────────────────────────────────────────────────────
# 2. Massenaktionen
# ─────────────────────────────────────────────────────────────

def page_bulk_actions(run_fn, df_fn, log_fn, refresh_inv_fn, gen_pdf_fn, queue_email_fn) -> None:
    """Massenaktionen für Rechnungen, Schichten, Ausgaben."""
    st.title("⚡ Massenaktionen")

    tabs = st.tabs([
        "🧾 Rechnungen", "📅 Schichten", "📤 Ausgaben", "📨 Massen-E-Mail"
    ])

    # ── Rechnungen Massenaktionen ─────────────────────────────
    with tabs[0]:
        st.subheader("Rechnungen massenweise verarbeiten")

        action = st.selectbox("Aktion auswählen", [
            "Ausgewählte als 'bezahlt' markieren",
            "Ausgewählte als 'storniert' markieren",
            "PDFs für ausgewählte erstellen",
            "Mahnungen für überfällige vorbereiten",
        ])

        # Filter
        col1, col2 = st.columns(2)
        status_filter = col1.selectbox("Rechnungen filtern", ["offen", "ueberfaellig", "alle"])
        month_filter = col2.text_input("Monat (YYYY-MM, leer = alle)")

        query = """
            SELECT i.id, i.invoice_no AS Nr, c.company AS Kunde,
                   i.invoice_date AS Datum, i.due_date AS Fällig,
                   ROUND(i.gross_total - i.paid_amount, 2) AS Offen_EUR,
                   i.status AS Status
            FROM invoices i JOIN customers c ON c.id=i.customer_id
        """
        params = []
        where = []
        if status_filter != "alle":
            where.append("i.status = ?"); params.append(status_filter)
        if month_filter:
            where.append("substr(i.invoice_date,1,7) = ?"); params.append(month_filter)
        if where:
            query += " WHERE " + " AND ".join(where)
        query += " ORDER BY i.invoice_date"

        inv_list = df_fn(query, tuple(params))

        if inv_list.empty:
            st.info("Keine Rechnungen in dieser Auswahl.")
        else:
            st.caption(f"{len(inv_list)} Rechnungen · {fmt_eur(float(inv_list['Offen_EUR'].sum()))} offen")
            selected_nrs = st.multiselect(
                "Rechnungen auswählen (leer = alle gefilterten)",
                inv_list["Nr"].tolist()
            )
            target = inv_list[inv_list["Nr"].isin(selected_nrs)] if selected_nrs else inv_list
            st.caption(f"→ {len(target)} Rechnungen betroffen")

            if st.button(f"▶️ Ausführen: {action}", type="primary"):
                count = 0
                with st.spinner("Wird ausgeführt..."):
                    for _, row in target.iterrows():
                        iid = int(row["id"])
                        if action == "Ausgewählte als 'bezahlt' markieren":
                            run_fn("UPDATE invoices SET status='bezahlt', paid_amount=gross_total, paid_date=? WHERE id=?",
                                   (date.today().isoformat(), iid))
                            refresh_inv_fn(iid)
                        elif action == "Ausgewählte als 'storniert' markieren":
                            run_fn("UPDATE invoices SET status='storniert' WHERE id=?", (iid,))
                        elif action == "PDFs für ausgewählte erstellen":
                            try:
                                gen_pdf_fn(iid)
                            except Exception:
                                pass
                        elif action == "Mahnungen für überfällige vorbereiten":
                            inv_d = df_fn("SELECT i.*, c.email, c.company FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=?", (iid,))
                            if not inv_d.empty:
                                r = inv_d.iloc[0]
                                email = str(r.get("email") or "")
                                if email:
                                    rest = float(r["gross_total"]) - float(r.get("paid_amount") or 0)
                                    queue_email_fn(
                                        email,
                                        f"Mahnung {r['invoice_no']} – {rest:.2f} €",
                                        f"Sehr geehrte Damen und Herren,\n\n"
                                        f"die Rechnung {r['invoice_no']} vom {r['invoice_date']} "
                                        f"über {rest:.2f} EUR ist seit dem {r.get('due_date','')} fällig.\n\n"
                                        f"Bitte überweisen Sie den Betrag umgehend.\n\n"
                                        f"Mit freundlichen Grüßen\nByblos Sicherheitsdienst & Service",
                                        str(r.get("pdf_path") or "")
                                    )
                        count += 1
                log_fn("bulk_action", f"{action}: {count} Rechnungen")
                st.success(f"✅ {action} für {count} Rechnungen ausgeführt!")
                st.rerun()

    # ── Schichten Massenaktionen ──────────────────────────────
    with tabs[1]:
        st.subheader("Schichten massenweise verarbeiten")
        col1, col2 = st.columns(2)
        from_date = col1.date_input("Von", date.today().replace(day=1))
        to_date   = col2.date_input("Bis", date.today())
        shift_action = st.selectbox("Aktion", [
            "Als 'abgeschlossen' markieren",
            "Als 'bestätigt' markieren",
            "Als 'ausgefallen' markieren",
        ])
        shift_status_f = st.selectbox("Nur Schichten mit Status", ["geplant", "bestätigt", "alle"])

        q2 = """
            SELECT s.id, s.shift_date AS Datum, s.start_time AS Von, s.end_time AS Bis,
                   COALESCE(e.name,'unbesetzt') AS Mitarbeiter,
                   COALESCE(c.company,'–') AS Kunde, s.status AS Status
            FROM shifts s
            LEFT JOIN employees e ON e.id=s.employee_id
            LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.shift_date BETWEEN ? AND ?
        """
        p2 = [from_date.isoformat(), to_date.isoformat()]
        if shift_status_f != "alle":
            q2 += " AND s.status = ?"
            p2.append(shift_status_f)
        q2 += " ORDER BY s.shift_date, s.start_time"

        shifts_list = df_fn(q2, tuple(p2))
        if shifts_list.empty:
            st.info("Keine Schichten in dieser Auswahl.")
        else:
            st.caption(f"{len(shifts_list)} Schichten")
            st.dataframe(shifts_list.drop(columns=["id"]).head(20), use_container_width=True)
            if st.button(f"▶️ {shift_action} für alle {len(shifts_list)} Schichten"):
                new_status = {
                    "Als 'abgeschlossen' markieren": "abgeschlossen",
                    "Als 'bestätigt' markieren": "bestätigt",
                    "Als 'ausgefallen' markieren": "ausgefallen",
                }.get(shift_action, "bestätigt")
                for _, row in shifts_list.iterrows():
                    run_fn("UPDATE shifts SET status=? WHERE id=?", (new_status, int(row["id"])))
                log_fn("bulk_shifts", f"{shift_action}: {len(shifts_list)} Schichten")
                st.success(f"✅ {len(shifts_list)} Schichten → '{new_status}'")
                st.rerun()

    # ── Ausgaben Massenaktionen ───────────────────────────────
    with tabs[2]:
        st.subheader("Ausgaben massenweise als bezahlt markieren")
        pay_month = st.text_input("Monat (YYYY-MM)", date.today().strftime("%Y-%m"), key="bulk_exp_month")
        exp_list = df_fn("""
            SELECT id, expense_no AS Nr, description AS Beschreibung,
                   gross_amount AS Brutto, status AS Status
            FROM expenses WHERE bwa_month=? AND status!='bezahlt'
            ORDER BY expense_date
        """, (pay_month,))

        if exp_list.empty:
            st.success(f"✅ Alle Ausgaben in {pay_month} bereits bezahlt.")
        else:
            total = float(exp_list["Brutto"].sum())
            st.caption(f"{len(exp_list)} offene Ausgaben · {fmt_eur(total)}")
            st.dataframe(exp_list.drop(columns=["id"]), use_container_width=True)
            pay_date = st.date_input("Zahlungsdatum", date.today(), key="bulk_exp_date")
            if st.button(f"💳 Alle {len(exp_list)} Ausgaben als bezahlt markieren", type="primary"):
                for _, row in exp_list.iterrows():
                    run_fn("UPDATE expenses SET status='bezahlt', paid_amount=gross_amount, paid_date=? WHERE id=?",
                           (pay_date.isoformat(), int(row["id"])))
                log_fn("bulk_expenses_paid", f"{len(exp_list)} Ausgaben in {pay_month}")
                st.success(f"✅ {len(exp_list)} Ausgaben bezahlt!")
                st.rerun()

    # ── Massen-E-Mail ─────────────────────────────────────────
    with tabs[3]:
        st.subheader("📨 Massen-E-Mail an Kunden")
        st.warning("⚠️ Nur für legitime Geschäftskommunikation verwenden.")

        customers_mail = df_fn("SELECT id, company, email FROM customers WHERE email!='' ORDER BY company")
        if customers_mail.empty:
            st.info("Keine Kunden mit E-Mail-Adresse.")
            return

        selected_customers = st.multiselect(
            "Empfänger auswählen",
            customers_mail["company"].tolist(),
            help="Leer lassen = alle Kunden mit E-Mail"
        )
        target_custs = customers_mail[customers_mail["company"].isin(selected_customers)] if selected_customers else customers_mail
        st.caption(f"→ {len(target_custs)} Empfänger")

        with st.form("mass_email_form"):
            subject = st.text_input("Betreff *")
            body = st.text_area("E-Mail-Text *", height=200)
            salutation = st.checkbox("Individuelle Anrede (Sehr geehrte…, Firmenname)", value=True)
            dry_run = st.checkbox("Vorschau nur (keine E-Mails senden)", value=True)
            submitted = st.form_submit_button("📨 Senden / Vorbereiten", type="primary")

        if submitted and subject and body:
            count = 0
            for _, row in target_custs.iterrows():
                email = str(row["email"])
                company = str(row["company"])
                personal_body = (f"Sehr geehrte Damen und Herren von {company},\n\n" + body) if salutation else body
                if not dry_run:
                    queue_email_fn(email, subject, personal_body, "")
                count += 1
            if dry_run:
                st.info(f"Vorschau: {count} E-Mails würden vorbereitet werden. Haken Sie 'Vorschau' ab um wirklich zu senden.")
            else:
                log_fn("mass_email", f"{count} E-Mails vorbereitet: {subject}")
                st.success(f"✅ {count} E-Mails in der Warteschlange.")


# ─────────────────────────────────────────────────────────────
# 3. Verbessertes Schnellstart-Cockpit
# ─────────────────────────────────────────────────────────────

def render_startup_tips(df_fn) -> None:
    """Zeigt beim ersten Start Hinweise und fehlende Einrichtungsschritte."""
    customers_n = int(df_fn("SELECT COUNT(*) AS n FROM customers").iloc[0]["n"])
    inv_n       = int(df_fn("SELECT COUNT(*) AS n FROM invoices").iloc[0]["n"])
    smtp_set    = bool(df_fn("SELECT value FROM settings WHERE key='smtp_host' AND value!=''").shape[0] > 0)
    logo_ok     = (Path(__file__).resolve().parent / "assets" / "logo.png").exists()
    backup_n    = int(df_fn("SELECT COUNT(*) AS n FROM backups").iloc[0]["n"])

    tips = []
    if customers_n == 0:
        tips.append(("👥 Kunden anlegen", "Noch keine Kunden vorhanden.", "Kunden"))
    if not smtp_set:
        tips.append(("📧 SMTP einrichten", "Kein SMTP konfiguriert – E-Mail-Versand nicht möglich.", "Einstellungen"))
    if not logo_ok:
        tips.append(("🖼️ Logo hochladen", "Kein Firmenlogo – wird auf Rechnungen angezeigt.", "Einstellungen"))
    if backup_n == 0:
        tips.append(("💾 Erstes Backup", "Noch kein Backup erstellt.", "Export & Backup Center"))

    if tips:
        with st.expander("🚀 Einrichtungs-Checkliste", expanded=customers_n == 0):
            for icon_title, desc, page in tips:
                col1, col2 = st.columns([4, 1])
                col1.markdown(f"**{icon_title}** — {desc}")
                if col2.button("→ Öffnen", key=f"tip_{page}"):
                    st.session_state["_nav_override"] = page
                    st.rerun()


# ─────────────────────────────────────────────────────────────
# 4. Sitzungs-Timeout-Warnung
# ─────────────────────────────────────────────────────────────

def check_session_timeout(timeout_minutes: int = 480) -> None:
    """Warnt nach langer Inaktivität (Standard: 8 Stunden)."""
    key = "_session_start"
    if key not in st.session_state:
        st.session_state[key] = datetime.now()
    elapsed = (datetime.now() - st.session_state[key]).total_seconds() / 60
    if elapsed > timeout_minutes:
        st.warning(f"⚠️ Sitzung läuft seit {elapsed/60:.0f} Stunden. Bitte neu einloggen.")


# ─────────────────────────────────────────────────────────────
# 5. PDF-Monatsbericht (ReportLab)
# ─────────────────────────────────────────────────────────────

def generate_monthly_report_pdf(df_fn, year: int, month: int, output_dir: Path) -> Optional[Path]:
    """
    Erstellt einen PDF-Monatsbericht mit:
    - Deckblatt + Firmendaten
    - KPI-Zusammenfassung
    - Rechnungsliste
    - Ausgaben nach Kostenart
    - Offene Posten
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        return None

    month_str = f"{year}-{month:02d}"
    month_names = ["Januar","Februar","März","April","Mai","Juni",
                   "Juli","August","September","Oktober","November","Dezember"]
    month_name = month_names[month - 1]
    output_path = output_dir / f"monatsbericht_{month_str}.pdf"

    # Daten laden
    inv = df_fn("""
        SELECT i.invoice_no, c.company, i.invoice_date, i.gross_total, i.paid_amount, i.status
        FROM invoices i JOIN customers c ON c.id=i.customer_id
        WHERE substr(i.invoice_date,1,7)=? ORDER BY i.invoice_date
    """, (month_str,))
    exp_cat = df_fn("""
        SELECT category, SUM(net_amount) AS Netto, SUM(gross_amount) AS Brutto
        FROM expenses WHERE bwa_month=? GROUP BY category ORDER BY Brutto DESC
    """, (month_str,))
    open_inv = df_fn("""
        SELECT i.invoice_no, c.company, i.due_date,
               ROUND(i.gross_total-i.paid_amount,2) AS Offen
        FROM invoices i JOIN customers c ON c.id=i.customer_id
        WHERE i.status IN ('offen','ueberfaellig')
        ORDER BY i.due_date
    """)

    rev_paid = float(inv[inv["status"]=="bezahlt"]["gross_total"].sum()) if not inv.empty else 0
    rev_all  = float(inv["gross_total"].sum()) if not inv.empty else 0
    exp_all  = float(exp_cat["Brutto"].sum()) if not exp_cat.empty else 0
    result   = rev_paid - exp_all

    doc = SimpleDocTemplate(str(output_path), pagesize=A4,
                            rightMargin=18*mm, leftMargin=18*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="Title2", fontSize=20, fontName="Helvetica-Bold",
                               textColor=colors.HexColor("#0e1117"), spaceAfter=6))
    styles.add(ParagraphStyle(name="Sub", fontSize=10, textColor=colors.HexColor("#555"),
                               spaceAfter=4))
    styles.add(ParagraphStyle(name="Sm", fontSize=8, leading=10))
    styles.add(ParagraphStyle(name="SmB", fontSize=8, leading=10, fontName="Helvetica-Bold"))

    story = []

    # Titel
    story.append(Paragraph(f"Monatsbericht {month_name} {year}", styles["Title2"]))
    story.append(Paragraph(f"Byblos Sicherheitsdienst & Service · Erstellt: {date.today().isoformat()}", styles["Sub"]))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#c0392b")))
    story.append(Spacer(1, 6*mm))

    # KPI-Tabelle
    story.append(Paragraph("Kennzahlen", styles["h2"]))
    kpi_data = [
        ["Kennzahl", "Wert"],
        ["Umsatz fakturiert", f"{rev_all:,.2f} €"],
        ["Davon bezahlt", f"{rev_paid:,.2f} €"],
        ["Ausgaben gesamt", f"{exp_all:,.2f} €"],
        ["Ergebnis (bez. Umsatz - Ausgaben)", f"{result:,.2f} €"],
        ["Anzahl Rechnungen", str(len(inv))],
        ["Offene Posten", str(len(open_inv))],
    ]
    kpi_table = Table(kpi_data, colWidths=[110*mm, 55*mm])
    kpi_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0e1117")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#cccccc")),
        ("ALIGN", (1,0), (-1,-1), "RIGHT"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f5f5f5")]),
        ("FONTNAME", (0,-1), (-1,-1), "Helvetica-Bold"),
        ("BACKGROUND", (0,-1), (-1,-1), colors.HexColor("#e8f5e9") if result >= 0 else colors.HexColor("#ffebee")),
    ]))
    story.append(kpi_table)
    story.append(Spacer(1, 8*mm))

    # Rechnungen
    if not inv.empty:
        story.append(Paragraph(f"Rechnungen ({len(inv)})", styles["h2"]))
        inv_data = [["Nr.", "Kunde", "Datum", "Brutto", "Bezahlt", "Status"]]
        for _, r in inv.iterrows():
            inv_data.append([
                str(r["invoice_no"]), str(r["company"])[:30],
                str(r["invoice_date"]),
                f"{float(r['gross_total']):,.2f} €",
                f"{float(r['paid_amount']):,.2f} €",
                str(r["status"]),
            ])
        inv_table = Table(inv_data, colWidths=[25*mm, 60*mm, 22*mm, 25*mm, 25*mm, 20*mm])
        inv_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1a2744")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#cccccc")),
            ("ALIGN", (3,1), (4,-1), "RIGHT"),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f0f4ff")]),
        ]))
        story.append(inv_table)
        story.append(Spacer(1, 8*mm))

    # Ausgaben nach Kostenart
    if not exp_cat.empty:
        story.append(Paragraph("Ausgaben nach Kostenart", styles["h2"]))
        exp_data = [["Kostenart", "Netto", "Brutto"]]
        for _, r in exp_cat.iterrows():
            exp_data.append([str(r["category"]), f"{float(r['Netto']):,.2f} €", f"{float(r['Brutto']):,.2f} €"])
        exp_data.append(["GESAMT", "", f"{exp_all:,.2f} €"])
        exp_table = Table(exp_data, colWidths=[90*mm, 40*mm, 40*mm])
        exp_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1a2744")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTNAME", (0,-1), (-1,-1), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#cccccc")),
            ("ALIGN", (1,0), (-1,-1), "RIGHT"),
            ("ROWBACKGROUNDS", (0,1), (-1,-2), [colors.white, colors.HexColor("#fff8f0")]),
            ("BACKGROUND", (0,-1), (-1,-1), colors.HexColor("#ffe0cc")),
        ]))
        story.append(exp_table)
        story.append(Spacer(1, 8*mm))

    # Offene Posten
    if not open_inv.empty:
        story.append(Paragraph(f"Offene Posten ({len(open_inv)})", styles["h2"]))
        op_data = [["Rechnung", "Kunde", "Fällig", "Offen"]]
        for _, r in open_inv.head(20).iterrows():
            op_data.append([str(r["invoice_no"]), str(r["company"])[:35],
                            str(r["due_date"]), f"{float(r['Offen']):,.2f} €"])
        op_table = Table(op_data, colWidths=[25*mm, 80*mm, 25*mm, 27*mm])
        op_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#c0392b")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#cccccc")),
            ("ALIGN", (3,1), (3,-1), "RIGHT"),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#fff0f0")]),
        ]))
        story.append(op_table)

    # Fußzeile
    story.append(Spacer(1, 10*mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc")))
    story.append(Paragraph(
        f"Byblos CRM v2.0 · Bericht erstellt am {datetime.now().strftime('%d.%m.%Y %H:%M')} · "
        f"Operative Auswertung – keine steuerliche Beratung.",
        styles["Sm"]
    ))

    doc.build(story)
    return output_path


def page_pdf_report(df_fn, base_dir: Path) -> None:
    """Seite: PDF-Monatsberichte erstellen und herunterladen."""
    st.title("📑 PDF-Berichte")

    tabs = st.tabs(["📅 Monatsbericht", "📋 Vorhandene Berichte"])

    with tabs[0]:
        st.subheader("Monatsbericht als PDF erstellen")
        col1, col2 = st.columns(2)
        year  = col1.selectbox("Jahr", list(range(date.today().year, date.today().year - 5, -1)))
        month = col2.selectbox("Monat", list(range(1, 13)), index=date.today().month - 1,
                               format_func=lambda m: ["Jan","Feb","Mär","Apr","Mai","Jun",
                                                       "Jul","Aug","Sep","Okt","Nov","Dez"][m-1])
        if st.button("📄 PDF erstellen", type="primary"):
            with st.spinner("PDF wird erstellt..."):
                report_dir = base_dir / "generated"
                report_dir.mkdir(exist_ok=True)
                pdf_path = generate_monthly_report_pdf(df_fn, year, month, report_dir)
                if pdf_path and pdf_path.exists():
                    st.success(f"✅ {pdf_path.name} erstellt!")
                    st.download_button(
                        "📥 PDF herunterladen",
                        pdf_path.read_bytes(),
                        file_name=pdf_path.name,
                        mime="application/pdf"
                    )
                else:
                    st.error("PDF-Erstellung fehlgeschlagen. Bitte ReportLab prüfen.")

    with tabs[1]:
        report_dir = base_dir / "generated"
        if report_dir.exists():
            pdfs = sorted(report_dir.glob("monatsbericht_*.pdf"), reverse=True)
            if pdfs:
                for pdf in pdfs[:20]:
                    col1, col2 = st.columns([4, 1])
                    col1.write(f"📄 {pdf.name} ({pdf.stat().st_size//1024} KB)")
                    col2.download_button("⬇", pdf.read_bytes(), pdf.name,
                                         mime="application/pdf", key=f"dl_{pdf.name}")
            else:
                st.info("Noch keine PDF-Berichte erstellt.")
