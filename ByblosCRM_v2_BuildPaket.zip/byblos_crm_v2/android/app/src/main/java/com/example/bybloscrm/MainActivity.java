package com.example.bybloscrm;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Hauptaktivität für die Byblos‑CRM‑WebView‑App.
 *
 * Diese minimalistische Klasse lädt beim Start die CRM‑Webanwendung
 * über eine WebView.  JavaScript ist aktiviert, um moderne
 * Web‑Frameworks zu unterstützen.  Der WebViewClient sorgt dafür,
 * dass Links innerhalb der WebView geöffnet werden, anstatt einen
 * externen Browser zu verwenden.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        // TODO: Setze hier die URL deines CRM‑Servers ein
        webView.loadUrl("https://dein-crm-server-url.de");
    }
}