@echo off
:: build_apk.bat - Byblos CRM APK Builder (Windows)
:: Voraussetzungen: Android SDK, Java 17, ANDROID_HOME gesetzt

echo.
echo =====================================================
echo   Byblos CRM - Android APK Builder (Windows)
echo =====================================================
echo.

set BUILD_TYPE=%1
if "%BUILD_TYPE%"=="" set BUILD_TYPE=debug

where java >nul 2>&1
if errorlevel 1 ( echo [FEHLER] Java nicht gefunden. & pause & exit /b 1 )
java -version

cd /d "%~dp0"

if not exist "gradlew.bat" (
    echo [FEHLER] gradlew.bat nicht gefunden.
    echo Bitte Android Studio verwenden oder Gradle Wrapper manuell einrichten.
    pause & exit /b 1
)

echo [INFO] Starte Gradle Build (%BUILD_TYPE%)...
if "%BUILD_TYPE%"=="release" (
    gradlew.bat assembleRelease
    set APK_PATH=app\build\outputs\apk\release\app-release.apk
) else (
    gradlew.bat assembleDebug
    set APK_PATH=app\build\outputs\apk\debug\app-debug.apk
)

if errorlevel 1 ( echo [FEHLER] Build fehlgeschlagen. & pause & exit /b 1 )

echo.
echo [OK] APK erstellt: %~dp0%APK_PATH%
echo.
echo Installation: adb install %APK_PATH%
echo =====================================================
pause
