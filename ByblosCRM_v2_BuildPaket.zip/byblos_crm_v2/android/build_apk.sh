#!/usr/bin/env bash
# build_apk.sh – Byblos CRM APK Builder
# =====================================================
# Erstellt eine Debug- und Release-APK mit Gradle.
# Voraussetzungen:
#   - Android SDK installiert (ANDROID_HOME gesetzt)
#   - Java 17 installiert (JAVA_HOME gesetzt)
#   - Gradle Wrapper (gradlew) vorhanden
#
# Aufruf:
#   ./android/build_apk.sh                 # Debug-APK
#   ./android/build_apk.sh release         # Release-APK (Signierung erforderlich)
#
# APK-Ausgabe:
#   android/app/build/outputs/apk/debug/app-debug.apk
#   android/app/build/outputs/apk/release/app-release.apk

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
BUILD_TYPE="${1:-debug}"

echo ""
echo "====================================================="
echo "  Byblos CRM – Android APK Builder"
echo "  Build-Typ: $BUILD_TYPE"
echo "====================================================="
echo ""

# Voraussetzungen prüfen
check_cmd() {
    command -v "$1" &>/dev/null || { echo "[FEHLER] $1 nicht gefunden. Bitte installieren."; exit 1; }
}

check_cmd java
java -version

# Gradle Wrapper erstellen falls nicht vorhanden
cd "$SCRIPT_DIR"
if [ ! -f "gradlew" ]; then
    echo "[INFO] Erstelle Gradle Wrapper..."
    gradle wrapper --gradle-version 8.6 2>/dev/null || {
        echo "[WARN] gradle nicht gefunden. Lade Gradle Wrapper manuell..."
        mkdir -p gradle/wrapper
        cat > gradle/wrapper/gradle-wrapper.properties << 'EOF'
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.6-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
EOF
        # Wrapper-JAR herunterladen
        curl -sL "https://github.com/gradle/gradle/raw/v8.6.0/gradle/wrapper/gradle-wrapper.jar" \
             -o gradle/wrapper/gradle-wrapper.jar || true
    }
fi

chmod +x gradlew 2>/dev/null || true

# Build-Befehl ausführen
echo "[INFO] Starte Gradle Build ($BUILD_TYPE)..."
echo ""

if [ "$BUILD_TYPE" = "release" ]; then
    # Release-Build (Keystore-Variablen müssen gesetzt sein)
    if [ -z "${KEYSTORE_FILE:-}" ]; then
        echo "[WARN] KEYSTORE_FILE nicht gesetzt. Erstelle unsigned Release-APK..."
        ./gradlew assembleRelease \
            -PKEYSTORE_FILE="" -PKEYSTORE_PASS="" -PKEY_ALIAS="" -PKEY_PASS=""
    else
        ./gradlew assembleRelease \
            -PKEYSTORE_FILE="$KEYSTORE_FILE" \
            -PKEYSTORE_PASS="$KEYSTORE_PASS" \
            -PKEY_ALIAS="$KEY_ALIAS" \
            -PKEY_PASS="$KEY_PASS"
    fi
    APK_PATH="app/build/outputs/apk/release/app-release.apk"
else
    ./gradlew assembleDebug
    APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
fi

echo ""
if [ -f "$APK_PATH" ]; then
    echo "[OK] APK erstellt: $SCRIPT_DIR/$APK_PATH"
    echo ""
    echo "Installation auf verbundenem Gerät:"
    echo "  adb install $APK_PATH"
    echo ""
    echo "Oder: Datei per USB auf Gerät übertragen und öffnen."
else
    echo "[FEHLER] APK-Datei nicht gefunden. Build fehlgeschlagen."
    exit 1
fi

echo "====================================================="
