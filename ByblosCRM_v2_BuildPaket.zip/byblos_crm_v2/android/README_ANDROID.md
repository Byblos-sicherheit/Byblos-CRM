# Android‑App (WebView) für Byblos CRM

Diese Anwendung ist eine einfache Hülle um die webbasierte
Byblos‑CRM‑Anwendung.  Sie besteht aus einer Android‑App mit einer
einzigen `WebView`, die die URL deines CRM lädt.  Damit
erhältst du eine installierbare `.apk`, die sich wie eine native
App verhält.

## Struktur

```
android/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/bybloscrm/MainActivity.java
│   │   │   ├── res/layout/activity_main.xml
│   │   │   └── AndroidManifest.xml
│   └── build.gradle (je nach Android‑Studio‑Version)
└── README_ANDROID.md
```

> **Wichtig:** Dies ist eine vereinfachte Struktur.  In der
> Praxis erzeugst du das Projekt mit Android Studio; kopiere dann
> die Dateien `MainActivity.java`, `activity_main.xml` und die
> `uses‑permission`‑Einträge in dein Projekt.

## Schritte zum Erstellen

1. **Android Studio installieren.**  Lade Android Studio von der
   offiziellen Website herunter und installiere es.
2. **Neues Projekt anlegen.**  Starte Android Studio, wähle
   "Neues Projekt" → "Empty Activity".  Vergib Paketnamen
   (z. B. `com.example.bybloscrm`) und leg den Speicherort fest.
3. **WebView einrichten.**  Öffne die Datei
   `app/src/main/res/layout/activity_main.xml` und ersetze den
   Inhalt durch:

   ```xml
   <?xml version="1.0" encoding="utf-8"?>
   <RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
       android:layout_width="match_parent"
       android:layout_height="match_parent">

       <WebView
           android:id="@+id/webview"
           android:layout_width="match_parent"
           android:layout_height="match_parent" />

   </RelativeLayout>
   ```

4. **Activity‑Code anpassen.**  Öffne
   `app/src/main/java/.../MainActivity.java` und ersetze den Inhalt
   durch den Code aus `MainActivity.java` in diesem Verzeichnis:

   ```java
   package com.example.bybloscrm;

   import android.os.Bundle;
   import android.webkit.WebView;
   import android.webkit.WebViewClient;
   import androidx.appcompat.app.AppCompatActivity;

   public class MainActivity extends AppCompatActivity {
       @Override
       protected void onCreate(Bundle savedInstanceState) {
           super.onCreate(savedInstanceState);
           setContentView(R.layout.activity_main);
           WebView webView = findViewById(R.id.webview);
           webView.setWebViewClient(new WebViewClient());
           webView.getSettings().setJavaScriptEnabled(true);
           webView.loadUrl("https://dein-crm-server-url.de");
       }
   }
   ```

   Ersetze `https://dein-crm-server-url.de` durch die URL deines
   selbst gehosteten CRMs (z. B. eine öffentliche IP oder Domain).
5. **Internet‑Berechtigung eintragen.**  Füge in deiner
   `AndroidManifest.xml` folgende Zeile innerhalb des
   `<manifest>`–Tags ein:

   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   ```

   Der Manifest‑Ausschnitt sieht dann so aus:

   ```xml
   <manifest xmlns:android="http://schemas.android.com/apk/res/android"
       package="com.example.bybloscrm">

       <uses-permission android:name="android.permission.INTERNET" />

       <application
           android:allowBackup="true"
           android:label="Byblos CRM"
           android:theme="@style/Theme.AppCompat.Light.NoActionBar">
           <activity android:name=".MainActivity">
               <intent-filter>
                   <action android:name="android.intent.action.MAIN" />
                   <category android:name="android.intent.category.LAUNCHER" />
               </intent-filter>
           </activity>
       </application>

   </manifest>
   ```

6. **Projekt bauen.**  Wähle "Build" → "Build Bundle / APK" →
   "Build APK".  Android Studio erstellt eine `app-release.apk` im
   Ordner `app/build/outputs/apk/release/`.  Signiere die APK
   mit einem Release‑Keystore (über "Generate Signed Bundle / APK").

7. **Testen.**  Übertrage die signierte APK auf ein Android‑Gerät
   oder verwende einen Emulator und installiere die App.

## Hinweise

* Der WebView lädt Inhalte aus dem Internet; es gibt daher keine
  Offline‑Funktion.  Stelle sicher, dass der CRM‑Server erreichbar
  ist.
* Je nach Android‑Version müssen zusätzliche Berechtigungen
  beachtet werden (z. B. `REQUEST_INSTALL_PACKAGES`).

Die in diesem Verzeichnis enthaltenen Dateien dienen als Vorlage und
Beispiel.  Passe Paketnamen und URLs an dein Projekt an.