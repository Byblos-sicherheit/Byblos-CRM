# Copilot, Codespaces und VS Code Setup

## Ziel
Diese Erweiterung macht das CRM sofort entwicklerfreundlicher. Neue Entwickler können das Projekt in GitHub Codespaces öffnen, Abhängigkeiten installieren, Smoke-Tests ausführen und die Streamlit-App starten.

## Enthalten
- `.devcontainer/devcontainer.json` für GitHub Codespaces
- `.vscode/extensions.json` mit empfohlenen Erweiterungen
- `.vscode/settings.json` mit Python- und Copilot-Hinweisen
- `.vscode/tasks.json` für Install, Start, Smoke-Test und Windows-Build
- `.vscode/launch.json` für Streamlit-Debugging
- `.github/copilot-instructions.md` als Arbeitsanweisung für GitHub Copilot
- `.github/workflows/smoke-test.yml` für GitHub Actions
- `scripts/dev_setup_windows.ps1`
- `scripts/dev_setup_mac_linux.sh`

## Start in Codespaces
1. Projekt in ein GitHub Repository hochladen.
2. In GitHub auf **Code** klicken.
3. Tab **Codespaces** öffnen.
4. **Create codespace** starten.
5. Nach dem Container-Setup wird automatisch `pip install -r byblos_crm_app/requirements.txt` ausgeführt.
6. In VS Code Task **Run CRM** starten.
7. Port 8501 öffnen.

## Lokaler Start mit VS Code

### Windows PowerShell
```powershell
scripts\dev_setup_windows.ps1
```

### macOS/Linux
```bash
bash scripts/dev_setup_mac_linux.sh
```

## Copilot-Workflow
Nutze Copilot für:
- kleine UI-Erweiterungen in Streamlit
- Testfälle für neue Import-Logik
- Dokumentation
- Refactoring-Vorschläge

Nicht blind übernehmen bei:
- XRechnung/XML-Konformität
- Datenschutz/AVV/AGB/Verträgen
- Lohnabrechnung oder Arbeitszeitrecht
- Sicherheits-/Berechtigungslogik

## Mindestprüfung vor jeder Änderung
```bash
python tests/test_imports.py
python -m py_compile byblos_crm_app/app.py
python -m py_compile byblos_crm_app/ml_logic.py
```
