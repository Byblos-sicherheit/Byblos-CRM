# skills-copilot-codespaces-vscode

Dieses Verzeichnis beschreibt den eingebauten Entwickler-Workflow für Byblos CRM:

- GitHub Codespaces
- VS Code Tasks
- GitHub Copilot Instructions
- Smoke-Test Workflow
- lokale Setup-Skripte

Das eigentliche installierbare ChatGPT-Skill-Paket liegt separat als `skill.zip` bei.
